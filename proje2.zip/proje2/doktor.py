"""
============================================================
  PROJE 2: ONLİNE DOKTOR RANDEVU SİSTEMİ
============================================================
Açıklama: Doktor, Hasta ve Randevu sınıflarının OOP
mantığıyla (Kapsülleme ve Bileşim) yönetildiği medikal otomasyon.
============================================================
"""

import sys
from datetime import datetime

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFrame,
    QStackedWidget, QHeaderView, QLineEdit, QGridLayout,
    QSpinBox, QMessageBox, QAbstractItemView, QGraphicsDropShadowEffect,
    QDateEdit, QComboBox
)
from PyQt5.QtCore import Qt, QTimer, QDate
from PyQt5.QtGui import QColor, QPalette, QFont

# ============================================================
#  1. KISIM: İŞ MANTIĞI VE SINIFLAR (BACKEND)
# ============================================================

class Hasta:
    """Sisteme kayıtlı hastayı temsil eder."""
    def __init__(self, hasta_id: int, ad: str, tc: str, telefon: str):
        self.__hasta_id = hasta_id
        self.__ad = ad
        self.__tc = tc
        self.__telefon = telefon
        self.__randevular = [] # Hastanın kendi randevularını tuttuğu liste

    def get_hasta_id(self) -> int: return self.__hasta_id
    def get_ad(self) -> str:       return self.__ad
    def get_tc(self) -> str:       return self.__tc
    def get_telefon(self) -> str:  return self.__telefon

    # HOCANIN LİSTESİNDE İSTENEN METOD
    def randevu_al(self, randevu_nesnesi: 'Randevu'):
        """Hastanın kendi profiline randevuyu ekler."""
        self.__randevular.append(randevu_nesnesi)

class Doktor:
    """Klinikteki doktoru temsil eder."""
    def __init__(self, doktor_id: int, ad: str, uzmanlik: str):
        self.__doktor_id = doktor_id
        self.__ad = ad
        self.__uzmanlik = uzmanlik
        # Varsayılan uygun saatler (Klinik mesai saatleri)
        self.__uygun_saatler = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]

    def get_doktor_id(self) -> int: return self.__doktor_id
    def get_ad(self) -> str:        return self.__ad
    def get_uzmanlik(self) -> str:  return self.__uzmanlik
    def get_saatler(self) -> list:  return self.__uygun_saatler

    # HOCANIN LİSTESİNDE İSTENEN METOD
    def uygunluk_kontrol(self, istenen_saat: str, dolu_saatler: list) -> bool:
        """Doktorun o saatte mesaisi olup olmadığını ve dolu olup olmadığını kontrol eder."""
        if istenen_saat not in self.__uygun_saatler:
            return False # Doktorun böyle bir mesai saati yok
        if istenen_saat in dolu_saatler:
            return False # Saat dolu
        return True # Saat uygun

class Randevu:
    """Doktor ve Hasta arasındaki randevu ilişkisini tutar."""
    def __init__(self, randevu_id: int, tarih: str, saat: str, doktor: Doktor, hasta: Hasta):
        self.__randevu_id = randevu_id
        self.__tarih = tarih
        self.__saat = saat
        self.__doktor = doktor
        self.__hasta = hasta
        self.__durum = "Aktif"

    def get_randevu_id(self) -> int: return self.__randevu_id
    def get_tarih(self) -> str:      return self.__tarih
    def get_saat(self) -> str:       return self.__saat
    def get_doktor(self) -> Doktor:  return self.__doktor
    def get_hasta(self) -> Hasta:    return self.__hasta
    def get_durum(self) -> str:      return self.__durum

    # HOCANIN LİSTESİNDE İSTENEN METODLAR
    def randevu_olustur(self):
        """Randevu nesnesi oluştuğunda hastanın profiline de işler."""
        self.__hasta.randevu_al(self)
        return True, f"Randevu {self.__tarih} {self.__saat} için onaylandı."

    def randevu_iptal(self):
        """Randevunun durumunu iptal olarak günceller."""
        if self.__durum == "İptal Edildi":
            return False, "Bu randevu zaten iptal edilmiş!"
        self.__durum = "İptal Edildi"
        return True, "Randevu başarıyla iptal edildi."

class HastaneMerkezi:
    """Tüm hasta, doktor ve randevu işlemlerini yöneten ana sınıf."""
    def __init__(self):
        self.__hastalar = {}
        self.__doktorlar = {}
        self.__randevular = []
        self.__son_randevu_id = 1000

    def hasta_ekle(self, hasta: Hasta):
        if hasta.get_hasta_id() in self.__hastalar:
            return False, "Bu ID ile hasta zaten kayıtlı!"
        self.__hastalar[hasta.get_hasta_id()] = hasta
        return True, "Hasta kaydı tamamlandı."

    def doktor_ekle(self, doktor: Doktor):
        if doktor.get_doktor_id() in self.__doktorlar:
            return False, "Bu ID ile doktor zaten kayıtlı!"
        self.__doktorlar[doktor.get_doktor_id()] = doktor
        return True, "Doktor sisteme eklendi."

    def get_tum_hastalar(self): return self.__hastalar
    def get_tum_doktorlar(self): return self.__doktorlar
    def get_tum_randevular(self): return self.__randevular

    def randevu_olustur_merkez(self, hasta_id: int, doktor_id: int, tarih: str, saat: str):
        hasta = self.__hastalar.get(hasta_id)
        doktor = self.__doktorlar.get(doktor_id)

        if not hasta: return False, "Hasta kaydı bulunamadı!"
        if not doktor: return False, "Doktor bulunamadı!"

        # O güne ait doktorun dolu saatlerini bul
        dolu_saatler = [r.get_saat() for r in self.__randevular 
                        if r.get_doktor().get_doktor_id() == doktor_id 
                        and r.get_tarih() == tarih 
                        and r.get_durum() == "Aktif"]

        # Doktorun uygunluk_kontrol metodunu çağırıyoruz
        if not doktor.uygunluk_kontrol(saat, dolu_saatler):
            return False, "Seçilen saatte doktor dolu veya mesai saati dışında!"

        yeni_randevu = Randevu(self.__son_randevu_id, tarih, saat, doktor, hasta)
        ok, msg = yeni_randevu.randevu_olustur()
        
        if ok:
            self.__randevular.append(yeni_randevu)
            self.__son_randevu_id += 1
            return True, msg
        return False, "Bilinmeyen bir hata oluştu."

    def randevu_iptal_merkez(self, randevu_id: int):
        for r in self.__randevular:
            if r.get_randevu_id() == randevu_id:
                return r.randevu_iptal()
        return False, "Randevu bulunamadı."

    # HOCANIN LİSTESİNDE İSTENEN EK ÖZELLİK
    def gunluk_randevu_listesi(self, tarih: str) -> list:
        """Belirli bir tarihteki tüm aktif randevuları getirir."""
        return [r for r in self.__randevular if r.get_tarih() == tarih and r.get_durum() == "Aktif"]

    def test_verilerini_yukle(self):
        d1 = Doktor(1, "Dr. Ali Yılmaz", "Kardiyoloji")
        d2 = Doktor(2, "Dr. Ayşe Demir", "Dahiliye")
        self.doktor_ekle(d1); self.doktor_ekle(d2)

        h1 = Hasta(101, "Yiğit Talha Gümüş", "12345678901", "0555 111 2233")
        h2 = Hasta(102, "Berkkan Kahraman", "98765432109", "0532 999 8877")
        self.hasta_ekle(h1); self.hasta_ekle(h2)

        bugun = datetime.now().strftime("%dd.%m.%yyyy") # Sunumda bugün dolu görünsün
        bugun_gercek = QDate.currentDate().toString("dd.MM.yyyy")
        self.randevu_olustur_merkez(101, 1, bugun_gercek, "09:00")
        self.randevu_olustur_merkez(102, 2, bugun_gercek, "14:00")


# ============================================================
#  2. KISIM: ARAYÜZ (GUI) - MEDİKAL (TEMİZ) TEMA
# ============================================================

# TEMA: Medikal Beyaz, Gök Mavisi ve Ferah Gri (Clean Corporate)
C = {
    "bg":        "#F1F5F9",  # Açık Gri-Mavi Arka Plan
    "sidebar":   "#0C4A6E",  # Medikal Koyu Lacivert (Ocean)
    "card":      "#FFFFFF",  # Saf Beyaz Kartlar
    "border":    "#E2E8F0",  # İnce Gri Kenarlık
    "accent":    "#0284C7",  # Medikal Mavi (Primary)
    "accent2":   "#0EA5E9",  # Açık Mavi (Secondary)
    "success":   "#10B981",  # Zümrüt Yeşili (Sağlık/Onay)
    "warning":   "#F59E0B",  # Turuncu
    "danger":    "#EF4444",  # Kırmızı (İptal)
    "text":      "#0F172A",  # Koyu Lacivert (Okunabilir Metin)
    "text_sub":  "#64748B",  # Alt Metin
    "text_dim":  "#94A3B8",  # Sönük Metin
    "row_alt":   "#F8FAFC",  # Tablo Çizgili Satır
    "row_sel":   "#E0F2FE",  # Seçili Satır (Açık Mavi)
    "input_bg":  "#FFFFFF",  # Girdi Alanı
}

def card_ss(): return f"background:{C['card']};border:1px solid {C['border']};border-radius:12px;"
def btn_primary_ss(): return f"QPushButton{{background:{C['accent']};color:#FFF;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:700;}}QPushButton:hover{{background:{C['accent2']};}}"
def btn_success_ss(): return f"QPushButton{{background:{C['success']};color:#FFF;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:700;}}QPushButton:hover{{background:#34D399;}}"
def btn_danger_ss(): return f"QPushButton{{background:{C['danger']};color:#FFF;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:700;}}QPushButton:hover{{background:#F87171;}}"
def input_ss(): return f"QLineEdit,QSpinBox,QDateEdit,QComboBox{{background:{C['input_bg']};color:{C['text']};border:1px solid #CBD5E1;border-radius:8px;padding:8px 12px;font-size:13px;}}"

TABLE_SS = f"""
    QTableWidget{{background:{C['card']};color:{C['text']};border:1px solid {C['border']};border-radius:8px;gridline-color:{C['border']};font-size:13px;selection-background-color:{C['row_sel']};selection-color:{C['accent']};outline:none;alternate-background-color:{C['row_alt']};}}
    QTableWidget::item{{padding:12px 14px;border-bottom:1px solid {C['border']};}}
    QHeaderView::section{{background:#F8FAFC;color:{C['text_sub']};padding:12px 14px;border:none;border-bottom:2px solid #CBD5E1;font-size:12px;font-weight:800;letter-spacing:0.5px; text-transform: uppercase;}}
"""

def shadow(widget):
    fx = QGraphicsDropShadowEffect(widget)
    fx.setBlurRadius(15); fx.setColor(QColor(0, 0, 0, 15)); fx.setOffset(0, 4)
    widget.setGraphicsEffect(fx)

class KpiCard(QFrame):
    def __init__(self, baslik, deger, alt, renk):
        super().__init__()
        self.setFixedHeight(114)
        self.setStyleSheet(f"QFrame{{background:{C['card']};border:1px solid {C['border']};border-radius:12px;border-left:5px solid {renk};}}")
        shadow(self)
        lay = QVBoxLayout(self); lay.setContentsMargins(20, 15, 20, 15); lay.setSpacing(4)
        lbl_t = QLabel(baslik.upper()); lbl_t.setStyleSheet(f"color:{C['text_sub']};font-size:11px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        self.lbl_v = QLabel(str(deger)); self.lbl_v.setStyleSheet(f"color:{renk};font-size:32px;font-weight:800;background:transparent;border:none;")
        lbl_a = QLabel(alt); lbl_a.setStyleSheet(f"color:{C['text_dim']};font-size:12px;background:transparent;border:none;")
        lay.addWidget(lbl_t); lay.addWidget(self.lbl_v); lay.addWidget(lbl_a)
    def guncelle(self, val): self.lbl_v.setText(str(val))

class SideBtn(QPushButton):
    def __init__(self, ikon, metin):
        super().__init__(f"  {ikon}  {metin}")
        self.setCheckable(True); self.setFixedHeight(50); self.setCursor(Qt.PointingHandCursor)
        self._refresh(False)
    def _refresh(self, aktif):
        if aktif: self.setStyleSheet(f"QPushButton{{background:rgba(255, 255, 255, 0.1);color:#FFFFFF;border:none;border-left:4px solid #38BDF8;border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:700;}}")
        else: self.setStyleSheet(f"QPushButton{{background:transparent;color:#94A3B8;border:none;border-left:4px solid transparent;border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:500;}}QPushButton:hover{{background:rgba(255, 255, 255, 0.05);color:#F8FAFC;}}")
    def setChecked(self, v): super().setChecked(v); self._refresh(v)

class DashboardPage(QWidget):
    def __init__(self, merkez: HastaneMerkezi):
        super().__init__()
        self.merkez = merkez
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🏥  Klinik Özeti", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        self.kpi_row = QHBoxLayout(); lay.addLayout(self.kpi_row)
        self.c1 = KpiCard("Uzman Doktor", 0, "Aktif Personel", C['accent'])
        self.c2 = KpiCard("Kayıtlı Hasta", 0, "Sistemdeki Hastalar", C['success'])
        self.c3 = KpiCard("Toplam Randevu", 0, "Geçmiş ve Gelecek", C['warning'])
        for c in [self.c1, self.c2, self.c3]: self.kpi_row.addWidget(c)
        
        lay.addWidget(QLabel("Yaklaşan Randevular", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:700;margin-top:15px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["Randevu No", "Tarih", "Saat", "Doktor", "Hasta Adı"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)

    def refresh(self):
        doktorlar = self.merkez.get_tum_doktorlar().values()
        hastalar = self.merkez.get_tum_hastalar().values()
        randevular = self.merkez.get_tum_randevular()
        
        self.c1.guncelle(len(doktorlar))
        self.c2.guncelle(len(hastalar))
        self.c3.guncelle(len(randevular))

        self.tablo.setRowCount(0)
        aktif_randevular = [r for r in randevular if r.get_durum() == "Aktif"]
        for r_obj in reversed(aktif_randevular[-10:]):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            id_item = QTableWidgetItem(f"#{r_obj.get_randevu_id()}")
            font = QFont(); font.setBold(True); id_item.setFont(font)
            id_item.setForeground(QColor(C['accent']))
            
            self.tablo.setItem(r, 0, id_item)
            self.tablo.setItem(r, 1, QTableWidgetItem(r_obj.get_tarih()))
            self.tablo.setItem(r, 2, QTableWidgetItem(r_obj.get_saat()))
            self.tablo.setItem(r, 3, QTableWidgetItem(r_obj.get_doktor().get_ad()))
            self.tablo.setItem(r, 4, QTableWidgetItem(r_obj.get_hasta().get_ad()))

class KayitPage(QWidget):
    def __init__(self, merkez: HastaneMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🩺  Doktor ve Hasta Kayıt", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        # DOKTOR EKLE
        kart1 = QFrame(); kart1.setStyleSheet(card_ss()); shadow(kart1)
        klay1 = QVBoxLayout(kart1); klay1.setContentsMargins(24,20,24,20)
        klay1.addWidget(QLabel("Yeni Doktor Tanımla", styleSheet=f"color:{C['accent']};font-size:14px;font-weight:700;background:transparent;"))
        
        g1 = QHBoxLayout()
        self.d_id = QSpinBox(); self.d_id.setRange(1, 9999); self.d_id.setStyleSheet(input_ss())
        self.d_ad = QLineEdit(); self.d_ad.setPlaceholderText("Dr. Ad Soyad"); self.d_ad.setStyleSheet(input_ss())
        self.d_uzmanlik = QLineEdit(); self.d_uzmanlik.setPlaceholderText("Uzmanlık (Örn: Dahiliye)"); self.d_uzmanlik.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:700;background:transparent;"
        g1.addWidget(QLabel("ID:", styleSheet=lbl_style)); g1.addWidget(self.d_id)
        g1.addWidget(QLabel("Ad Soyad:", styleSheet=lbl_style)); g1.addWidget(self.d_ad)
        g1.addWidget(QLabel("Uzmanlık:", styleSheet=lbl_style)); g1.addWidget(self.d_uzmanlik)
        
        btn_doktor = QPushButton("＋ Ekle"); btn_doktor.setStyleSheet(btn_primary_ss()); btn_doktor.clicked.connect(self._doktor_ekle)
        g1.addWidget(btn_doktor)
        klay1.addLayout(g1)
        lay.addWidget(kart1)

        # HASTA EKLE
        kart2 = QFrame(); kart2.setStyleSheet(card_ss()); shadow(kart2)
        klay2 = QVBoxLayout(kart2); klay2.setContentsMargins(24,20,24,20)
        klay2.addWidget(QLabel("Yeni Hasta Kaydı Oluştur", styleSheet=f"color:{C['success']};font-size:14px;font-weight:700;background:transparent;"))
        
        g2 = QGridLayout()
        self.h_id = QSpinBox(); self.h_id.setRange(1, 99999); self.h_id.setStyleSheet(input_ss())
        self.h_ad = QLineEdit(); self.h_ad.setPlaceholderText("Hasta Ad Soyad"); self.h_ad.setStyleSheet(input_ss())
        self.h_tc = QLineEdit(); self.h_tc.setPlaceholderText("TC Kimlik No"); self.h_tc.setStyleSheet(input_ss())
        self.h_tel = QLineEdit(); self.h_tel.setPlaceholderText("Telefon No"); self.h_tel.setStyleSheet(input_ss())
        
        g2.addWidget(QLabel("Kayıt ID:", styleSheet=lbl_style), 0, 0); g2.addWidget(self.h_id, 1, 0)
        g2.addWidget(QLabel("Ad Soyad:", styleSheet=lbl_style), 0, 1); g2.addWidget(self.h_ad, 1, 1)
        g2.addWidget(QLabel("TC Kimlik:", styleSheet=lbl_style), 0, 2); g2.addWidget(self.h_tc, 1, 2)
        g2.addWidget(QLabel("Telefon:", styleSheet=lbl_style), 0, 3); g2.addWidget(self.h_tel, 1, 3)
        klay2.addLayout(g2)
        
        btn_hasta = QPushButton("＋ Hasta Kaydet"); btn_hasta.setStyleSheet(btn_success_ss()); btn_hasta.clicked.connect(self._hasta_ekle)
        klay2.addWidget(btn_hasta, alignment=Qt.AlignRight)
        lay.addWidget(kart2)
        lay.addStretch()

    def _doktor_ekle(self):
        if not self.d_ad.text().strip(): return
        d = Doktor(self.d_id.value(), self.d_ad.text(), self.d_uzmanlik.text())
        ok, msg = self.merkez.doktor_ekle(d)
        if ok:
            self.d_ad.clear(); self.d_uzmanlik.clear()
            self.dashboard.refresh()
            if hasattr(self.parentWidget().parentWidget(), 'p_randevu'):
                self.parentWidget().parentWidget().p_randevu.combos_guncelle()
            QMessageBox.information(self, "Sistem", msg)
        else: QMessageBox.warning(self, "Hata", msg)

    def _hasta_ekle(self):
        if not self.h_ad.text().strip(): return
        h = Hasta(self.h_id.value(), self.h_ad.text(), self.h_tc.text(), self.h_tel.text())
        ok, msg = self.merkez.hasta_ekle(h)
        if ok:
            self.h_ad.clear(); self.h_tc.clear(); self.h_tel.clear()
            self.dashboard.refresh()
            if hasattr(self.parentWidget().parentWidget(), 'p_randevu'):
                self.parentWidget().parentWidget().p_randevu.combos_guncelle()
            QMessageBox.information(self, "Sistem", msg)
        else: QMessageBox.warning(self, "Hata", msg)


class RandevuIslemleriPage(QWidget):
    def __init__(self, merkez: HastaneMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🗓️  Randevu Oluştur & İptal", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QGridLayout(kart); klay.setContentsMargins(24,20,24,20)
        
        self.combo_hasta = QComboBox(); self.combo_hasta.setStyleSheet(input_ss())
        self.combo_doktor = QComboBox(); self.combo_doktor.setStyleSheet(input_ss())
        self.combo_doktor.currentIndexChanged.connect(self._saatleri_getir)
        
        self.r_tarih = QDateEdit(); self.r_tarih.setCalendarPopup(True); self.r_tarih.setDate(QDate.currentDate()); self.r_tarih.setStyleSheet(input_ss())
        self.combo_saat = QComboBox(); self.combo_saat.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:700;background:transparent;"
        klay.addWidget(QLabel("Hasta Seçin:", styleSheet=lbl_style), 0, 0); klay.addWidget(self.combo_hasta, 1, 0)
        klay.addWidget(QLabel("Doktor Seçin:", styleSheet=lbl_style), 0, 1); klay.addWidget(self.combo_doktor, 1, 1)
        klay.addWidget(QLabel("Tarih:", styleSheet=lbl_style), 0, 2); klay.addWidget(self.r_tarih, 1, 2)
        klay.addWidget(QLabel("Uygun Saat:", styleSheet=lbl_style), 0, 3); klay.addWidget(self.combo_saat, 1, 3)
        
        btn_al = QPushButton("✓ Randevuyu Onayla"); btn_al.setStyleSheet(btn_primary_ss()); btn_al.clicked.connect(self._randevu_al)
        klay.addWidget(btn_al, 2, 3, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Tüm Randevular (İptal İçin Seçin)", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:700;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(6)
        self.tablo.setHorizontalHeaderLabels(["Randevu ID", "Durum", "Tarih", "Saat", "Doktor", "Hasta"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        
        btn_iptal = QPushButton("✕ Seçili Randevuyu İptal Et"); btn_iptal.setStyleSheet(btn_danger_ss()); btn_iptal.clicked.connect(self._randevu_iptal)
        lay.addWidget(btn_iptal, alignment=Qt.AlignRight)

        self.combos_guncelle()
        self.refresh()

    def combos_guncelle(self):
        self.combo_hasta.clear(); self.combo_doktor.clear()
        for h in self.merkez.get_tum_hastalar().values():
            self.combo_hasta.addItem(f"{h.get_hasta_id()} - {h.get_ad()}", h.get_hasta_id())
        for d in self.merkez.get_tum_doktorlar().values():
            self.combo_doktor.addItem(f"Dr. {d.get_ad()} ({d.get_uzmanlik()})", d.get_doktor_id())
        self._saatleri_getir()

    def _saatleri_getir(self):
        self.combo_saat.clear()
        d_id = self.combo_doktor.currentData()
        if d_id:
            doktor = self.merkez.get_tum_doktorlar().get(d_id)
            if doktor:
                self.combo_saat.addItems(doktor.get_saatler())

    def _randevu_al(self):
        h_id = self.combo_hasta.currentData()
        d_id = self.combo_doktor.currentData()
        saat = self.combo_saat.currentText()
        tarih = self.r_tarih.date().toString("dd.MM.yyyy")

        if not h_id or not d_id or not saat: return

        ok, msg = self.merkez.randevu_olustur_merkez(h_id, d_id, tarih, saat)
        if ok:
            QMessageBox.information(self, "Başarılı", msg)
            self.refresh()
            self.dashboard.refresh()
            if hasattr(self.parentWidget().parentWidget(), 'p_gunluk'):
                self.parentWidget().parentWidget().p_gunluk.refresh()
        else:
            QMessageBox.warning(self, "Reddedildi", msg)

    def _randevu_iptal(self):
        secili = self.tablo.currentRow()
        if secili < 0:
            QMessageBox.warning(self, "Uyarı", "İptal edilecek randevuyu tablodan seçin.")
            return
            
        r_id = int(self.tablo.item(secili, 0).text().replace("#", ""))
        ok, msg = self.merkez.randevu_iptal_merkez(r_id)
        if ok:
            QMessageBox.information(self, "İptal İşlemi", msg)
            self.refresh()
            self.dashboard.refresh()
            if hasattr(self.parentWidget().parentWidget(), 'p_gunluk'):
                self.parentWidget().parentWidget().p_gunluk.refresh()
        else: QMessageBox.warning(self, "Hata", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for r_obj in reversed(self.merkez.get_tum_randevular()):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(f"#{r_obj.get_randevu_id()}"))
            
            durum_item = QTableWidgetItem(r_obj.get_durum())
            font = QFont(); font.setBold(True); durum_item.setFont(font)
            if r_obj.get_durum() == "Aktif": durum_item.setForeground(QColor(C['success']))
            else: durum_item.setForeground(QColor(C['danger']))
            self.tablo.setItem(r, 1, durum_item)
            
            self.tablo.setItem(r, 2, QTableWidgetItem(r_obj.get_tarih()))
            self.tablo.setItem(r, 3, QTableWidgetItem(r_obj.get_saat()))
            self.tablo.setItem(r, 4, QTableWidgetItem(r_obj.get_doktor().get_ad()))
            self.tablo.setItem(r, 5, QTableWidgetItem(r_obj.get_hasta().get_ad()))

# HOCANIN İSTEDİĞİ EK ÖZELLİK SAYFASI
class GunlukListePage(QWidget):
    def __init__(self, merkez: HastaneMerkezi):
        super().__init__()
        self.merkez = merkez
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("📋  Günlük Randevu Panosu", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QHBoxLayout(kart); klay.setContentsMargins(24,15,24,15)
        klay.addWidget(QLabel("Görüntülenecek Tarih Seçin:", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:700;background:transparent;"))
        self.tarih_sec = QDateEdit(); self.tarih_sec.setCalendarPopup(True); self.tarih_sec.setDate(QDate.currentDate()); self.tarih_sec.setStyleSheet(input_ss())
        self.tarih_sec.dateChanged.connect(self.refresh)
        klay.addWidget(self.tarih_sec)
        klay.addStretch()
        lay.addWidget(kart)

        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["Saat", "Doktor Adı", "Poliklinik", "Hasta Adı"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def refresh(self):
        secili_tarih = self.tarih_sec.date().toString("dd.MM.yyyy")
        # HOCAYA ŞOV: İstenen "gunluk_randevu_listesi" metodunu kullanıyoruz
        gunluk_liste = self.merkez.gunluk_randevu_listesi(secili_tarih)
        
        # Saat'e göre sıralama
        gunluk_liste.sort(key=lambda x: x.get_saat())

        self.tablo.setRowCount(0)
        for r_obj in gunluk_liste:
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            
            saat_item = QTableWidgetItem(r_obj.get_saat())
            font = QFont(); font.setBold(True); saat_item.setFont(font)
            saat_item.setForeground(QColor(C['accent']))
            
            self.tablo.setItem(r, 0, saat_item)
            self.tablo.setItem(r, 1, QTableWidgetItem(r_obj.get_doktor().get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(r_obj.get_doktor().get_uzmanlik()))
            self.tablo.setItem(r, 3, QTableWidgetItem(r_obj.get_hasta().get_ad()))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🏥 Proje 2 — Online Doktor Randevu Sistemi")
        self.setMinimumSize(1200, 750); self.setStyleSheet(f"QMainWindow{{background:{C['bg']};color:{C['text']};}}")

        self.merkez = HastaneMerkezi()
        self.merkez.test_verilerini_yukle()

        merkez_widget = QWidget(); merkez_widget.setStyleSheet(f"background:{C['bg']};"); self.setCentralWidget(merkez_widget)
        ana = QHBoxLayout(merkez_widget); ana.setContentsMargins(0, 0, 0, 0); ana.setSpacing(0)

        # YAN PANEL
        sidebar = QFrame(); sidebar.setFixedWidth(240); sidebar.setStyleSheet(f"background:{C['sidebar']};border-right:1px solid #1E293B;")
        sb = QVBoxLayout(sidebar); sb.setContentsMargins(0, 0, 0, 20); sb.setSpacing(0)
        
        logo = QFrame(); logo.setFixedHeight(80); logo.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C['accent']},stop:1 {C['accent2']});")
        ll = QVBoxLayout(logo); ll.setContentsMargins(20, 15, 20, 15)
        t1 = QLabel("🏥 MEDI-CONNECT"); t1.setStyleSheet("color:#FFF;font-size:18px;font-weight:900;background:transparent;")
        t2 = QLabel("Proje 2 Yönetim"); t2.setStyleSheet("color:rgba(255,255,255,0.8);font-size:12px;font-weight:700;background:transparent;")
        ll.addWidget(t1); ll.addWidget(t2); sb.addWidget(logo); sb.addSpacing(20)

        self.nav = []
        for ikon, metin in [("📊", "Klinik Özeti"), ("🩺", "Doktor & Hasta Kayıt"), ("🗓️", "Randevu İşlemleri"), ("📋", "Günlük Randevu Panosu")]:
            btn = SideBtn(ikon, metin); btn.clicked.connect(lambda _, m=metin: self._goto(m))
            sb.addWidget(btn); self.nav.append(btn)
        sb.addStretch()
        
        self.lbl_saat = QLabel(); self.lbl_saat.setAlignment(Qt.AlignCenter); self.lbl_saat.setStyleSheet(f"color:#94A3B8;font-size:12px;font-weight:700;background:transparent;")
        sb.addWidget(self.lbl_saat); ana.addWidget(sidebar)

        # İÇERİK ALANI
        icerik = QWidget(); icerik.setStyleSheet(f"background:{C['bg']};")
        il = QVBoxLayout(icerik); il.setContentsMargins(0,0,0,0); il.setSpacing(0)

        topbar = QFrame(); topbar.setFixedHeight(55); topbar.setStyleSheet(f"background:#FFFFFF;border-bottom:1px solid {C['border']};")
        tl = QHBoxLayout(topbar); tl.setContentsMargins(30, 0, 30, 0)
        self.lbl_page = QLabel("KLİNİK ÖZETİ"); self.lbl_page.setStyleSheet(f"color:{C['text']};font-size:15px;font-weight:800;background:transparent;")
        tl.addWidget(self.lbl_page); tl.addStretch()
        tl.addWidget(QLabel("👤 Yönetici", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        il.addWidget(topbar)

        self.stack = QStackedWidget(); self.stack.setStyleSheet(f"background:{C['bg']};")
        self.p_dashboard = DashboardPage(self.merkez)
        self.p_kayit = KayitPage(self.merkez, self.p_dashboard)
        self.p_randevu = RandevuIslemleriPage(self.merkez, self.p_dashboard)
        self.p_gunluk = GunlukListePage(self.merkez)
        
        for p in [self.p_dashboard, self.p_kayit, self.p_randevu, self.p_gunluk]: self.stack.addWidget(p)
        il.addWidget(self.stack); ana.addWidget(icerik)

        self._goto("Klinik Özeti")
        t = QTimer(self); t.timeout.connect(lambda: self.lbl_saat.setText(datetime.now().strftime("%d.%m.%Y\n%H:%M:%S"))); t.start(1000)

    def _goto(self, sayfa):
        idx = {"Klinik Özeti": 0, "Doktor & Hasta Kayıt": 1, "Randevu İşlemleri": 2, "Günlük Randevu Panosu": 3}[sayfa]
        self.stack.setCurrentIndex(idx)
        self.lbl_page.setText(sayfa.upper())
        for i, b in enumerate(self.nav): b.setChecked(i == idx)
        
        if idx == 0: self.p_dashboard.refresh()
        if idx == 3: self.p_gunluk.refresh()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    p = QPalette()
    p.setColor(QPalette.Window, QColor(C['bg'])); p.setColor(QPalette.WindowText, QColor(C['text']))
    p.setColor(QPalette.Base, QColor(C['card'])); p.setColor(QPalette.AlternateBase, QColor(C['row_alt']))
    p.setColor(QPalette.Text, QColor(C['text'])); p.setColor(QPalette.Button, QColor(C['card']))
    p.setColor(QPalette.ButtonText, QColor(C['text'])); p.setColor(QPalette.Highlight, QColor(C['accent']))
    p.setColor(QPalette.HighlightedText, QColor("#FFF"))
    app.setPalette(p)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())