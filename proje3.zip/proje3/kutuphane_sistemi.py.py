"""
============================================================
  PROJE 3: DİJİTAL KÜTÜPHANE SİSTEMİ (Sunum Sürümü)
============================================================
Açıklama: Bu proje, kütüphane kitap ve üye yönetimini 
Nesne Tabanlı Programlama (OOP) mantığıyla sağlar.
============================================================
"""

import sys
from datetime import datetime, timedelta

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFrame,
    QStackedWidget, QHeaderView, QLineEdit, QGridLayout,
    QSpinBox, QMessageBox, QAbstractItemView, QGraphicsDropShadowEffect
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QPalette, QFont

# ============================================================
#  1. KISIM: İŞ MANTIĞI VE SINIFLAR (BACKEND)
# ============================================================

# KÜTÜPHANE SİSTEMİ İÇİN GEREKLİ SINIFLAR VE İŞ MANTIĞI
class Kitap:
    def __init__(self, kitap_id: int, ad: str, yazar: str, kategori: str):
        self.__kitap_id = kitap_id
        self.__ad = ad
        self.__yazar = yazar
        self.__kategori = kategori
        self.__durum = "Müsait" #başlangıçta kitap her zaman müsait olur

    def get_kitap_id(self) -> int: return self.__kitap_id
    def get_ad(self) -> str:       return self.__ad
    def get_yazar(self) -> str:    return self.__yazar
    def get_kategori(self) -> str: return self.__kategori
    def get_durum(self) -> str:    return self.__durum

    def kitap_durumu_degistir(self, yeni_durum: str):
        self.__durum = yeni_durum

# Diğer sınıflar (Odunc, Uye, KutuphaneMerkezi) aşağıda
class Odunc:
    def __init__(self, odunc_id: int, kitap: Kitap, uye: 'Uye'):
        self.__odunc_id = odunc_id
        self.__kitap = kitap
        self.__uye = uye
        self.__odunc_tarihi = datetime.now()
        self.__iade_tarihi = None 

    def get_odunc_id(self) -> int: return self.__odunc_id
    def get_kitap(self) -> Kitap:  return self.__kitap
    def get_uye(self) -> 'Uye':    return self.__uye
    def get_odunc_tarihi(self) -> datetime: return self.__odunc_tarihi
    def get_iade_tarihi(self):     return self.__iade_tarihi

    # Sadece test verilerinde zamanı geriye almak için gizli bir metod (Sunum için)
    def _test_icin_tarih_degistir(self, gun_farki):
        self.__odunc_tarihi -= timedelta(days=gun_farki)

    def iade_edildi_isaretle(self):
        self.__iade_tarihi = datetime.now()

# Diğer sınıflar (Uye, KutuphaneMerkezi) aşağıda
class Uye:
    def __init__(self, uye_id: int, ad: str, email: str):
        self.__uye_id = uye_id
        self.__ad = ad
        self.__email = email
        self.__aktif_oduncler = []

    def get_uye_id(self) -> int: return self.__uye_id
    def get_ad(self) -> str:     return self.__ad
    def get_email(self) -> str:  return self.__email
    def get_aktif_oduncler(self) -> list: return self.__aktif_oduncler

    def kitap_odunc_al(self, odunc_kaydi: Odunc):
        kitap = odunc_kaydi.get_kitap()
        if kitap.get_durum() == "Müsait":
            self.__aktif_oduncler.append(odunc_kaydi)
            kitap.kitap_durumu_degistir("Ödünç Verildi")
            return True, f"{kitap.get_ad()} kitabı, {self.__ad} isimli üyeye verildi."
        return False, "Kitap şu an kütüphanede değil!"

    def kitap_iade_et(self, kitap_id: int):
        for odunc in self.__aktif_oduncler:
            kitap = odunc.get_kitap()
            if kitap.get_kitap_id() == kitap_id:
                odunc.iade_edildi_isaretle()
                kitap.kitap_durumu_degistir("Müsait")
                self.__aktif_oduncler.remove(odunc)
                return True, f"{kitap.get_ad()} kütüphaneye başarıyla iade edildi."
        return False, "Bu kitap üyede bulunmuyor."


class KutuphaneMerkezi:
    def __init__(self):
        self.__kitaplar = {}
        self.__uyeler = {}
        self.__odunc_gecmisi = []
        self.__son_odunc_id = 1000

    def kitap_ekle(self, kitap: Kitap):
        if kitap.get_kitap_id() in self.__kitaplar: 
            return False, "Bu ID ile kitap zaten var."
        self.__kitaplar[kitap.get_kitap_id()] = kitap
        return True, "Kitap arşive eklendi."

    def uye_ekle(self, uye: Uye):
        if uye.get_uye_id() in self.__uyeler: 
            return False, "Bu ID ile üye zaten var."
        self.__uyeler[uye.get_uye_id()] = uye
        return True, "Üye sisteme kaydedildi."

    def get_kitaplar(self): return self.__kitaplar
    def get_uyeler(self): return self.__uyeler
    def get_oduncler(self): return self.__odunc_gecmisi

    def yeni_odunc_islemi(self, uye_id: int, kitap_id: int):
        uye = self.__uyeler.get(uye_id)
        kitap = self.__kitaplar.get(kitap_id)
        
        if not uye: return False, "Üye bulunamadı!"
        if not kitap: return False, "Kitap bulunamadı!"
        
        yeni_odunc = Odunc(self.__son_odunc_id, kitap, uye)
        ok, msg = uye.kitap_odunc_al(yeni_odunc)
        
        if ok:
            self.__odunc_gecmisi.append(yeni_odunc)
            self.__son_odunc_id += 1
        return ok, msg

    def iade_islemi(self, uye_id: int, kitap_id: int):
        uye = self.__uyeler.get(uye_id)
        if not uye: return False, "Üye bulunamadı!"
        return uye.kitap_iade_et(kitap_id)

    # SUNUM İÇİN SAHTE VERİ ÜRETİCİ
    def sahte_verileri_yukle(self):
        # 1. Grup arkadaşlarını üye yapalım
        self.uye_ekle(Uye(1, "Halit Güneş", "halit@grup.com"))
        self.uye_ekle(Uye(2, "Alp Akcelep", "alp@grup.com"))
        self.uye_ekle(Uye(3, "Yiğit Gümüş", "yigit@grup.com"))
        self.uye_ekle(Uye(4, "Berkkan Kahraman", "berkkan@grup.com"))

        # 2. Popüler Kitaplar Ekleyelim
        self.kitap_ekle(Kitap(101, "Python OOP Mimarisi", "Fırat Özgül", "Eğitim"))
        self.kitap_ekle(Kitap(102, "1984", "George Orwell", "Distopya"))
        self.kitap_ekle(Kitap(103, "Suç ve Ceza", "Dostoyevski", "Klasik Roman"))
        self.kitap_ekle(Kitap(104, "Sefiller", "Victor Hugo", "Klasik Roman"))
        self.kitap_ekle(Kitap(105, "Algoritmalara Giriş", "T. Cormen", "Mühendislik"))

        # 3. Ödünç ve İade Senaryoları (Dashboard dolsun diye)
        self.yeni_odunc_islemi(1, 102) # Halit 1984'ü aldı
        self.__odunc_gecmisi[-1]._test_icin_tarih_degistir(2) # 2 gün önce almış gibi göster

        self.yeni_odunc_islemi(2, 105) # Alp Algoritmaları aldı
        self.__odunc_gecmisi[-1]._test_icin_tarih_degistir(1) # 1 gün önce

        self.yeni_odunc_islemi(3, 101) # Yiğit Python kitabını aldı...
        self.iade_islemi(3, 101)       # ...ve okuyup iade etti.


# ============================================================
#  2. KISIM: ARAYÜZ (GUI) - GÖZ YORMAYAN MODERN TEMA
# ============================================================

C = {
    "bg":        "#1E1E2E",  
    "sidebar":   "#181825",  
    "card":      "#313244",  
    "border":    "#45475A",  
    "accent":    "#89B4FA",  
    "accent2":   "#74C7EC",  
    "success":   "#A6E3A1",  
    "warning":   "#F9E2AF",  
    "danger":    "#F38BA8",  
    "text":      "#CDD6F4",  
    "text_sub":  "#A6ADC8",  
    "text_dim":  "#7F849C",  
    "row_alt":   "#25253A",  
    "row_sel":   "#3B4252",  
    "input_bg":  "#11111B",  
}

# Stil Fonksiyonları (Tekrar Kullanılabilir CSS Parçaları)
def card_ss(): return f"background:{C['card']};border:1px solid {C['border']};border-radius:12px;"
def btn_primary_ss(): return f"QPushButton{{background:{C['accent']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:{C['accent2']};}}"
def btn_success_ss(): return f"QPushButton{{background:{C['success']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#87D481;}}"
def btn_warning_ss(): return f"QPushButton{{background:{C['warning']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#EBD399;}}"
def input_ss(): return f"QLineEdit,QSpinBox{{background:{C['input_bg']};color:{C['text']};border:1px solid {C['border']};border-radius:8px;padding:8px 12px;font-size:13px;}}"


TABLE_SS = f"""
    QTableWidget{{background:{C['card']};color:{C['text']};border:none;gridline-color:{C['border']};font-size:13px;selection-background-color:{C['row_sel']};outline:none;alternate-background-color:{C['row_alt']};}}
    QTableWidget::item{{padding:10px 14px;border-bottom:1px solid {C['border']};}}
    QHeaderView::section{{background:{C['sidebar']};color:{C['accent']};padding:10px 14px;border:none;border-bottom:2px solid {C['accent']};font-size:12px;font-weight:800;letter-spacing:0.5px;}}
"""


def shadow(widget):
    fx = QGraphicsDropShadowEffect(widget)
    fx.setBlurRadius(20); fx.setColor(QColor(0, 0, 0, 60)); fx.setOffset(0, 4)
    widget.setGraphicsEffect(fx)


class KpiCard(QFrame):  #bu şu işe yarar: Dashboard'daki KPI kartları için tek bir sınıf oluşturduk. Başlık, değer, alt metin ve renk alarak şık kartlar yapmamızı sağlar. Ayrıca guncelle() metodu ile değeri dinamik olarak değiştirebiliriz.
    def __init__(self, baslik, deger, alt, renk):
        super().__init__()
        self.setFixedHeight(114)
        self.setStyleSheet(f"QFrame{{background:{C['card']};border:1px solid {C['border']};border-radius:12px;border-left:5px solid {renk};}}")
        shadow(self)
        lay = QVBoxLayout(self); lay.setContentsMargins(20, 15, 20, 15); lay.setSpacing(4)
        lbl_t = QLabel(baslik.upper()); lbl_t.setStyleSheet(f"color:{C['text_sub']};font-size:11px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        self.lbl_v = QLabel(str(deger)); self.lbl_v.setStyleSheet(f"color:{renk};font-size:30px;font-weight:800;background:transparent;border:none;")
        lbl_a = QLabel(alt); lbl_a.setStyleSheet(f"color:{C['text_dim']};font-size:12px;background:transparent;border:none;")
        lay.addWidget(lbl_t); lay.addWidget(self.lbl_v); lay.addWidget(lbl_a)
    def guncelle(self, val): self.lbl_v.setText(str(val))

class SideBtn(QPushButton): # Sol menüdeki butonlar için tek bir sınıf oluşturduk. İkon ve metin alarak şık, aktif/pasif görünümlü butonlar yapmamızı sağlar. setChecked() metodu ile aktif durumunu değiştirebiliriz.
    def __init__(self, ikon, metin):
        super().__init__(f"  {ikon}  {metin}")
        self.setCheckable(True); self.setFixedHeight(50); self.setCursor(Qt.PointingHandCursor)
        self._refresh(False)
    def _refresh(self, aktif):
        if aktif: self.setStyleSheet(f"QPushButton{{background:rgba(137, 180, 250, 0.1);color:{C['accent']};border:none;border-left:4px solid {C['accent']};border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:800;}}")
        else: self.setStyleSheet(f"QPushButton{{background:transparent;color:{C['text_sub']};border:none;border-left:4px solid transparent;border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:600;}}QPushButton:hover{{background:{C['card']};color:{C['text']};border-left:4px solid {C['border']};}}")
    def setChecked(self, v): super().setChecked(v); self._refresh(v)

class DashboardPage(QWidget): # Dashboard ana sayfası, KPI kartları ve canlı işlem geçmişi içerir
    def __init__(self, kutuphane: KutuphaneMerkezi):
        super().__init__()
        self.kutuphane = kutuphane
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lbl = QLabel("📊  Sistem Özeti")
        lbl.setStyleSheet(f"color:{C['text']};font-size:24px;font-weight:800;")
        lay.addWidget(lbl)

        # ÜST KPI KARTLARI
        self.kpi_row = QHBoxLayout(); lay.addLayout(self.kpi_row)
        self.c1 = KpiCard("Toplam Kitap", 0, "Kütüphane Arşivi", C['accent'])
        self.c2 = KpiCard("Aktif Üyeler", 0, "Sisteme Kayıtlı Okur", C['success'])
        self.c3 = KpiCard("Ödünç Verilen", 0, "Teslim Edilmeyenler", C['warning'])
        for c in [self.c1, self.c2, self.c3]: self.kpi_row.addWidget(c)
        
        # ALT CANLI İŞLEM GEÇMİŞİ (Hocanın Dikkatini Çekecek Kısım)
        lay.addWidget(QLabel("Son Gerçekleşen İşlemler (Canlı Log)", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:15px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["İşlem Durumu", "İşlem No", "Okuyucu (Üye)", "Eser Adı", "İşlem Tarihi"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)

    def refresh(self):
        # KPI Kartlarını Güncelle
        kitaplar = self.kutuphane.get_kitaplar().values()
        uyeler = self.kutuphane.get_uyeler().values()
        self.c1.guncelle(len(kitaplar))
        self.c2.guncelle(len(uyeler))
        self.c3.guncelle(sum(1 for k in kitaplar if k.get_durum() == "Ödünç Verildi"))

        # İşlem Tablosunu Güncelle (Son 10 İşlemi Ters Sırada Göster)
        self.tablo.setRowCount(0)
        oduncler = self.kutuphane.get_oduncler()
        
        for o in reversed(oduncler[-10:]):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            
            # Durum Sütunu (Görsel Zenginlik İçin)
            iade_edildi_mi = o.get_iade_tarihi() is not None
            durum_txt = "🟢 İade Edildi" if iade_edildi_mi else "🔴 Kitap Dışarıda"
            item_durum = QTableWidgetItem(durum_txt)
            item_durum.setForeground(QColor(C['success'] if iade_edildi_mi else C['warning']))
            font = QFont(); font.setBold(True); item_durum.setFont(font)
            
            self.tablo.setItem(r, 0, item_durum)
            self.tablo.setItem(r, 1, QTableWidgetItem(f"#{o.get_odunc_id()}"))
            self.tablo.setItem(r, 2, QTableWidgetItem(o.get_uye().get_ad()))
            self.tablo.setItem(r, 3, QTableWidgetItem(o.get_kitap().get_ad()))
            
            # Hangi tarih daha yeniyse onu göster
            tarih_obj = o.get_iade_tarihi() if iade_edildi_mi else o.get_odunc_tarihi()
            self.tablo.setItem(r, 4, QTableWidgetItem(tarih_obj.strftime("%d.%m.%Y - %H:%M")))

class KitapYonetimPage(QWidget): # Kitap ekleme ve envanter yönetimi sayfası 
    def __init__(self, kutuphane: KutuphaneMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.kutuphane = kutuphane; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("📚  Kitap Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Yeni Kitap Ekle", styleSheet=f"color:{C['accent']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QGridLayout()
        self.k_id = QSpinBox(); self.k_id.setRange(1, 9999)
        self.k_ad = QLineEdit(); self.k_ad.setPlaceholderText("Kitap Adı")
        self.k_yazar = QLineEdit(); self.k_yazar.setPlaceholderText("Yazar Adı")
        self.k_kat = QLineEdit(); self.k_kat.setPlaceholderText("Kategori")
        for w in [self.k_id, self.k_ad, self.k_yazar, self.k_kat]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Kitap ID", styleSheet=lbl_style), 0, 0); g.addWidget(self.k_id, 1, 0)
        g.addWidget(QLabel("Kitap Adı", styleSheet=lbl_style), 0, 1); g.addWidget(self.k_ad, 1, 1)
        g.addWidget(QLabel("Yazar", styleSheet=lbl_style), 0, 2); g.addWidget(self.k_yazar, 1, 2)
        g.addWidget(QLabel("Kategori", styleSheet=lbl_style), 0, 3); g.addWidget(self.k_kat, 1, 3)
        klay.addLayout(g)
        
        btn_kitap = QPushButton("＋ Kitap Kaydet"); btn_kitap.setStyleSheet(btn_primary_ss()); btn_kitap.clicked.connect(self._kitap_ekle)
        klay.addWidget(btn_kitap, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Kütüphane Envanteri", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["ID", "Kitap Adı", "Yazar", "Kategori", "Mevcut Durum"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _kitap_ekle(self):
        if not self.k_ad.text().strip():
            QMessageBox.warning(self, "Hata", "Kitap adı boş olamaz!")
            return
        k = Kitap(self.k_id.value(), self.k_ad.text(), self.k_yazar.text(), self.k_kat.text())
        ok, msg = self.kutuphane.kitap_ekle(k)
        if ok: 
            self.k_ad.clear(); self.k_yazar.clear(); self.k_kat.clear()
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for k in self.kutuphane.get_kitaplar().values():
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(k.get_kitap_id())))
            self.tablo.setItem(r, 1, QTableWidgetItem(k.get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(k.get_yazar()))
            self.tablo.setItem(r, 3, QTableWidgetItem(k.get_kategori()))
            
            durum_item = QTableWidgetItem(k.get_durum())
            font = QFont(); font.setBold(True); durum_item.setFont(font)
            if k.get_durum() == "Müsait": durum_item.setForeground(QColor(C['success']))
            else: durum_item.setForeground(QColor(C['warning']))
            self.tablo.setItem(r, 4, durum_item)

class UyeYonetimPage(QWidget):
    def __init__(self, kutuphane: KutuphaneMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.kutuphane = kutuphane; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("👥  Üye Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Yeni Üye Kaydı", styleSheet=f"color:{C['success']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QHBoxLayout()
        self.u_id = QSpinBox(); self.u_id.setRange(1, 9999)
        self.u_ad = QLineEdit(); self.u_ad.setPlaceholderText("Ad Soyad")
        self.u_email = QLineEdit(); self.u_email.setPlaceholderText("E-posta Adresi")
        for w in [self.u_id, self.u_ad, self.u_email]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Üye ID:", styleSheet=lbl_style)); g.addWidget(self.u_id)
        g.addWidget(QLabel("Ad Soyad:", styleSheet=lbl_style)); g.addWidget(self.u_ad)
        g.addWidget(QLabel("Email:", styleSheet=lbl_style)); g.addWidget(self.u_email)
        klay.addLayout(g)
        
        btn_uye = QPushButton("＋ Üye Kaydet"); btn_uye.setStyleSheet(btn_success_ss()); btn_uye.clicked.connect(self._uye_ekle)
        klay.addWidget(btn_uye, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Aktif Üyeler Listesi", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["ID", "Üye Adı", "Email Adresi", "Elindeki Kitap Sayısı"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _uye_ekle(self):
        if not self.u_ad.text().strip():
            QMessageBox.warning(self, "Hata", "Ad Soyad boş olamaz!")
            return
        u = Uye(self.u_id.value(), self.u_ad.text(), self.u_email.text())
        ok, msg = self.kutuphane.uye_ekle(u)
        if ok: 
            self.u_ad.clear(); self.u_email.clear()
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for u in self.kutuphane.get_uyeler().values():
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(u.get_uye_id())))
            self.tablo.setItem(r, 1, QTableWidgetItem(u.get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(u.get_email()))
            
            odunc_sayisi = len(u.get_aktif_oduncler())
            item = QTableWidgetItem(f"{odunc_sayisi} Adet Okuyor")
            if odunc_sayisi > 0: 
                item.setForeground(QColor(C['warning']))
                font = QFont(); font.setBold(True); item.setFont(font)
            self.tablo.setItem(r, 3, item)

# Ödünç Verme ve İade Alma Sayfası
class OduncPage(QWidget):
    def __init__(self, kutuphane: KutuphaneMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.kutuphane = kutuphane; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🔄  Ödünç & İade İşlemleri", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QHBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        
        self.o_uye = QSpinBox(); self.o_uye.setRange(1, 9999); self.o_uye.setStyleSheet(input_ss())
        self.o_kitap = QSpinBox(); self.o_kitap.setRange(1, 9999); self.o_kitap.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:13px;font-weight:800;background:transparent;"
        klay.addWidget(QLabel("Üye ID:", styleSheet=lbl_style)); klay.addWidget(self.o_uye)
        klay.addWidget(QLabel("Kitap ID:", styleSheet=lbl_style)); klay.addWidget(self.o_kitap)
        
        btn_al = QPushButton("▼ Ödünç Ver"); btn_al.setStyleSheet(btn_warning_ss()); btn_al.clicked.connect(self._odunc_ver)
        btn_iade = QPushButton("▲ İade Al"); btn_iade.setStyleSheet(btn_primary_ss()); btn_iade.clicked.connect(self._iade_al)
        
        klay.addWidget(btn_al); klay.addWidget(btn_iade); klay.addStretch()
        lay.addWidget(kart)

        lay.addWidget(QLabel("Tüm İşlem Kayıtları", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["İşlem No", "Üye Adı", "Kitap", "Veriliş Tarihi", "İade Tarihi"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _odunc_ver(self):
        ok, msg = self.kutuphane.yeni_odunc_islemi(self.o_uye.value(), self.o_kitap.value())
        QMessageBox.information(self, "İşlem Sonucu", msg)
        if ok: self._tum_sayfalari_guncelle()

    def _iade_al(self):
        ok, msg = self.kutuphane.iade_islemi(self.o_uye.value(), self.o_kitap.value())
        QMessageBox.information(self, "İşlem Sonucu", msg)
        if ok: self._tum_sayfalari_guncelle()

    def _tum_sayfalari_guncelle(self):
        self.refresh()
        self.dashboard.refresh()
        if hasattr(self.parentWidget().parentWidget(), 'p_kitap'):
            self.parentWidget().parentWidget().p_kitap.refresh()
        if hasattr(self.parentWidget().parentWidget(), 'p_uye'):
            self.parentWidget().parentWidget().p_uye.refresh()

    def refresh(self):
        self.tablo.setRowCount(0)
        for o in reversed(self.kutuphane.get_oduncler()):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(f"#{o.get_odunc_id()}"))
            self.tablo.setItem(r, 1, QTableWidgetItem(o.get_uye().get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(o.get_kitap().get_ad()))
            self.tablo.setItem(r, 3, QTableWidgetItem(o.get_odunc_tarihi().strftime("%d.%m.%Y %H:%M")))
            
            iade_tarih = "⏳ Okunuyor"
            if o.get_iade_tarihi() is not None:
                iade_tarih = o.get_iade_tarihi().strftime("%d.%m.%Y %H:%M")
                
            item_iade = QTableWidgetItem(iade_tarih)
            if o.get_iade_tarihi() is None: item_iade.setForeground(QColor(C['warning']))
            else: item_iade.setForeground(QColor(C['success']))
            self.tablo.setItem(r, 4, item_iade)
 
#============================================================
#  3. KISIM: ANA PENCERE VE GEZİNME
#============================================================
class MainWindow(QMainWindow): 
    def __init__(self):
        super().__init__()
        self.setWindowTitle("📚 Proje 3 — Dijital Kütüphane Otomasyonu")
        self.setMinimumSize(1200, 750); self.setStyleSheet(f"QMainWindow{{background:{C['bg']};color:{C['text']};}}")

        self.kutuphane = KutuphaneMerkezi()
        self.kutuphane.sahte_verileri_yukle() # Sunum İçin Veriler Yüklendi

        merkez = QWidget(); merkez.setStyleSheet(f"background:{C['bg']};"); self.setCentralWidget(merkez)
        ana = QHBoxLayout(merkez); ana.setContentsMargins(0, 0, 0, 0); ana.setSpacing(0)

        # YAN PANEL
        sidebar = QFrame(); sidebar.setFixedWidth(240); sidebar.setStyleSheet(f"background:{C['sidebar']};border-right:1px solid {C['border']};")
        sb = QVBoxLayout(sidebar); sb.setContentsMargins(0, 0, 0, 20); sb.setSpacing(0)
        
        logo = QFrame(); logo.setFixedHeight(80); logo.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C['accent']},stop:1 {C['accent2']});")
        ll = QVBoxLayout(logo); ll.setContentsMargins(20, 15, 20, 15)
        t1 = QLabel("📚 Kütüphane"); t1.setStyleSheet("color:#11111B;font-size:18px;font-weight:900;background:transparent;")
        t2 = QLabel("Proje 3"); t2.setStyleSheet("color:rgba(17,17,27,0.7);font-size:12px;font-weight:800;background:transparent;")
        ll.addWidget(t1); ll.addWidget(t2); sb.addWidget(logo); sb.addSpacing(20)

        self.nav = []
        for ikon, metin in [("📊", "Özet Ekranı"), ("📚", "Kitap Yönetimi"), ("👥", "Üye Yönetimi"), ("🔄", "Ödünç / İade")]:
            btn = SideBtn(ikon, metin); btn.clicked.connect(lambda _, m=metin: self._goto(m))
            sb.addWidget(btn); self.nav.append(btn)
        sb.addStretch()
        
        self.lbl_saat = QLabel(); self.lbl_saat.setAlignment(Qt.AlignCenter); self.lbl_saat.setStyleSheet(f"color:{C['text_dim']};font-size:12px;font-weight:800;background:transparent;")
        sb.addWidget(self.lbl_saat); ana.addWidget(sidebar)

        # İÇERİK ALANI
        icerik = QWidget(); icerik.setStyleSheet(f"background:{C['bg']};")
        il = QVBoxLayout(icerik); il.setContentsMargins(0,0,0,0); il.setSpacing(0)

        topbar = QFrame(); topbar.setFixedHeight(55); topbar.setStyleSheet(f"background:{C['sidebar']};border-bottom:1px solid {C['border']};")
        tl = QHBoxLayout(topbar); tl.setContentsMargins(30, 0, 30, 0)
        self.lbl_page = QLabel("Özet Ekranı"); self.lbl_page.setStyleSheet(f"color:{C['text']};font-size:15px;font-weight:800;background:transparent;")
        tl.addWidget(self.lbl_page); tl.addStretch()
        tl.addWidget(QLabel("👤 Yönetici", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        il.addWidget(topbar)

        self.stack = QStackedWidget(); self.stack.setStyleSheet(f"background:{C['bg']};")
        self.p_dashboard = DashboardPage(self.kutuphane)
        self.p_kitap = KitapYonetimPage(self.kutuphane, self.p_dashboard)
        self.p_uye = UyeYonetimPage(self.kutuphane, self.p_dashboard)
        self.p_odunc = OduncPage(self.kutuphane, self.p_dashboard)
        
        for p in [self.p_dashboard, self.p_kitap, self.p_uye, self.p_odunc]: self.stack.addWidget(p)
        il.addWidget(self.stack); ana.addWidget(icerik)

        self._goto("Özet Ekranı")
        t = QTimer(self); t.timeout.connect(lambda: self.lbl_saat.setText(datetime.now().strftime("%d.%m.%Y\n%H:%M:%S"))); t.start(1000)

    def _goto(self, sayfa):
        idx = {"Özet Ekranı": 0, "Kitap Yönetimi": 1, "Üye Yönetimi": 2, "Ödünç / İade": 3}[sayfa]
        self.stack.setCurrentIndex(idx)
        self.lbl_page.setText(sayfa.upper())
        for i, b in enumerate(self.nav): b.setChecked(i == idx)
        
        if idx == 0: self.p_dashboard.refresh()
        elif idx == 1: self.p_kitap.refresh()
        elif idx == 2: self.p_uye.refresh()
        elif idx == 3: self.p_odunc.refresh()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    p = QPalette()
    p.setColor(QPalette.Window, QColor(C['bg'])); p.setColor(QPalette.WindowText, QColor(C['text']))
    p.setColor(QPalette.Base, QColor(C['card'])); p.setColor(QPalette.AlternateBase, QColor(C['row_alt']))
    p.setColor(QPalette.Text, QColor(C['text'])); p.setColor(QPalette.Button, QColor(C['card']))
    p.setColor(QPalette.ButtonText, QColor(C['text'])); p.setColor(QPalette.Highlight, QColor(C['accent']))
    p.setColor(QPalette.HighlightedText, QColor("#11111B"))
    app.setPalette(p)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())