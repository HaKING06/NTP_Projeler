"""
============================================================
  PROJE 1: ARAÇ PAYLAŞIM SİSTEMİ (Car Sharing System)
============================================================
Açıklama: Bu proje, araçların farklı kullanıcılar tarafından 
kiralanabildiği sistemi OOP mantığıyla ve modern bir arayüzle sağlar.
============================================================
"""

import sys
from datetime import datetime, timedelta

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFrame,
    QStackedWidget, QHeaderView, QLineEdit, QGridLayout,
    QSpinBox, QMessageBox, QAbstractItemView, QGraphicsDropShadowEffect
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QPalette, QFont

# ============================================================
#  1. KISIM: İŞ MANTIĞI VE SINIFLAR (BACKEND)
# ============================================================

class Arac:
    def __init__(self, arac_id: int, marka: str, model: str, kilometre: int):
        self.__arac_id = arac_id
        self.__marka = marka
        self.__model = model
        self.__kilometre = kilometre
        self.__musait_mi = True # Başlangıçta araç her zaman müsaittir

    def get_arac_id(self) -> int: return self.__arac_id
    def get_marka(self) -> str:   return self.__marka
    def get_model(self) -> str:   return self.__model
    def get_kilometre(self) -> int: return self.__kilometre
    def get_musait_mi(self) -> bool: return self.__musait_mi

    def arac_durumu_guncelle(self, durum: bool):
        self.__musait_mi = durum

    def kilometre_guncelle(self, yeni_kilometre: int):
        if yeni_kilometre > self.__kilometre:
            self.__kilometre = yeni_kilometre


class Kiralama:
    def __init__(self, kiralama_id: int, arac: Arac, kullanici: 'Kullanici'):
        self.__kiralama_id = kiralama_id
        self.__arac = arac
        self.__kullanici = kullanici
        self.__baslangic_saati = None
        self.__bitis_saati = None

    def get_kiralama_id(self) -> int: return self.__kiralama_id
    def get_arac(self) -> Arac:  return self.__arac
    def get_kullanici(self) -> 'Kullanici': return self.__kullanici
    def get_baslangic_saati(self) -> datetime: return self.__baslangic_saati
    def get_bitis_saati(self): return self.__bitis_saati

    def kiralama_baslat(self):
        self.__baslangic_saati = datetime.now()

    def kiralama_bitir(self):
        self.__bitis_saati = datetime.now()

    def kiralama_bilgisi(self) -> str:
        durum = "Devam Ediyor" if self.__bitis_saati is None else "Tamamlandı"
        baslangic = self.__baslangic_saati.strftime("%d.%m.%Y %H:%M") if self.__baslangic_saati else "Başlamadı"
        return f"Kiralama No: {self.__kiralama_id} | Araç: {self.__arac.get_marka()} {self.__arac.get_model()} | Sürücü: {self.__kullanici.get_ad()} | Başlangıç: {baslangic} | Durum: {durum}"

    # Sadece test verilerinde zamanı geriye almak için gizli bir metod (Sunum için)
    def _test_icin_tarih_degistir(self, gun_farki):
        if self.__baslangic_saati:
            self.__baslangic_saati -= timedelta(days=gun_farki)


class Kullanici:
    def __init__(self, kullanici_id: int, ad: str, ehliyet_no: str):
        self.__kullanici_id = kullanici_id
        self.__ad = ad
        self.__ehliyet_no = ehliyet_no
        self.__gecmis_kiralamalar = []
        self.__aktif_kiralamalar = []

    def get_kullanici_id(self) -> int: return self.__kullanici_id
    def get_ad(self) -> str:     return self.__ad
    def get_ehliyet_no(self) -> str:  return self.__ehliyet_no
    def get_aktif_kiralamalar(self) -> list: return self.__aktif_kiralamalar

    def kiralama_gecmisi(self) -> list:
        # Hem bitmiş hem devam eden tüm kiralamaları döndürür
        return self.__gecmis_kiralamalar + self.__aktif_kiralamalar

    def arac_kirala(self, kiralama: Kiralama):
        arac = kiralama.get_arac()
        if arac.get_musait_mi():
            kiralama.kiralama_baslat()
            self.__aktif_kiralamalar.append(kiralama)
            arac.arac_durumu_guncelle(False)
            return True, f"{arac.get_marka()} {arac.get_model()} aracı, {self.__ad} tarafından kiralandı."
        return False, "Araç şu an kullanımda!"

    def arac_teslim_et(self, arac_id: int, yeni_kilometre: int):
        for kiralama in self.__aktif_kiralamalar:
            arac = kiralama.get_arac()
            if arac.get_arac_id() == arac_id:
                kiralama.kiralama_bitir()
                arac.kilometre_guncelle(yeni_kilometre)
                arac.arac_durumu_guncelle(True)
                self.__aktif_kiralamalar.remove(kiralama)
                self.__gecmis_kiralamalar.append(kiralama)
                return True, f"Araç başarıyla teslim edildi. Güncel KM: {arac.get_kilometre()}"
        return False, "Bu araç kullanıcıda bulunmuyor."


class AracPaylasimMerkezi:
    def __init__(self):
        self.__araclar = {}
        self.__kullanicilar = {}
        self.__kiralama_gecmisi = []
        self.__son_kiralama_id = 5000

    def arac_ekle(self, arac: Arac):
        if arac.get_arac_id() in self.__araclar: 
            return False, "Bu ID ile araç zaten var."
        self.__araclar[arac.get_arac_id()] = arac
        return True, "Araç filoya eklendi."

    def kullanici_ekle(self, kullanici: Kullanici):
        if kullanici.get_kullanici_id() in self.__kullanicilar: 
            return False, "Bu ID ile kullanıcı zaten var."
        self.__kullanicilar[kullanici.get_kullanici_id()] = kullanici
        return True, "Kullanıcı sisteme kaydedildi."

    def get_araclar(self): return self.__araclar
    def get_kullanicilar(self): return self.__kullanicilar
    def get_kiralamalar(self): return self.__kiralama_gecmisi

    def yeni_kiralama_islemi(self, kullanici_id: int, arac_id: int):
        kullanici = self.__kullanicilar.get(kullanici_id)
        arac = self.__araclar.get(arac_id)
        
        if not kullanici: return False, "Kullanıcı bulunamadı!"
        if not arac: return False, "Araç bulunamadı!"
        
        yeni_kiralama = Kiralama(self.__son_kiralama_id, arac, kullanici)
        ok, msg = kullanici.arac_kirala(yeni_kiralama)
        
        if ok:
            self.__kiralama_gecmisi.append(yeni_kiralama)
            self.__son_kiralama_id += 1
        return ok, msg

    def teslim_islemi(self, kullanici_id: int, arac_id: int, yeni_km: int):
        kullanici = self.__kullanicilar.get(kullanici_id)
        if not kullanici: return False, "Kullanıcı bulunamadı!"
        return kullanici.arac_teslim_et(arac_id, yeni_km)

    # SUNUM İÇİN SAHTE VERİ ÜRETİCİ
    def sahte_verileri_yukle(self):
        # 1. Kullanıcıları ekleyelim
        self.kullanici_ekle(Kullanici(1, "Berkkan Kahraman", "EHL-98765"))
        self.kullanici_ekle(Kullanici(2, "Halit Güneş", "EHL-12345"))
        self.kullanici_ekle(Kullanici(3, "Alp Akcelep", "EHL-11223"))
        self.kullanici_ekle(Kullanici(4, "Yiğit Gümüş", "EHL-44556"))

        # 2. Filo Araçları Ekleyelim
        self.arac_ekle(Arac(101, "Renault", "Clio", 45000))
        self.arac_ekle(Arac(102, "Fiat", "Egea", 62000))
        self.arac_ekle(Arac(103, "Toyota", "Corolla", 15000))
        self.arac_ekle(Arac(104, "Honda", "Civic", 22000))
        self.arac_ekle(Arac(105, "Ford", "Focus", 85000))

        # 3. Kiralama ve Teslim Senaryoları
        self.yeni_kiralama_islemi(1, 103) # Berkkan Corolla'yı kiraladı
        self.__kiralama_gecmisi[-1]._test_icin_tarih_degistir(2) # 2 gün önce

        self.yeni_kiralama_islemi(2, 101) # Halit Clio'yu kiraladı
        self.__kiralama_gecmisi[-1]._test_icin_tarih_degistir(1)

        self.yeni_kiralama_islemi(3, 105) # Alp Focus'u kiraladı...
        self.teslim_islemi(3, 105, 85200) # ...ve 200 km yaparak teslim etti.


# ============================================================
#  2. KISIM: ARAYÜZ (GUI) - GÖZ YORMAYAN MODERN TEMA
# ============================================================

C = {
    "bg":        "#1E1E2E",  
    "sidebar":   "#181825",  
    "card":      "#313244",  
    "border":    "#45475A",  
    "accent":    "#89B4FA",  
    "accent2":   "#74C7EC",  
    "success":   "#A6E3A1",  
    "warning":   "#F9E2AF",  
    "danger":    "#F38BA8",  
    "text":      "#CDD6F4",  
    "text_sub":  "#A6ADC8",  
    "text_dim":  "#7F849C",  
    "row_alt":   "#25253A",  
    "row_sel":   "#3B4252",  
    "input_bg":  "#11111B",  
}

def card_ss(): return f"background:{C['card']};border:1px solid {C['border']};border-radius:12px;"
def btn_primary_ss(): return f"QPushButton{{background:{C['accent']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:{C['accent2']};}}"
def btn_success_ss(): return f"QPushButton{{background:{C['success']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#87D481;}}"
def btn_warning_ss(): return f"QPushButton{{background:{C['warning']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#EBD399;}}"
def input_ss(): return f"QLineEdit,QSpinBox{{background:{C['input_bg']};color:{C['text']};border:1px solid {C['border']};border-radius:8px;padding:8px 12px;font-size:13px;}}"

TABLE_SS = f"""
    QTableWidget{{background:{C['card']};color:{C['text']};border:none;gridline-color:{C['border']};font-size:13px;selection-background-color:{C['row_sel']};outline:none;alternate-background-color:{C['row_alt']};}}
    QTableWidget::item{{padding:10px 14px;border-bottom:1px solid {C['border']};}}
    QHeaderView::section{{background:{C['sidebar']};color:{C['accent']};padding:10px 14px;border:none;border-bottom:2px solid {C['accent']};font-size:12px;font-weight:800;letter-spacing:0.5px;}}
"""

def shadow(widget):
    fx = QGraphicsDropShadowEffect(widget)
    fx.setBlurRadius(20); fx.setColor(QColor(0, 0, 0, 60)); fx.setOffset(0, 4)
    widget.setGraphicsEffect(fx)


class KpiCard(QFrame):
    def __init__(self, baslik, deger, alt, renk):
        super().__init__()
        self.setFixedHeight(114)
        self.setStyleSheet(f"QFrame{{background:{C['card']};border:1px solid {C['border']};border-radius:12px;border-left:5px solid {renk};}}")
        shadow(self)
        lay = QVBoxLayout(self); lay.setContentsMargins(20, 15, 20, 15); lay.setSpacing(4)
        lbl_t = QLabel(baslik.upper()); lbl_t.setStyleSheet(f"color:{C['text_sub']};font-size:11px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        self.lbl_v = QLabel(str(deger)); self.lbl_v.setStyleSheet(f"color:{renk};font-size:30px;font-weight:800;background:transparent;border:none;")
        lbl_a = QLabel(alt); lbl_a.setStyleSheet(f"color:{C['text_dim']};font-size:12px;background:transparent;border:none;")
        lay.addWidget(lbl_t); lay.addWidget(self.lbl_v); lay.addWidget(lbl_a)
    def guncelle(self, val): self.lbl_v.setText(str(val))

class SideBtn(QPushButton):
    def __init__(self, ikon, metin):
        super().__init__(f"  {ikon}  {metin}")
        self.setCheckable(True); self.setFixedHeight(50); self.setCursor(Qt.PointingHandCursor)
        self._refresh(False)
    def _refresh(self, aktif):
        if aktif: self.setStyleSheet(f"QPushButton{{background:rgba(137, 180, 250, 0.1);color:{C['accent']};border:none;border-left:4px solid {C['accent']};border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:800;}}")
        else: self.setStyleSheet(f"QPushButton{{background:transparent;color:{C['text_sub']};border:none;border-left:4px solid transparent;border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:600;}}QPushButton:hover{{background:{C['card']};color:{C['text']};border-left:4px solid {C['border']};}}")
    def setChecked(self, v): super().setChecked(v); self._refresh(v)

class DashboardPage(QWidget):
    def __init__(self, merkez: AracPaylasimMerkezi):
        super().__init__()
        self.merkez = merkez
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lbl = QLabel("📊  Sistem Özeti")
        lbl.setStyleSheet(f"color:{C['text']};font-size:24px;font-weight:800;")
        lay.addWidget(lbl)

        self.kpi_row = QHBoxLayout(); lay.addLayout(self.kpi_row)
        self.c1 = KpiCard("Toplam Araç", 0, "Sistemdeki Filo", C['accent'])
        self.c2 = KpiCard("Kayıtlı Kullanıcı", 0, "Aktif Sürücüler", C['success'])
        self.c3 = KpiCard("Kiradaki Araçlar", 0, "Teslim Bekleyen", C['warning'])
        for c in [self.c1, self.c2, self.c3]: self.kpi_row.addWidget(c)
        
        lay.addWidget(QLabel("Son Gerçekleşen İşlemler (Canlı Log)", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:15px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["İşlem Durumu", "İşlem No", "Sürücü", "Araç Bilgisi", "İşlem Tarihi"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)

    def refresh(self):
        araclar = self.merkez.get_araclar().values()
        kullanicilar = self.merkez.get_kullanicilar().values()
        self.c1.guncelle(len(araclar))
        self.c2.guncelle(len(kullanicilar))
        self.c3.guncelle(sum(1 for a in araclar if not a.get_musait_mi()))

        self.tablo.setRowCount(0)
        kiralamalar = self.merkez.get_kiralamalar()
        
        for k in reversed(kiralamalar[-10:]):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            
            iade_edildi_mi = k.get_bitis_saati() is not None
            durum_txt = "🟢 Teslim Edildi" if iade_edildi_mi else "🔴 Araç Kullanımda"
            item_durum = QTableWidgetItem(durum_txt)
            item_durum.setForeground(QColor(C['success'] if iade_edildi_mi else C['warning']))
            font = QFont(); font.setBold(True); item_durum.setFont(font)
            
            self.tablo.setItem(r, 0, item_durum)
            self.tablo.setItem(r, 1, QTableWidgetItem(f"#{k.get_kiralama_id()}"))
            self.tablo.setItem(r, 2, QTableWidgetItem(k.get_kullanici().get_ad()))
            self.tablo.setItem(r, 3, QTableWidgetItem(f"{k.get_arac().get_marka()} {k.get_arac().get_model()}"))
            
            tarih_obj = k.get_bitis_saati() if iade_edildi_mi else k.get_baslangic_saati()
            self.tablo.setItem(r, 4, QTableWidgetItem(tarih_obj.strftime("%d.%m.%Y - %H:%M") if tarih_obj else "-"))

class AracYonetimPage(QWidget):
    def __init__(self, merkez: AracPaylasimMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🚗  Araç Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Yeni Araç Ekle", styleSheet=f"color:{C['accent']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QGridLayout()
        self.a_id = QSpinBox(); self.a_id.setRange(1, 9999)
        self.a_marka = QLineEdit(); self.a_marka.setPlaceholderText("Marka (örn. Renault)")
        self.a_model = QLineEdit(); self.a_model.setPlaceholderText("Model (örn. Clio)")
        self.a_km = QSpinBox(); self.a_km.setRange(0, 500000); self.a_km.setSingleStep(100)
        
        for w in [self.a_id, self.a_marka, self.a_model, self.a_km]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Araç ID", styleSheet=lbl_style), 0, 0); g.addWidget(self.a_id, 1, 0)
        g.addWidget(QLabel("Marka", styleSheet=lbl_style), 0, 1); g.addWidget(self.a_marka, 1, 1)
        g.addWidget(QLabel("Model", styleSheet=lbl_style), 0, 2); g.addWidget(self.a_model, 1, 2)
        g.addWidget(QLabel("Mevcut KM", styleSheet=lbl_style), 0, 3); g.addWidget(self.a_km, 1, 3)
        klay.addLayout(g)
        
        btn_arac = QPushButton("＋ Araç Kaydet"); btn_arac.setStyleSheet(btn_primary_ss()); btn_arac.clicked.connect(self._arac_ekle)
        klay.addWidget(btn_arac, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Filo Envanteri", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["ID", "Marka / Model", "Kilometre", "Kiralama Durumu", "Sistem Bilgisi"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _arac_ekle(self):
        if not self.a_marka.text().strip() or not self.a_model.text().strip():
            QMessageBox.warning(self, "Hata", "Marka ve Model boş olamaz!")
            return
        a = Arac(self.a_id.value(), self.a_marka.text(), self.a_model.text(), self.a_km.value())
        ok, msg = self.merkez.arac_ekle(a)
        if ok: 
            self.a_marka.clear(); self.a_model.clear(); self.a_km.setValue(0)
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for a in self.merkez.get_araclar().values():
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(a.get_arac_id())))
            self.tablo.setItem(r, 1, QTableWidgetItem(f"{a.get_marka()} {a.get_model()}"))
            self.tablo.setItem(r, 2, QTableWidgetItem(f"{a.get_kilometre()} km"))
            
            durum_txt = "Müsait" if a.get_musait_mi() else "Kiralandı"
            durum_item = QTableWidgetItem(durum_txt)
            font = QFont(); font.setBold(True); durum_item.setFont(font)
            if a.get_musait_mi(): durum_item.setForeground(QColor(C['success']))
            else: durum_item.setForeground(QColor(C['warning']))
            self.tablo.setItem(r, 3, durum_item)
            self.tablo.setItem(r, 4, QTableWidgetItem("Kayıtlı"))

class KullaniciYonetimPage(QWidget):
    def __init__(self, merkez: AracPaylasimMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("👥  Kullanıcı Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Yeni Kullanıcı Kaydı", styleSheet=f"color:{C['success']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QHBoxLayout()
        self.u_id = QSpinBox(); self.u_id.setRange(1, 9999)
        self.u_ad = QLineEdit(); self.u_ad.setPlaceholderText("Ad Soyad")
        self.u_ehliyet = QLineEdit(); self.u_ehliyet.setPlaceholderText("Ehliyet No")
        for w in [self.u_id, self.u_ad, self.u_ehliyet]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Kullanıcı ID:", styleSheet=lbl_style)); g.addWidget(self.u_id)
        g.addWidget(QLabel("Ad Soyad:", styleSheet=lbl_style)); g.addWidget(self.u_ad)
        g.addWidget(QLabel("Ehliyet No:", styleSheet=lbl_style)); g.addWidget(self.u_ehliyet)
        klay.addLayout(g)
        
        btn_kullanici = QPushButton("＋ Kullanıcı Kaydet"); btn_kullanici.setStyleSheet(btn_success_ss()); btn_kullanici.clicked.connect(self._kullanici_ekle)
        klay.addWidget(btn_kullanici, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Aktif Kullanıcı Listesi", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["ID", "Ad Soyad", "Ehliyet Numarası", "Mevcut Kiralamalar"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _kullanici_ekle(self):
        if not self.u_ad.text().strip():
            QMessageBox.warning(self, "Hata", "Ad Soyad boş olamaz!")
            return
        u = Kullanici(self.u_id.value(), self.u_ad.text(), self.u_ehliyet.text())
        ok, msg = self.merkez.kullanici_ekle(u)
        if ok: 
            self.u_ad.clear(); self.u_ehliyet.clear()
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for u in self.merkez.get_kullanicilar().values():
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(u.get_kullanici_id())))
            self.tablo.setItem(r, 1, QTableWidgetItem(u.get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(u.get_ehliyet_no()))
            
            kiralama_sayisi = len(u.get_aktif_kiralamalar())
            item = QTableWidgetItem(f"{kiralama_sayisi} Araç Kullanıyor")
            if kiralama_sayisi > 0: 
                item.setForeground(QColor(C['warning']))
                font = QFont(); font.setBold(True); item.setFont(font)
            self.tablo.setItem(r, 3, item)


class KiralamaPage(QWidget):
    def __init__(self, merkez: AracPaylasimMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🔄  Kiralama & Teslim İşlemleri", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QHBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        
        self.k_kullanici = QSpinBox(); self.k_kullanici.setRange(1, 9999); self.k_kullanici.setStyleSheet(input_ss())
        self.k_arac = QSpinBox(); self.k_arac.setRange(1, 9999); self.k_arac.setStyleSheet(input_ss())
        self.k_yeni_km = QSpinBox(); self.k_yeni_km.setRange(0, 600000); self.k_yeni_km.setSingleStep(100); self.k_yeni_km.setStyleSheet(input_ss())
        self.k_yeni_km.setToolTip("Sadece Teslim Alırken Doldurulur")

        lbl_style = f"color:{C['text_sub']};font-size:13px;font-weight:800;background:transparent;"
        klay.addWidget(QLabel("Sürücü ID:", styleSheet=lbl_style)); klay.addWidget(self.k_kullanici)
        klay.addWidget(QLabel("Araç ID:", styleSheet=lbl_style)); klay.addWidget(self.k_arac)
        klay.addWidget(QLabel("Teslim KM:", styleSheet=lbl_style)); klay.addWidget(self.k_yeni_km)
        
        btn_al = QPushButton("▼ Aracı Kirala"); btn_al.setStyleSheet(btn_warning_ss()); btn_al.clicked.connect(self._kirala)
        btn_teslim = QPushButton("▲ Teslim Al"); btn_teslim.setStyleSheet(btn_primary_ss()); btn_teslim.clicked.connect(self._teslim_al)
        
        klay.addWidget(btn_al); klay.addWidget(btn_teslim); klay.addStretch()
        lay.addWidget(kart)

        lay.addWidget(QLabel("Tüm Kiralama Geçmişi", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["İşlem No", "Sürücü Adı", "Araç", "Kiralama Tarihi", "Teslim Tarihi"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _kirala(self):
        ok, msg = self.merkez.yeni_kiralama_islemi(self.k_kullanici.value(), self.k_arac.value())
        QMessageBox.information(self, "İşlem Sonucu", msg)
        if ok: self._tum_sayfalari_guncelle()

    def _teslim_al(self):
        ok, msg = self.merkez.teslim_islemi(self.k_kullanici.value(), self.k_arac.value(), self.k_yeni_km.value())
        QMessageBox.information(self, "İşlem Sonucu", msg)
        if ok: 
            self.k_yeni_km.setValue(0)
            self._tum_sayfalari_guncelle()

    def _tum_sayfalari_guncelle(self):
        self.refresh()
        self.dashboard.refresh()
        if hasattr(self.parentWidget().parentWidget(), 'p_arac'):
            self.parentWidget().parentWidget().p_arac.refresh()
        if hasattr(self.parentWidget().parentWidget(), 'p_kullanici'):
            self.parentWidget().parentWidget().p_kullanici.refresh()

    def refresh(self):
        self.tablo.setRowCount(0)
        for k in reversed(self.merkez.get_kiralamalar()):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(f"#{k.get_kiralama_id()}"))
            self.tablo.setItem(r, 1, QTableWidgetItem(k.get_kullanici().get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(f"{k.get_arac().get_marka()} {k.get_arac().get_model()}"))
            
            baslangic = k.get_baslangic_saati().strftime("%d.%m.%Y %H:%M") if k.get_baslangic_saati() else "-"
            self.tablo.setItem(r, 3, QTableWidgetItem(baslangic))
            
            teslim_tarih = "⏳ Kullanımda"
            if k.get_bitis_saati() is not None:
                teslim_tarih = k.get_bitis_saati().strftime("%d.%m.%Y %H:%M")
                
            item_teslim = QTableWidgetItem(teslim_tarih)
            if k.get_bitis_saati() is None: item_teslim.setForeground(QColor(C['warning']))
            else: item_teslim.setForeground(QColor(C['success']))
            self.tablo.setItem(r, 4, item_teslim)
 
#============================================================
#  3. KISIM: ANA PENCERE VE GEZİNME
#============================================================
class MainWindow(QMainWindow): 
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🚗 Proje 1 — Araç Paylaşım Sistemi")
        self.setMinimumSize(1200, 750); self.setStyleSheet(f"QMainWindow{{background:{C['bg']};color:{C['text']};}}")

        self.merkez = AracPaylasimMerkezi()
        self.merkez.sahte_verileri_yukle()

        merkez_widget = QWidget(); merkez_widget.setStyleSheet(f"background:{C['bg']};"); self.setCentralWidget(merkez_widget)
        ana = QHBoxLayout(merkez_widget); ana.setContentsMargins(0, 0, 0, 0); ana.setSpacing(0)

        # YAN PANEL
        sidebar = QFrame(); sidebar.setFixedWidth(240); sidebar.setStyleSheet(f"background:{C['sidebar']};border-right:1px solid {C['border']};")
        sb = QVBoxLayout(sidebar); sb.setContentsMargins(0, 0, 0, 20); sb.setSpacing(0)
        
        logo = QFrame(); logo.setFixedHeight(80); logo.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C['accent']},stop:1 {C['accent2']});")
        ll = QVBoxLayout(logo); ll.setContentsMargins(20, 15, 20, 15)
        t1 = QLabel("🚗 Araç Paylaşım"); t1.setStyleSheet("color:#11111B;font-size:17px;font-weight:900;background:transparent;")
        t2 = QLabel("Proje 1"); t2.setStyleSheet("color:rgba(17,17,27,0.7);font-size:12px;font-weight:800;background:transparent;")
        ll.addWidget(t1); ll.addWidget(t2); sb.addWidget(logo); sb.addSpacing(20)

        self.nav = []
        for ikon, metin in [("📊", "Özet Ekranı"), ("🚗", "Araç Yönetimi"), ("👥", "Kullanıcı Yönetimi"), ("🔄", "Kiralama / Teslim")]:
            btn = SideBtn(ikon, metin); btn.clicked.connect(lambda _, m=metin: self._goto(m))
            sb.addWidget(btn); self.nav.append(btn)
        sb.addStretch()
        
        self.lbl_saat = QLabel(); self.lbl_saat.setAlignment(Qt.AlignCenter); self.lbl_saat.setStyleSheet(f"color:{C['text_dim']};font-size:12px;font-weight:800;background:transparent;")
        sb.addWidget(self.lbl_saat); ana.addWidget(sidebar)

        # İÇERİK ALANI
        icerik = QWidget(); icerik.setStyleSheet(f"background:{C['bg']};")
        il = QVBoxLayout(icerik); il.setContentsMargins(0,0,0,0); il.setSpacing(0)

        topbar = QFrame(); topbar.setFixedHeight(55); topbar.setStyleSheet(f"background:{C['sidebar']};border-bottom:1px solid {C['border']};")
        tl = QHBoxLayout(topbar); tl.setContentsMargins(30, 0, 30, 0)
        self.lbl_page = QLabel("Özet Ekranı"); self.lbl_page.setStyleSheet(f"color:{C['text']};font-size:15px;font-weight:800;background:transparent;")
        tl.addWidget(self.lbl_page); tl.addStretch()
        tl.addWidget(QLabel("👤 Yönetici", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        il.addWidget(topbar)

        self.stack = QStackedWidget(); self.stack.setStyleSheet(f"background:{C['bg']};")
        self.p_dashboard = DashboardPage(self.merkez)
        self.p_arac = AracYonetimPage(self.merkez, self.p_dashboard)
        self.p_kullanici = KullaniciYonetimPage(self.merkez, self.p_dashboard)
        self.p_kiralama = KiralamaPage(self.merkez, self.p_dashboard)
        
        for p in [self.p_dashboard, self.p_arac, self.p_kullanici, self.p_kiralama]: self.stack.addWidget(p)
        il.addWidget(self.stack); ana.addWidget(icerik)

        self._goto("Özet Ekranı")
        t = QTimer(self); t.timeout.connect(lambda: self.lbl_saat.setText(datetime.now().strftime("%d.%m.%Y\n%H:%M:%S"))); t.start(1000)

    def _goto(self, sayfa):
        idx = {"Özet Ekranı": 0, "Araç Yönetimi": 1, "Kullanıcı Yönetimi": 2, "Kiralama / Teslim": 3}[sayfa]
        self.stack.setCurrentIndex(idx)
        self.lbl_page.setText(sayfa.upper())
        for i, b in enumerate(self.nav): b.setChecked(i == idx)
        
        if idx == 0: self.p_dashboard.refresh()
        elif idx == 1: self.p_arac.refresh()
        elif idx == 2: self.p_kullanici.refresh()
        elif idx == 3: self.p_kiralama.refresh()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    p = QPalette()
    p.setColor(QPalette.Window, QColor(C['bg'])); p.setColor(QPalette.WindowText, QColor(C['text']))
    p.setColor(QPalette.Base, QColor(C['card'])); p.setColor(QPalette.AlternateBase, QColor(C['row_alt']))
    p.setColor(QPalette.Text, QColor(C['text'])); p.setColor(QPalette.Button, QColor(C['card']))
    p.setColor(QPalette.ButtonText, QColor(C['text'])); p.setColor(QPalette.Highlight, QColor(C['accent']))
    p.setColor(QPalette.HighlightedText, QColor("#11111B"))
    app.setPalette(p)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())