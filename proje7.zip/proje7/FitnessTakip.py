"""
============================================================
  PROJE 7: FİTNESS TAKİP SİSTEMİ
============================================================
Açıklama: Bu proje, sporcuların antrenmanlarını, yaktıkları 
kalorileri ve fiziksel ilerlemelerini OOP mantığıyla takip eder.
============================================================
"""

import sys
from datetime import datetime, timedelta

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFrame,
    QStackedWidget, QHeaderView, QLineEdit, QGridLayout,
    QSpinBox, QMessageBox, QAbstractItemView, QGraphicsDropShadowEffect
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QPalette, QFont

# ============================================================
#  1. KISIM: İŞ MANTIĞI VE SINIFLAR (BACKEND)
# ============================================================

class Antrenman:
    def __init__(self, antrenman_id: int, tur: str, sure: int):
        self.__antrenman_id = antrenman_id
        self.__tur = tur   # Örn: Ağırlık, Kardiyo, Hiit
        self.__sure = sure # Dakika cinsinden

    def get_antrenman_id(self) -> int: return self.__antrenman_id
    def get_tur(self) -> str: return self.__tur
    def get_sure(self) -> int: return self.__sure


class Takip:
    def __init__(self, takip_id: int, sporcu: 'Sporcu', antrenman: Antrenman, kalori: int):
        self.__takip_id = takip_id
        self.__sporcu = sporcu
        self.__antrenman = antrenman
        self.__kalori = kalori
        self.__tarih = datetime.now()

    def get_takip_id(self) -> int: return self.__takip_id
    def get_sporcu(self) -> 'Sporcu': return self.__sporcu
    def get_antrenman(self) -> Antrenman: return self.__antrenman
    def get_kalori(self) -> int: return self.__kalori
    def get_tarih(self) -> datetime: return self.__tarih

    # Sunum/Test için tarihi geriye alma metodu
    def _test_icin_tarih_degistir(self, gun_farki):
        self.__tarih -= timedelta(days=gun_farki)


class Sporcu:
    def __init__(self, sporcu_id: int, ad: str, kilo: float, boy: int):
        self.__sporcu_id = sporcu_id
        self.__ad = ad
        self.__kilo = kilo # kg
        self.__boy = boy   # cm
        self.__antrenman_gecmisi = []

    def get_sporcu_id(self) -> int: return self.__sporcu_id
    def get_ad(self) -> str: return self.__ad
    def get_kilo(self) -> float: return self.__kilo
    def get_boy(self) -> int: return self.__boy
    def get_antrenman_gecmisi(self) -> list: return self.__antrenman_gecmisi

    def ilerleme_kaydet(self, takip_kaydi: Takip, guncel_kilo: float = None):
        self.__antrenman_gecmisi.append(takip_kaydi)
        # Eğer yeni kilo girildiyse sporcunun kilosunu güncelle
        if guncel_kilo and guncel_kilo > 0:
            self.__kilo = guncel_kilo
        return True, f"{self.__ad} adlı sporcunun {takip_kaydi.get_antrenman().get_tur()} antrenmanı kaydedildi."

    def vki_hesapla(self) -> float:
        # Boyu metreye çevir ve VKİ hesapla: Kilo / (Boy * Boy)
        boy_m = self.__boy / 100.0
        return self.__kilo / (boy_m ** 2)

    def vki_durumu(self) -> str:
        vki = self.vki_hesapla()
        if vki < 18.5: return "Zayıf"
        elif 18.5 <= vki < 24.9: return "Normal"
        elif 25 <= vki < 29.9: return "Fazla Kilolu"
        else: return "Obez"


class FitnessMerkezi:
    def __init__(self):
        self.__sporcular = {}
        self.__antrenmanlar = {}
        self.__tum_takipler = []
        self.__son_takip_id = 1000

    def sporcu_ekle(self, sporcu: Sporcu):
        if sporcu.get_sporcu_id() in self.__sporcular: 
            return False, "Bu ID ile sporcu zaten var."
        self.__sporcular[sporcu.get_sporcu_id()] = sporcu
        return True, "Sporcu sisteme eklendi."

    def antrenman_ekle(self, antrenman: Antrenman):
        if antrenman.get_antrenman_id() in self.__antrenmanlar: 
            return False, "Bu ID ile antrenman zaten var."
        self.__antrenmanlar[antrenman.get_antrenman_id()] = antrenman
        return True, "Antrenman programı kaydedildi."

    def get_sporcular(self): return self.__sporcular
    def get_antrenmanlar(self): return self.__antrenmanlar
    def get_takipler(self): return self.__tum_takipler

    def yeni_takip_islemi(self, sporcu_id: int, antrenman_id: int, kalori: int, guncel_kilo: float = 0):
        sporcu = self.__sporcular.get(sporcu_id)
        antrenman = self.__antrenmanlar.get(antrenman_id)
        
        if not sporcu: return False, "Sporcu bulunamadı!"
        if not antrenman: return False, "Antrenman bulunamadı!"
        
        yeni_takip = Takip(self.__son_takip_id, sporcu, antrenman, kalori)
        ok, msg = sporcu.ilerleme_kaydet(yeni_takip, guncel_kilo)
        
        if ok:
            self.__tum_takipler.append(yeni_takip)
            self.__son_takip_id += 1
        return ok, msg

    # SUNUM İÇİN SAHTE VERİ ÜRETİCİ
    def sahte_verileri_yukle(self):
        # 1. Sporcuları Ekleyelim
        self.sporcu_ekle(Sporcu(1, "Berkkan Kahraman", 85.5, 187))
        self.sporcu_ekle(Sporcu(2, "Jimmy Tyler", 76.0, 180))
        self.sporcu_ekle(Sporcu(3, "Alp Akcelep", 92.0, 175))
        self.sporcu_ekle(Sporcu(4, "Halit Güneş", 70.0, 182))

        # 2. Antrenman Türlerini Ekleyelim
        self.antrenman_ekle(Antrenman(101, "Ağırlık (İtme/Push)", 60))
        self.antrenman_ekle(Antrenman(102, "Ağırlık (Çekme/Pull)", 60))
        self.antrenman_ekle(Antrenman(103, "Kardiyo (Koşu)", 45))
        self.antrenman_ekle(Antrenman(104, "HIIT (Yüksek Yoğunluk)", 30))
        self.antrenman_ekle(Antrenman(105, "Bacak & Core", 75))

        # 3. İlerleme ve Takip Senaryoları
        # Berkkan'ın ilk antrenman kaydı (Şubat 1'e ayarlıyoruz)
        self.yeni_takip_islemi(1, 101, 450) 
        self.__tum_takipler[-1]._test_icin_tarih_degistir(78) 

        self.yeni_takip_islemi(1, 102, 500, 84.8) # Kilo güncellemesi ile
        self.__tum_takipler[-1]._test_icin_tarih_degistir(75)

        self.yeni_takip_islemi(2, 103, 600) # Jimmy koşu yaptı
        self.__tum_takipler[-1]._test_icin_tarih_degistir(2)
        
        self.yeni_takip_islemi(3, 105, 550) # Alp bacak çalıştı


# ============================================================
#  2. KISIM: ARAYÜZ (GUI) - GÖZ YORMAYAN MODERN TEMA
# ============================================================

C = {
    "bg":        "#1E1E2E",  
    "sidebar":   "#181825",  
    "card":      "#313244",  
    "border":    "#45475A",  
    "accent":    "#89B4FA",  
    "accent2":   "#74C7EC",  
    "success":   "#A6E3A1",  
    "warning":   "#F9E2AF",  
    "danger":    "#F38BA8",  
    "text":      "#CDD6F4",  
    "text_sub":  "#A6ADC8",  
    "text_dim":  "#7F849C",  
    "row_alt":   "#25253A",  
    "row_sel":   "#3B4252",  
    "input_bg":  "#11111B",  
}

def card_ss(): return f"background:{C['card']};border:1px solid {C['border']};border-radius:12px;"
def btn_primary_ss(): return f"QPushButton{{background:{C['accent']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:{C['accent2']};}}"
def btn_success_ss(): return f"QPushButton{{background:{C['success']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#87D481;}}"
def btn_warning_ss(): return f"QPushButton{{background:{C['warning']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#EBD399;}}"
def input_ss(): return f"QLineEdit,QSpinBox,QDoubleSpinBox{{background:{C['input_bg']};color:{C['text']};border:1px solid {C['border']};border-radius:8px;padding:8px 12px;font-size:13px;}}"

TABLE_SS = f"""
    QTableWidget{{background:{C['card']};color:{C['text']};border:none;gridline-color:{C['border']};font-size:13px;selection-background-color:{C['row_sel']};outline:none;alternate-background-color:{C['row_alt']};}}
    QTableWidget::item{{padding:10px 14px;border-bottom:1px solid {C['border']};}}
    QHeaderView::section{{background:{C['sidebar']};color:{C['accent']};padding:10px 14px;border:none;border-bottom:2px solid {C['accent']};font-size:12px;font-weight:800;letter-spacing:0.5px;}}
"""

def shadow(widget):
    fx = QGraphicsDropShadowEffect(widget)
    fx.setBlurRadius(20); fx.setColor(QColor(0, 0, 0, 60)); fx.setOffset(0, 4)
    widget.setGraphicsEffect(fx)


class KpiCard(QFrame):
    def __init__(self, baslik, deger, alt, renk):
        super().__init__()
        self.setFixedHeight(114)
        self.setStyleSheet(f"QFrame{{background:{C['card']};border:1px solid {C['border']};border-radius:12px;border-left:5px solid {renk};}}")
        shadow(self)
        lay = QVBoxLayout(self); lay.setContentsMargins(20, 15, 20, 15); lay.setSpacing(4)
        lbl_t = QLabel(baslik.upper()); lbl_t.setStyleSheet(f"color:{C['text_sub']};font-size:11px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        self.lbl_v = QLabel(str(deger)); self.lbl_v.setStyleSheet(f"color:{renk};font-size:30px;font-weight:800;background:transparent;border:none;")
        lbl_a = QLabel(alt); lbl_a.setStyleSheet(f"color:{C['text_dim']};font-size:12px;background:transparent;border:none;")
        lay.addWidget(lbl_t); lay.addWidget(self.lbl_v); lay.addWidget(lbl_a)
    def guncelle(self, val): self.lbl_v.setText(str(val))

class SideBtn(QPushButton):
    def __init__(self, ikon, metin):
        super().__init__(f"  {ikon}  {metin}")
        self.setCheckable(True); self.setFixedHeight(50); self.setCursor(Qt.PointingHandCursor)
        self._refresh(False)
    def _refresh(self, aktif):
        if aktif: self.setStyleSheet(f"QPushButton{{background:rgba(137, 180, 250, 0.1);color:{C['accent']};border:none;border-left:4px solid {C['accent']};border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:800;}}")
        else: self.setStyleSheet(f"QPushButton{{background:transparent;color:{C['text_sub']};border:none;border-left:4px solid transparent;border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:600;}}QPushButton:hover{{background:{C['card']};color:{C['text']};border-left:4px solid {C['border']};}}")
    def setChecked(self, v): super().setChecked(v); self._refresh(v)

class DashboardPage(QWidget):
    def __init__(self, merkez: FitnessMerkezi):
        super().__init__()
        self.merkez = merkez
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lbl = QLabel("📊  Fitness Özeti")
        lbl.setStyleSheet(f"color:{C['text']};font-size:24px;font-weight:800;")
        lay.addWidget(lbl)

        self.kpi_row = QHBoxLayout(); lay.addLayout(self.kpi_row)
        self.c1 = KpiCard("Aktif Sporcular", 0, "Sisteme Kayıtlı", C['accent'])
        self.c2 = KpiCard("Tamamlanan Antrenman", 0, "Toplam Log Sayısı", C['success'])
        self.c3 = KpiCard("Yakılan Kalori", 0, "Tüm Zamanlar (kcal)", C['warning'])
        for c in [self.c1, self.c2, self.c3]: self.kpi_row.addWidget(c)
        
        lay.addWidget(QLabel("Son Antrenman Kayıtları (Canlı Log)", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:15px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["Durum", "Sporcu", "Antrenman Türü", "Kalori", "Tarih"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)

    def refresh(self):
        sporcular = self.merkez.get_sporcular().values()
        takipler = self.merkez.get_takipler()
        toplam_kalori = sum(t.get_kalori() for t in takipler)

        self.c1.guncelle(len(sporcular))
        self.c2.guncelle(len(takipler))
        self.c3.guncelle(toplam_kalori)

        self.tablo.setRowCount(0)
        for t in reversed(takipler[-10:]):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            
            durum_item = QTableWidgetItem("💪 Tamamlandı")
            durum_item.setForeground(QColor(C['success']))
            font = QFont(); font.setBold(True); durum_item.setFont(font)
            
            self.tablo.setItem(r, 0, durum_item)
            self.tablo.setItem(r, 1, QTableWidgetItem(t.get_sporcu().get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(t.get_antrenman().get_tur()))
            self.tablo.setItem(r, 3, QTableWidgetItem(f"🔥 {t.get_kalori()} kcal"))
            self.tablo.setItem(r, 4, QTableWidgetItem(t.get_tarih().strftime("%d.%m.%Y - %H:%M")))

class SporcuYonetimPage(QWidget):
    def __init__(self, merkez: FitnessMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        from PyQt5.QtWidgets import QDoubleSpinBox # Özel import
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🏋️‍♂️  Sporcu Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Yeni Sporcu Ekle", styleSheet=f"color:{C['accent']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QGridLayout()
        self.s_id = QSpinBox(); self.s_id.setRange(1, 9999)
        self.s_ad = QLineEdit(); self.s_ad.setPlaceholderText("Ad Soyad")
        self.s_kilo = QDoubleSpinBox(); self.s_kilo.setRange(30.0, 250.0); self.s_kilo.setSuffix(" kg")
        self.s_boy = QSpinBox(); self.s_boy.setRange(100, 250); self.s_boy.setSuffix(" cm")
        
        for w in [self.s_id, self.s_ad, self.s_kilo, self.s_boy]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Sporcu ID", styleSheet=lbl_style), 0, 0); g.addWidget(self.s_id, 1, 0)
        g.addWidget(QLabel("Ad Soyad", styleSheet=lbl_style), 0, 1); g.addWidget(self.s_ad, 1, 1)
        g.addWidget(QLabel("Kilo", styleSheet=lbl_style), 0, 2); g.addWidget(self.s_kilo, 1, 2)
        g.addWidget(QLabel("Boy", styleSheet=lbl_style), 0, 3); g.addWidget(self.s_boy, 1, 3)
        klay.addLayout(g)
        
        btn_sporcu = QPushButton("＋ Sporcu Kaydet"); btn_sporcu.setStyleSheet(btn_primary_ss()); btn_sporcu.clicked.connect(self._sporcu_ekle)
        klay.addWidget(btn_sporcu, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Sistemdeki Sporcular ve Fiziksel Durumları", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["ID", "Ad Soyad", "Vücut Ölçüleri", "VKİ (Endeks)", "Durum Analizi"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _sporcu_ekle(self):
        if not self.s_ad.text().strip():
            QMessageBox.warning(self, "Hata", "Ad Soyad boş olamaz!")
            return
        s = Sporcu(self.s_id.value(), self.s_ad.text(), self.s_kilo.value(), self.s_boy.value())
        ok, msg = self.merkez.sporcu_ekle(s)
        if ok: 
            self.s_ad.clear(); self.s_kilo.setValue(70.0); self.s_boy.setValue(170)
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for s in self.merkez.get_sporcular().values():
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(s.get_sporcu_id())))
            self.tablo.setItem(r, 1, QTableWidgetItem(s.get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(f"{s.get_kilo():.1f} kg / {s.get_boy()} cm"))
            
            vki = s.vki_hesapla()
            self.tablo.setItem(r, 3, QTableWidgetItem(f"{vki:.1f}"))
            
            durum_txt = s.vki_durumu()
            durum_item = QTableWidgetItem(durum_txt)
            font = QFont(); font.setBold(True); durum_item.setFont(font)
            
            if durum_txt == "Normal": durum_item.setForeground(QColor(C['success']))
            elif durum_txt == "Fazla Kilolu": durum_item.setForeground(QColor(C['warning']))
            else: durum_item.setForeground(QColor(C['danger']))
            
            self.tablo.setItem(r, 4, durum_item)

class AntrenmanYonetimPage(QWidget):
    def __init__(self, merkez: FitnessMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🏃‍♂️  Antrenman Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Yeni Antrenman Türü Ekle", styleSheet=f"color:{C['success']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QHBoxLayout()
        self.a_id = QSpinBox(); self.a_id.setRange(1, 9999)
        self.a_tur = QLineEdit(); self.a_tur.setPlaceholderText("Antrenman Türü (Örn: İtme Günü)")
        self.a_sure = QSpinBox(); self.a_sure.setRange(5, 300); self.a_sure.setSuffix(" Dk")
        for w in [self.a_id, self.a_tur, self.a_sure]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Antrenman ID:", styleSheet=lbl_style)); g.addWidget(self.a_id)
        g.addWidget(QLabel("Tür/İsim:", styleSheet=lbl_style)); g.addWidget(self.a_tur)
        g.addWidget(QLabel("Hedef Süre:", styleSheet=lbl_style)); g.addWidget(self.a_sure)
        klay.addLayout(g)
        
        btn_antrenman = QPushButton("＋ Antrenman Kaydet"); btn_antrenman.setStyleSheet(btn_success_ss()); btn_antrenman.clicked.connect(self._antrenman_ekle)
        klay.addWidget(btn_antrenman, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Program Havuzu", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(3)
        self.tablo.setHorizontalHeaderLabels(["ID", "Antrenman Türü", "Standart Süre"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _antrenman_ekle(self):
        if not self.a_tur.text().strip():
            QMessageBox.warning(self, "Hata", "Antrenman türü boş olamaz!")
            return
        a = Antrenman(self.a_id.value(), self.a_tur.text(), self.a_sure.value())
        ok, msg = self.merkez.antrenman_ekle(a)
        if ok: 
            self.a_tur.clear(); self.a_sure.setValue(60)
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for a in self.merkez.get_antrenmanlar().values():
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(a.get_antrenman_id())))
            self.tablo.setItem(r, 1, QTableWidgetItem(a.get_tur()))
            self.tablo.setItem(r, 2, QTableWidgetItem(f"{a.get_sure()} Dakika"))


class TakipPage(QWidget):
    def __init__(self, merkez: FitnessMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        from PyQt5.QtWidgets import QDoubleSpinBox
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("📈  İlerleme & Takip", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QHBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        
        self.t_sporcu = QSpinBox(); self.t_sporcu.setRange(1, 9999); self.t_sporcu.setStyleSheet(input_ss())
        self.t_antrenman = QSpinBox(); self.t_antrenman.setRange(1, 9999); self.t_antrenman.setStyleSheet(input_ss())
        self.t_kalori = QSpinBox(); self.t_kalori.setRange(10, 5000); self.t_kalori.setSuffix(" kcal"); self.t_kalori.setStyleSheet(input_ss())
        self.t_kilo = QDoubleSpinBox(); self.t_kilo.setRange(0.0, 250.0); self.t_kilo.setSuffix(" kg"); self.t_kilo.setStyleSheet(input_ss())
        self.t_kilo.setToolTip("Değişmediyse 0 bırakın")

        lbl_style = f"color:{C['text_sub']};font-size:13px;font-weight:800;background:transparent;"
        klay.addWidget(QLabel("Sporcu ID:", styleSheet=lbl_style)); klay.addWidget(self.t_sporcu)
        klay.addWidget(QLabel("Antrenman ID:", styleSheet=lbl_style)); klay.addWidget(self.t_antrenman)
        klay.addWidget(QLabel("Yakılan Kalori:", styleSheet=lbl_style)); klay.addWidget(self.t_kalori)
        klay.addWidget(QLabel("Güncel Kilo (Ops):", styleSheet=lbl_style)); klay.addWidget(self.t_kilo)
        
        btn_kaydet = QPushButton("Kaydet"); btn_kaydet.setStyleSheet(btn_warning_ss()); btn_kaydet.clicked.connect(self._takip_kaydet)
        
        klay.addWidget(btn_kaydet); klay.addStretch()
        lay.addWidget(kart)

        lay.addWidget(QLabel("Tüm İlerleme Geçmişi", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["Kayıt No", "Sporcu", "Tamamlanan Antrenman", "Harcanan Kalori"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _takip_kaydet(self):
        ok, msg = self.merkez.yeni_takip_islemi(self.t_sporcu.value(), self.t_antrenman.value(), self.t_kalori.value(), self.t_kilo.value())
        QMessageBox.information(self, "İşlem Sonucu", msg)
        if ok: 
            self.t_kalori.setValue(0)
            self.t_kilo.setValue(0.0)
            self._tum_sayfalari_guncelle()

    def _tum_sayfalari_guncelle(self):
        self.refresh()
        self.dashboard.refresh()
        if hasattr(self.parentWidget().parentWidget(), 'p_sporcu'):
            self.parentWidget().parentWidget().p_sporcu.refresh()

    def refresh(self):
        self.tablo.setRowCount(0)
        for t in reversed(self.merkez.get_takipler()):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(f"#{t.get_takip_id()}"))
            self.tablo.setItem(r, 1, QTableWidgetItem(t.get_sporcu().get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(t.get_antrenman().get_tur()))
            
            item_kalori = QTableWidgetItem(f"{t.get_kalori()} kcal")
            item_kalori.setForeground(QColor(C['warning']))
            font = QFont(); font.setBold(True); item_kalori.setFont(font)
            self.tablo.setItem(r, 3, item_kalori)
 
#============================================================
#  3. KISIM: ANA PENCERE VE GEZİNME
#============================================================
class MainWindow(QMainWindow): 
    def __init__(self):
        super().__init__()
        self.setWindowTitle("💪 Proje 7 — Fitness Takip Sistemi")
        self.setMinimumSize(1200, 750); self.setStyleSheet(f"QMainWindow{{background:{C['bg']};color:{C['text']};}}")

        self.merkez = FitnessMerkezi()
        self.merkez.sahte_verileri_yukle()

        merkez_widget = QWidget(); merkez_widget.setStyleSheet(f"background:{C['bg']};"); self.setCentralWidget(merkez_widget)
        ana = QHBoxLayout(merkez_widget); ana.setContentsMargins(0, 0, 0, 0); ana.setSpacing(0)

        # YAN PANEL
        sidebar = QFrame(); sidebar.setFixedWidth(240); sidebar.setStyleSheet(f"background:{C['sidebar']};border-right:1px solid {C['border']};")
        sb = QVBoxLayout(sidebar); sb.setContentsMargins(0, 0, 0, 20); sb.setSpacing(0)
        
        logo = QFrame(); logo.setFixedHeight(80); logo.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C['accent']},stop:1 {C['accent2']});")
        ll = QVBoxLayout(logo); ll.setContentsMargins(20, 15, 20, 15)
        t1 = QLabel("💪 Fitness & Gym"); t1.setStyleSheet("color:#11111B;font-size:17px;font-weight:900;background:transparent;")
        t2 = QLabel("Proje 7"); t2.setStyleSheet("color:rgba(17,17,27,0.7);font-size:12px;font-weight:800;background:transparent;")
        ll.addWidget(t1); ll.addWidget(t2); sb.addWidget(logo); sb.addSpacing(20)

        self.nav = []
        for ikon, metin in [("📊", "Özet Ekranı"), ("🏋️‍♂️", "Sporcu Yönetimi"), ("🏃‍♂️", "Antrenman Türleri"), ("📈", "İlerleme Takibi")]:
            btn = SideBtn(ikon, metin); btn.clicked.connect(lambda _, m=metin: self._goto(m))
            sb.addWidget(btn); self.nav.append(btn)
        sb.addStretch()
        
        self.lbl_saat = QLabel(); self.lbl_saat.setAlignment(Qt.AlignCenter); self.lbl_saat.setStyleSheet(f"color:{C['text_dim']};font-size:12px;font-weight:800;background:transparent;")
        sb.addWidget(self.lbl_saat); ana.addWidget(sidebar)

        # İÇERİK ALANI
        icerik = QWidget(); icerik.setStyleSheet(f"background:{C['bg']};")
        il = QVBoxLayout(icerik); il.setContentsMargins(0,0,0,0); il.setSpacing(0)

        topbar = QFrame(); topbar.setFixedHeight(55); topbar.setStyleSheet(f"background:{C['sidebar']};border-bottom:1px solid {C['border']};")
        tl = QHBoxLayout(topbar); tl.setContentsMargins(30, 0, 30, 0)
        self.lbl_page = QLabel("Özet Ekranı"); self.lbl_page.setStyleSheet(f"color:{C['text']};font-size:15px;font-weight:800;background:transparent;")
        tl.addWidget(self.lbl_page); tl.addStretch()
        tl.addWidget(QLabel("👤 Koç / Yönetici", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        il.addWidget(topbar)

        self.stack = QStackedWidget(); self.stack.setStyleSheet(f"background:{C['bg']};")
        self.p_dashboard = DashboardPage(self.merkez)
        self.p_sporcu = SporcuYonetimPage(self.merkez, self.p_dashboard)
        self.p_antrenman = AntrenmanYonetimPage(self.merkez, self.p_dashboard)
        self.p_takip = TakipPage(self.merkez, self.p_dashboard)
        
        for p in [self.p_dashboard, self.p_sporcu, self.p_antrenman, self.p_takip]: self.stack.addWidget(p)
        il.addWidget(self.stack); ana.addWidget(icerik)

        self._goto("Özet Ekranı")
        t = QTimer(self); t.timeout.connect(lambda: self.lbl_saat.setText(datetime.now().strftime("%d.%m.%Y\n%H:%M:%S"))); t.start(1000)

    def _goto(self, sayfa):
        idx = {"Özet Ekranı": 0, "Sporcu Yönetimi": 1, "Antrenman Türleri": 2, "İlerleme Takibi": 3}[sayfa]
        self.stack.setCurrentIndex(idx)
        self.lbl_page.setText(sayfa.upper())
        for i, b in enumerate(self.nav): b.setChecked(i == idx)
        
        if idx == 0: self.p_dashboard.refresh()
        elif idx == 1: self.p_sporcu.refresh()
        elif idx == 2: self.p_antrenman.refresh()
        elif idx == 3: self.p_takip.refresh()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    p = QPalette()
    p.setColor(QPalette.Window, QColor(C['bg'])); p.setColor(QPalette.WindowText, QColor(C['text']))
    p.setColor(QPalette.Base, QColor(C['card'])); p.setColor(QPalette.AlternateBase, QColor(C['row_alt']))
    p.setColor(QPalette.Text, QColor(C['text'])); p.setColor(QPalette.Button, QColor(C['card']))
    p.setColor(QPalette.ButtonText, QColor(C['text'])); p.setColor(QPalette.Highlight, QColor(C['accent']))
    p.setColor(QPalette.HighlightedText, QColor("#11111B"))
    app.setPalette(p)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())