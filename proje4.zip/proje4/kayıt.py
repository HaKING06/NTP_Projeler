"""
============================================================
  PROJE 4: ETKİNLİK KAYIT VE BİLET SİSTEMİ
============================================================
Açıklama: Bu proje, Nesne Tabanlı Programlama (OOP) ile
etkinlik kapasite yönetimi, katılımcı kaydı ve biletleme
işlemlerini simüle eder. Ekstra Raporlama özelliği içerir.
============================================================
"""

import sys
from datetime import datetime

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFrame,
    QStackedWidget, QHeaderView, QLineEdit, QGridLayout,
    QSpinBox, QMessageBox, QAbstractItemView, QGraphicsDropShadowEffect,
    QDateEdit
)
from PyQt5.QtCore import Qt, QTimer, QDate
from PyQt5.QtGui import QColor, QPalette, QFont

# ============================================================
#  1. KISIM: İŞ MANTIĞI VE SINIFLAR (BACKEND)
# ============================================================

class Katilimci:
    """Etkinliğe katılacak kişiyi temsil eder."""
    def __init__(self, katilimci_id: int, ad: str, email: str):
        # Kapsülleme (Encapsulation)
        self.__katilimci_id = katilimci_id
        self.__ad = ad
        self.__email = email

    def get_katilimci_id(self) -> int: return self.__katilimci_id
    def get_ad(self) -> str:           return self.__ad
    def get_email(self) -> str:        return self.__email

class Etkinlik:
    """Düzenlenen bir etkinliği temsil eder ve kapasite kontrolü yapar."""
    def __init__(self, etkinlik_id: int, ad: str, tarih: str, kapasite: int):
        self.__etkinlik_id = etkinlik_id
        self.__ad = ad
        self.__tarih = tarih
        self.__kapasite = kapasite
        self.__kayitli_katilimcilar = [] # Etkinliğe kayıtlı kişilerin listesi

    def get_etkinlik_id(self) -> int: return self.__etkinlik_id
    def get_ad(self) -> str:          return self.__ad
    def get_tarih(self) -> str:       return self.__tarih
    def get_kapasite(self) -> int:    return self.__kapasite
    def get_katilimci_sayisi(self)-> int: return len(self.__kayitli_katilimcilar)

    # PROJEDE İSTENEN METOD
    def katilimci_ekle(self, katilimci: Katilimci):
        """Kapasite kontrolü yaparak etkinliğe katılımcı ekler."""
        if len(self.__kayitli_katilimcilar) < self.__kapasite:
            # Aynı kişi aynı etkinliğe 2 kez kayıt olamasın diye kontrol
            for k in self.__kayitli_katilimcilar:
                if k.get_katilimci_id() == katilimci.get_katilimci_id():
                    return False, f"{katilimci.get_ad()} zaten bu etkinliğe kayıtlı."
            
            self.__kayitli_katilimcilar.append(katilimci)
            return True, "Katılımcı başarıyla eklendi."
        else:
            return False, f"HATA: {self.__ad} etkinliğinin kapasitesi ({self.__kapasite}) dolmuştur!"

class Bilet:
    """Etkinlik ve Katılımcı sınıflarını birbirine bağlayan bilet nesnesi."""
    def __init__(self, bilet_id: int, etkinlik: Etkinlik, katilimci: Katilimci):
        self.__bilet_id = bilet_id
        self.__etkinlik = etkinlik
        self.__katilimci = katilimci
        self.__olusturma_tarihi = datetime.now()

    def get_bilet_id(self) -> int: return self.__bilet_id
    def get_etkinlik(self) -> Etkinlik: return self.__etkinlik
    def get_katilimci(self) -> Katilimci: return self.__katilimci
    def get_olusturma_tarihi(self) -> datetime: return self.__olusturma_tarihi

    # PROJEDE İSTENEN METOD
    def bilet_olustur(self):
        """
        Bilet oluşturulurken Etkinlik sınıfındaki katilimci_ekle metodu tetiklenir.
        Eğer kapasite doluysa bilet oluşumu reddedilir.
        """
        basarili_mi, mesaj = self.__etkinlik.katilimci_ekle(self.__katilimci)
        return basarili_mi, mesaj

class EtkinlikMerkezi:
    """Tüm sistemin yönetildiği merkezi yönetici sınıfı (Manager Class)."""
    def __init__(self):
        self.__etkinlikler = {}
        self.__katilimcilar = {}
        self.__kesilen_biletler = []
        self.__son_bilet_id = 50000

    def etkinlik_ekle(self, etkinlik: Etkinlik):
        if etkinlik.get_etkinlik_id() in self.__etkinlikler:
            return False, "Bu ID ile bir etkinlik zaten var."
        self.__etkinlikler[etkinlik.get_etkinlik_id()] = etkinlik
        return True, "Etkinlik başarıyla oluşturuldu."

    def katilimci_ekle(self, katilimci: Katilimci):
        if katilimci.get_katilimci_id() not in self.__katilimcilar:
            self.__katilimcilar[katilimci.get_katilimci_id()] = katilimci
        # Eğer zaten varsa tekrar eklemeyiz ama hata da vermeyiz, direkt bilet kesimine geçeriz.
        return True, "Katılımcı kaydı tamam."

    def get_tum_etkinlikler(self): return self.__etkinlikler
    def get_tum_katilimcilar(self): return self.__katilimcilar
    def get_tum_biletler(self): return self.__kesilen_biletler

    def bilet_kes(self, etkinlik_id: int, katilimci_id: int, ad: str, email: str):
        etkinlik = self.__etkinlikler.get(etkinlik_id)
        if not etkinlik: return False, "Etkinlik bulunamadı!"

        # Katılımcıyı bul veya yeni yarat
        katilimci = self.__katilimcilar.get(katilimci_id)
        if not katilimci:
            katilimci = Katilimci(katilimci_id, ad, email)
            self.katilimci_ekle(katilimci)

        yeni_bilet = Bilet(self.__son_bilet_id, etkinlik, katilimci)
        ok, msg = yeni_bilet.bilet_olustur()

        if ok:
            self.__kesilen_biletler.append(yeni_bilet)
            self.__son_bilet_id += 1
            return True, f"Bilet Onaylandı! Bilet No: #{yeni_bilet.get_bilet_id()}"
        return False, msg

    # PROJEDE İSTENEN EK ÖZELLİK: RAPORLAMA METODU
    def katilim_raporu_getir(self):
        """Etkinliklerin doluluk oranlarını ve katılımcı sayılarını liste olarak döner."""
        rapor = []
        for e in self.__etkinlikler.values():
            rapor.append({
                "id": e.get_etkinlik_id(),
                "ad": e.get_ad(),
                "tarih": e.get_tarih(),
                "kapasite": e.get_kapasite(),
                "katilan": e.get_katilimci_sayisi(),
                "doluluk": round((e.get_katilimci_sayisi() / e.get_kapasite()) * 100, 1) if e.get_kapasite() > 0 else 0
            })
        return rapor

    def test_verilerini_yukle(self):
        # Sunum için örnek veriler
        self.etkinlik_ekle(Etkinlik(1, "Python Geliştirici Zirvesi", "20.05.2026", 150))
        self.etkinlik_ekle(Etkinlik(2, "Yapay Zeka Konferansı", "25.05.2026", 3)) # Kapasiteyi bilerek düşük tuttuk test için
        self.etkinlik_ekle(Etkinlik(3, "Bahar Şenliği Konseri", "30.05.2026", 5000))

        self.bilet_kes(2, 101, "Halit Güneş", "halit@iku.edu")
        self.bilet_kes(2, 102, "Alp Yılmaz", "alp@iku.edu")
        self.bilet_kes(1, 103, "Berkkan Demir", "berkkan@iku.edu")


# ============================================================
#  2. KISIM: ARAYÜZ (GUI) - ETKİNLİK / BİLET TEMASI (VİOLET)
# ============================================================

# TEMA: Biletix/Passo tarzı Canlı Mor ve Gece Mavisi (Eventbrite Esintili)
C = {
    "bg":        "#0F0F1A",  # Koyu Lacivert/Siyah Arka Plan
    "sidebar":   "#161625",  # Yan Panel
    "card":      "#1E1E2E",  # Kart Rengi
    "border":    "#2D2D44",  # İnce Kenarlıklar
    "accent":    "#8B5CF6",  # Canlı Mor (Primary)
    "accent2":   "#EC4899",  # Neon Pembe (Secondary)
    "success":   "#10B981",  # Zümrüt Yeşili
    "warning":   "#F59E0B",  # Turuncu/Sarı
    "danger":    "#EF4444",  # Kırmızı (Kapasite Dolu için)
    "text":      "#F8FAFC",  # Beyaz
    "text_sub":  "#94A3B8",  # Gri Alt Metin
    "text_dim":  "#475569",  # Koyu Gri
    "row_alt":   "#181824",  # Tablo Çizgili Satır
    "row_sel":   "#2D1B4E",  # Seçili Satır (Koyu Mor)
    "input_bg":  "#13131F",  # Girdi Alanı
}

def card_ss(): return f"background:{C['card']};border:1px solid {C['border']};border-radius:12px;"
def btn_primary_ss(): return f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C['accent']},stop:1 {C['accent2']});color:#FFF;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{opacity: 0.8;}}"
def btn_success_ss(): return f"QPushButton{{background:{C['success']};color:#000;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#34D399;}}"
def btn_warning_ss(): return f"QPushButton{{background:{C['warning']};color:#000;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}"
def input_ss(): return f"QLineEdit,QSpinBox,QDateEdit{{background:{C['input_bg']};color:{C['text']};border:1px solid {C['border']};border-radius:8px;padding:8px 12px;font-size:13px;}}"

TABLE_SS = f"""
    QTableWidget{{background:{C['card']};color:{C['text']};border:none;gridline-color:{C['border']};font-size:13px;selection-background-color:{C['row_sel']};outline:none;alternate-background-color:{C['row_alt']};}}
    QTableWidget::item{{padding:10px 14px;border-bottom:1px solid {C['border']};}}
    QHeaderView::section{{background:{C['sidebar']};color:{C['accent']};padding:10px 14px;border:none;border-bottom:2px solid {C['accent']};font-size:12px;font-weight:800;letter-spacing:0.5px;}}
"""

def shadow(widget, color_hex="#000000", radius=20, offset=4):
    fx = QGraphicsDropShadowEffect(widget)
    fx.setBlurRadius(radius); fx.setColor(QColor(color_hex)); fx.setOffset(0, offset)
    widget.setGraphicsEffect(fx)

class KpiCard(QFrame):
    def __init__(self, baslik, deger, alt, renk):
        super().__init__()
        self.setFixedHeight(114)
        self.setStyleSheet(f"QFrame{{background:{C['card']};border:1px solid {C['border']};border-radius:12px;border-top:4px solid {renk};}}")
        shadow(self)
        lay = QVBoxLayout(self); lay.setContentsMargins(20, 15, 20, 15); lay.setSpacing(4)
        lbl_t = QLabel(baslik.upper()); lbl_t.setStyleSheet(f"color:{C['text_sub']};font-size:11px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        self.lbl_v = QLabel(str(deger)); self.lbl_v.setStyleSheet(f"color:{renk};font-size:30px;font-weight:800;background:transparent;border:none;")
        lbl_a = QLabel(alt); lbl_a.setStyleSheet(f"color:{C['text_dim']};font-size:12px;background:transparent;border:none;")
        lay.addWidget(lbl_t); lay.addWidget(self.lbl_v); lay.addWidget(lbl_a)
    def guncelle(self, val): self.lbl_v.setText(str(val))

class SideBtn(QPushButton):
    def __init__(self, ikon, metin):
        super().__init__(f"  {ikon}  {metin}")
        self.setCheckable(True); self.setFixedHeight(50); self.setCursor(Qt.PointingHandCursor)
        self._refresh(False)
    def _refresh(self, aktif):
        if aktif: self.setStyleSheet(f"QPushButton{{background:rgba(139, 92, 246, 0.15);color:{C['accent']};border:none;border-left:4px solid {C['accent']};border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:800;}}")
        else: self.setStyleSheet(f"QPushButton{{background:transparent;color:{C['text_sub']};border:none;border-left:4px solid transparent;border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:600;}}QPushButton:hover{{background:{C['card']};color:{C['text']};border-left:4px solid {C['border']};}}")
    def setChecked(self, v): super().setChecked(v); self._refresh(v)

class DashboardPage(QWidget):
    def __init__(self, merkez: EtkinlikMerkezi):
        super().__init__()
        self.merkez = merkez
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🎟️  Sistem Özeti", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        self.kpi_row = QHBoxLayout(); lay.addLayout(self.kpi_row)
        self.c1 = KpiCard("Aktif Etkinlikler", 0, "Yayındaki Organizasyonlar", C['accent'])
        self.c2 = KpiCard("Toplam Bilet Satışı", 0, "Kesilen Bilet Adedi", C['success'])
        self.c3 = KpiCard("Toplam Katılımcı", 0, "Sisteme Kayıtlı Kullanıcılar", C['accent2'])
        for c in [self.c1, self.c2, self.c3]: self.kpi_row.addWidget(c)
        
        lay.addWidget(QLabel("Son Satılan Biletler", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:15px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["Bilet PNR", "Etkinlik Adı", "Katılımcı", "Kesim Tarihi"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)

    def refresh(self):
        etkinlikler = self.merkez.get_tum_etkinlikler()
        biletler = self.merkez.get_tum_biletler()
        katilimcilar = self.merkez.get_tum_katilimcilar()
        
        self.c1.guncelle(len(etkinlikler))
        self.c2.guncelle(len(biletler))
        self.c3.guncelle(len(katilimcilar))

        self.tablo.setRowCount(0)
        for b in reversed(biletler[-10:]):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            pnr = QTableWidgetItem(f"#{b.get_bilet_id()}")
            pnr.setForeground(QColor(C['accent2']))
            font = QFont(); font.setBold(True); pnr.setFont(font)
            
            self.tablo.setItem(r, 0, pnr)
            self.tablo.setItem(r, 1, QTableWidgetItem(b.get_etkinlik().get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(b.get_katilimci().get_ad()))
            self.tablo.setItem(r, 3, QTableWidgetItem(b.get_olusturma_tarihi().strftime("%d.%m.%Y %H:%M")))

class EtkinlikPage(QWidget):
    def __init__(self, merkez: EtkinlikMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("📅  Etkinlik Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Yeni Etkinlik Oluştur", styleSheet=f"color:{C['accent']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QGridLayout()
        self.e_id = QSpinBox(); self.e_id.setRange(1, 99999)
        self.e_ad = QLineEdit(); self.e_ad.setPlaceholderText("Konser, Konferans vb.")
        self.e_tarih = QDateEdit(); self.e_tarih.setCalendarPopup(True); self.e_tarih.setDate(QDate.currentDate())
        self.e_kapasite = QSpinBox(); self.e_kapasite.setRange(1, 500000)
        for w in [self.e_id, self.e_ad, self.e_tarih, self.e_kapasite]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Etkinlik ID", styleSheet=lbl_style), 0, 0); g.addWidget(self.e_id, 1, 0)
        g.addWidget(QLabel("Etkinlik Adı", styleSheet=lbl_style), 0, 1); g.addWidget(self.e_ad, 1, 1)
        g.addWidget(QLabel("Tarih", styleSheet=lbl_style), 0, 2); g.addWidget(self.e_tarih, 1, 2)
        g.addWidget(QLabel("Maksimum Kapasite", styleSheet=lbl_style), 0, 3); g.addWidget(self.e_kapasite, 1, 3)
        klay.addLayout(g)
        
        btn_ekle = QPushButton("＋ Etkinliği Yayına Al"); btn_ekle.setStyleSheet(btn_primary_ss()); btn_ekle.clicked.connect(self._etkinlik_ekle)
        klay.addWidget(btn_ekle, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Tüm Etkinlikler", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["ID", "Etkinlik Adı", "Tarih", "Maks. Kapasite"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _etkinlik_ekle(self):
        if not self.e_ad.text().strip():
            QMessageBox.warning(self, "Hata", "Etkinlik adı boş olamaz!")
            return
        e = Etkinlik(self.e_id.value(), self.e_ad.text(), self.e_tarih.date().toString("dd.MM.yyyy"), self.e_kapasite.value())
        ok, msg = self.merkez.etkinlik_ekle(e)
        if ok: 
            self.e_ad.clear()
            self.refresh()
            self.dashboard.refresh()
            QMessageBox.information(self, "Başarılı", msg)
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for e in self.merkez.get_tum_etkinlikler().values():
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(e.get_etkinlik_id())))
            
            ad_item = QTableWidgetItem(e.get_ad())
            font = QFont(); font.setBold(True); ad_item.setFont(font)
            ad_item.setForeground(QColor(C['accent'])) 
            self.tablo.setItem(r, 1, ad_item)
            
            self.tablo.setItem(r, 2, QTableWidgetItem(e.get_tarih()))
            self.tablo.setItem(r, 3, QTableWidgetItem(f"{e.get_kapasite()} Kişi"))

class BiletPage(QWidget):
    def __init__(self, merkez: EtkinlikMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🎟️  Bilet Satış & Kayıt Gişesi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        
        # Bilet Formu Grid
        g = QGridLayout()
        self.b_etkinlik = QSpinBox(); self.b_etkinlik.setRange(1, 99999)
        self.b_tc = QSpinBox(); self.b_tc.setRange(1, 99999999) # TC veya ID
        self.b_ad = QLineEdit(); self.b_ad.setPlaceholderText("Katılımcı Ad Soyad")
        self.b_mail = QLineEdit(); self.b_mail.setPlaceholderText("E-posta Adresi")
        
        for w in [self.b_etkinlik, self.b_tc, self.b_ad, self.b_mail]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Hangi Etkinlik (ID):", styleSheet=lbl_style), 0, 0); g.addWidget(self.b_etkinlik, 1, 0)
        g.addWidget(QLabel("Katılımcı ID/TC:", styleSheet=lbl_style), 0, 1); g.addWidget(self.b_tc, 1, 1)
        g.addWidget(QLabel("Ad Soyad:", styleSheet=lbl_style), 0, 2); g.addWidget(self.b_ad, 1, 2)
        g.addWidget(QLabel("E-Posta:", styleSheet=lbl_style), 0, 3); g.addWidget(self.b_mail, 1, 3)
        klay.addLayout(g)
        
        btn_satis = QPushButton("🎟️ Bileti Kes ve Kaydet"); btn_satis.setStyleSheet(btn_success_ss()); btn_satis.clicked.connect(self._bilet_kes)
        klay.addWidget(btn_satis, alignment=Qt.AlignRight)
        lay.addWidget(kart)
        lay.addStretch()

    def _bilet_kes(self):
        if not self.b_ad.text().strip():
            QMessageBox.warning(self, "Hata", "Katılımcı adı boş olamaz!")
            return
        
        # Bilet kesim işlemi, kapasite kontrolünü otomatik yapar
        ok, msg = self.merkez.bilet_kes(self.b_etkinlik.value(), self.b_tc.value(), self.b_ad.text(), self.b_mail.text())
        
        if ok: 
            QMessageBox.information(self, "Bilet Gişesi", msg)
            self.b_ad.clear(); self.b_mail.clear()
            self.dashboard.refresh()
            # Rapor sayfasını güncelle
            if hasattr(self.parentWidget().parentWidget(), 'p_rapor'):
                self.parentWidget().parentWidget().p_rapor.refresh()
        else: 
            # Kapasite doluysa Kırmızı Uyarı!
            QMessageBox.critical(self, "İşlem Reddedildi", msg)

# PROJEDE İSTENEN EKSTRA ÖZELLİK: RAPOR SAYFASI
class RaporPage(QWidget):
    def __init__(self, merkez: EtkinlikMerkezi):
        super().__init__()
        self.merkez = merkez
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("📈  Katılım ve Doluluk Raporu", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        lay.addWidget(QLabel("Etkinlik Bazlı Anlık Doluluk Verileri", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["Etkinlik ID", "Etkinlik Adı", "Kapasite", "Satılan Bilet (Katılan)", "Doluluk Oranı"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def refresh(self):
        self.tablo.setRowCount(0)
        rapor_verisi = self.merkez.katilim_raporu_getir()
        
        for r_data in rapor_verisi:
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(r_data["id"])))
            
            ad_item = QTableWidgetItem(r_data["ad"])
            font = QFont(); font.setBold(True); ad_item.setFont(font)
            self.tablo.setItem(r, 1, ad_item)
            
            self.tablo.setItem(r, 2, QTableWidgetItem(str(r_data["kapasite"])))
            
            katilan_item = QTableWidgetItem(str(r_data["katilan"]))
            katilan_item.setForeground(QColor(C['accent']))
            katilan_item.setFont(font)
            self.tablo.setItem(r, 3, katilan_item)
            
            # Doluluk Oranı Görselleştirme
            oran = r_data["doluluk"]
            oran_item = QTableWidgetItem(f"% {oran}")
            oran_item.setFont(font)
            if oran >= 100: oran_item.setForeground(QColor(C['danger'])) # Dolu
            elif oran >= 80: oran_item.setForeground(QColor(C['warning'])) # Az Kaldı
            else: oran_item.setForeground(QColor(C['success'])) # Yer Var
            
            self.tablo.setItem(r, 4, oran_item)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🎫 Proje 4 — Etkinlik ve Bilet Sistemi")
        self.setMinimumSize(1200, 750); self.setStyleSheet(f"QMainWindow{{background:{C['bg']};color:{C['text']};}}")

        self.merkez = EtkinlikMerkezi()
        self.merkez.test_verilerini_yukle()

        merkez_widget = QWidget(); merkez_widget.setStyleSheet(f"background:{C['bg']};"); self.setCentralWidget(merkez_widget)
        ana = QHBoxLayout(merkez_widget); ana.setContentsMargins(0, 0, 0, 0); ana.setSpacing(0)

        # YAN PANEL
        sidebar = QFrame(); sidebar.setFixedWidth(240); sidebar.setStyleSheet(f"background:{C['sidebar']};border-right:1px solid {C['border']};")
        sb = QVBoxLayout(sidebar); sb.setContentsMargins(0, 0, 0, 20); sb.setSpacing(0)
        
        logo = QFrame(); logo.setFixedHeight(80); logo.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C['accent']},stop:1 {C['accent2']});")
        ll = QVBoxLayout(logo); ll.setContentsMargins(20, 15, 20, 15)
        t1 = QLabel("🎫 TICKET MASTER"); t1.setStyleSheet("color:#FFF;font-size:18px;font-weight:900;background:transparent;")
        t2 = QLabel("Proje 4 Sistemi"); t2.setStyleSheet("color:rgba(255,255,255,0.7);font-size:12px;font-weight:800;background:transparent;")
        ll.addWidget(t1); ll.addWidget(t2); sb.addWidget(logo); sb.addSpacing(20)

        self.nav = []
        for ikon, metin in [("📊", "Sistem Özeti"), ("📅", "Etkinlik Yönetimi"), ("🎟️", "Bilet Satış Gişesi"), ("📈", "Katılım Raporu")]:
            btn = SideBtn(ikon, metin); btn.clicked.connect(lambda _, m=metin: self._goto(m))
            sb.addWidget(btn); self.nav.append(btn)
        sb.addStretch()
        
        self.lbl_saat = QLabel(); self.lbl_saat.setAlignment(Qt.AlignCenter); self.lbl_saat.setStyleSheet(f"color:{C['text_dim']};font-size:12px;font-weight:800;background:transparent;")
        sb.addWidget(self.lbl_saat); ana.addWidget(sidebar)

        # İÇERİK ALANI
        icerik = QWidget(); icerik.setStyleSheet(f"background:{C['bg']};")
        il = QVBoxLayout(icerik); il.setContentsMargins(0,0,0,0); il.setSpacing(0)

        topbar = QFrame(); topbar.setFixedHeight(55); topbar.setStyleSheet(f"background:{C['sidebar']};border-bottom:1px solid {C['border']};")
        tl = QHBoxLayout(topbar); tl.setContentsMargins(30, 0, 30, 0)
        self.lbl_page = QLabel("SİSTEM ÖZETİ"); self.lbl_page.setStyleSheet(f"color:{C['text']};font-size:15px;font-weight:800;background:transparent;")
        tl.addWidget(self.lbl_page); tl.addStretch()
        tl.addWidget(QLabel("👤 Yönetici", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        il.addWidget(topbar)

        self.stack = QStackedWidget(); self.stack.setStyleSheet(f"background:{C['bg']};")
        self.p_dashboard = DashboardPage(self.merkez)
        self.p_etkinlik = EtkinlikPage(self.merkez, self.p_dashboard)
        self.p_bilet = BiletPage(self.merkez, self.p_dashboard)
        self.p_rapor = RaporPage(self.merkez)
        
        for p in [self.p_dashboard, self.p_etkinlik, self.p_bilet, self.p_rapor]: self.stack.addWidget(p)
        il.addWidget(self.stack); ana.addWidget(icerik)

        self._goto("Sistem Özeti")
        t = QTimer(self); t.timeout.connect(lambda: self.lbl_saat.setText(datetime.now().strftime("%d.%m.%Y\n%H:%M:%S"))); t.start(1000)

    def _goto(self, sayfa):
        idx = {"Sistem Özeti": 0, "Etkinlik Yönetimi": 1, "Bilet Satış Gişesi": 2, "Katılım Raporu": 3}[sayfa]
        self.stack.setCurrentIndex(idx)
        self.lbl_page.setText(sayfa.upper())
        for i, b in enumerate(self.nav): b.setChecked(i == idx)
        
        # Sekme değiştiğinde sayfayı yenile
        if idx == 0: self.p_dashboard.refresh()
        elif idx == 1: self.p_etkinlik.refresh()
        elif idx == 3: self.p_rapor.refresh()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    p = QPalette()
    p.setColor(QPalette.Window, QColor(C['bg'])); p.setColor(QPalette.WindowText, QColor(C['text']))
    p.setColor(QPalette.Base, QColor(C['card'])); p.setColor(QPalette.AlternateBase, QColor(C['row_alt']))
    p.setColor(QPalette.Text, QColor(C['text'])); p.setColor(QPalette.Button, QColor(C['card']))
    p.setColor(QPalette.ButtonText, QColor(C['text'])); p.setColor(QPalette.Highlight, QColor(C['accent']))
    p.setColor(QPalette.HighlightedText, QColor("#FFF"))
    app.setPalette(p)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())