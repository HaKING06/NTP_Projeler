"""
============================================================
  PROJE 5: ONLINE KURS PLATFORMU (E-Learning System)
============================================================
Açıklama: Bu proje, Eğitmen, Kurs ve Öğrenci sınıfları
arasındaki çoklu ilişkileri (Composition) ve kontenjan 
kontrollerini Nesne Tabanlı Programlama ile simüle eder.
============================================================
"""

import sys
from datetime import datetime

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFrame,
    QStackedWidget, QHeaderView, QLineEdit, QGridLayout,
    QSpinBox, QMessageBox, QAbstractItemView, QGraphicsDropShadowEffect,
    QComboBox
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QPalette, QFont

# ============================================================
#  1. KISIM: İŞ MANTIĞI VE SINIFLAR (BACKEND)
# ============================================================

class Egitmen:
    """Kursu veren eğitmeni temsil eder."""
    def __init__(self, ad: str, uzmanlik: str):
        # Kapsülleme (Encapsulation)
        self.__ad = ad
        self.__uzmanlik = uzmanlik

    def get_ad(self) -> str:       return self.__ad
    def get_uzmanlik(self) -> str: return self.__uzmanlik

class Ogrenci:
    """Platforma kayıtlı öğrenciyi temsil eder."""
    def __init__(self, ogrenci_id: int, ad: str, email: str):
        self.__ogrenci_id = ogrenci_id
        self.__ad = ad
        self.__email = email
        self.__kayitli_kurslar = [] # Öğrencinin aldığı kursların listesi

    def get_ogrenci_id(self) -> int: return self.__ogrenci_id
    def get_ad(self) -> str:         return self.__ad
    def get_email(self) -> str:      return self.__email

    # HOCANIN LİSTESİNDE İSTENEN METOD
    def kurs_listesi(self) -> list:
        """Öğrencinin kayıtlı olduğu kursların listesini döndürür."""
        return self.__kayitli_kurslar

    def kursa_ekle(self, kurs: 'Kurs'):
        """Öğrencinin paneline kursu ekler (Sadece Kurs sınıfı tarafından tetiklenir)."""
        if kurs not in self.__kayitli_kurslar:
            self.__kayitli_kurslar.append(kurs)

class Kurs:
    """Platformdaki eğitim kursunu temsil eder."""
    def __init__(self, kurs_id: int, kurs_adi: str, egitmen: Egitmen, kontenjan: int):
        self.__kurs_id = kurs_id
        self.__kurs_adi = kurs_adi
        self.__egitmen = egitmen # Sınıf içine sınıf (Composition)
        self.__kontenjan = kontenjan
        self.__kayitli_ogrenciler = []

    def get_kurs_id(self) -> int:  return self.__kurs_id
    def get_kurs_adi(self) -> str: return self.__kurs_adi
    def get_egitmen(self) -> Egitmen: return self.__egitmen
    def get_kontenjan(self) -> int:   return self.__kontenjan
    def get_ogrenci_sayisi(self) -> int: return len(self.__kayitli_ogrenciler)

    # HOCANIN LİSTESİNDE İSTENEN METOD
    def ogrenci_kaydet(self, ogrenci: Ogrenci):
        """
        Kapasiteyi kontrol eder. Yer varsa öğrenciyi kursa yazar,
        ve öğrencinin 'kurs_listesi'ne bu kursu ekler.
        """
        if len(self.__kayitli_ogrenciler) >= self.__kontenjan:
            return False, f"Hata: '{self.__kurs_adi}' kursunun kontenjanı doludur!"
        
        if ogrenci in self.__kayitli_ogrenciler:
            return False, f"{ogrenci.get_ad()} bu kursa zaten kayıtlı."

        # Kursa öğrenciyi ekle
        self.__kayitli_ogrenciler.append(ogrenci)
        # Öğrencinin profiline de kursu ekle (Çift taraflı ilişki)
        ogrenci.kursa_ekle(self)
        
        return True, f"{ogrenci.get_ad()}, '{self.__kurs_adi}' kursuna başarıyla kaydedildi."

class PlatformMerkezi:
    """Tüm eğitmen, kurs ve öğrenci verilerini yöneten Sistem (Manager) Sınıfı."""
    def __init__(self):
        self.__egitmenler = []
        self.__kurslar = {}
        self.__ogrenciler = {}

    def egitmen_ekle(self, egitmen: Egitmen):
        self.__egitmenler.append(egitmen)
        return True, "Eğitmen sisteme eklendi."

    def kurs_ekle(self, kurs: Kurs):
        if kurs.get_kurs_id() in self.__kurslar:
            return False, "Bu ID ile bir kurs zaten mevcut!"
        self.__kurslar[kurs.get_kurs_id()] = kurs
        return True, "Kurs yayına alındı."

    def ogrenci_ekle(self, ogrenci: Ogrenci):
        if ogrenci.get_ogrenci_id() in self.__ogrenciler:
            return False, "Bu öğrenci numarası/ID zaten kayıtlı!"
        self.__ogrenciler[ogrenci.get_ogrenci_id()] = ogrenci
        return True, "Öğrenci hesabı oluşturuldu."

    def kursa_kayit_yap(self, ogrenci_id: int, kurs_id: int):
        ogrenci = self.__ogrenciler.get(ogrenci_id)
        kurs = self.__kurslar.get(kurs_id)

        if not ogrenci: return False, "Öğrenci bulunamadı!"
        if not kurs: return False, "Kurs bulunamadı!"

        # Kurs sınıfındaki metodu tetikliyoruz (Kontenjan kontrolü burada yapılır)
        return kurs.ogrenci_kaydet(ogrenci)

    def get_tum_egitmenler(self) -> list: return self.__egitmenler
    def get_tum_kurslar(self) -> dict: return self.__kurslar
    def get_tum_ogrenciler(self) -> dict: return self.__ogrenciler

    def test_verilerini_yukle(self):
        # Sunum için hazır veriler
        e1 = Egitmen("Ahmet Hoca", "Yapay Zeka ve Veri Bilimi")
        e2 = Egitmen("Ayşe Hoca", "Web Geliştirme (Frontend)")
        self.egitmen_ekle(e1); self.egitmen_ekle(e2)

        k1 = Kurs(101, "Sıfırdan Python ve OOP", e1, 50)
        k2 = Kurs(102, "İleri Seviye React.js", e2, 2) # Kapasite test için düşük tutuldu
        self.kurs_ekle(k1); self.kurs_ekle(k2)

        o1 = Ogrenci(1, "Yiğit Talha Gümüş", "yigit@iku.edu.tr")
        o2 = Ogrenci(2, "Halit Güneş", "halit@iku.edu.tr")
        self.ogrenci_ekle(o1); self.ogrenci_ekle(o2)

        self.kursa_kayit_yap(1, 101) # Yiğit Python kursuna girdi
        self.kursa_kayit_yap(2, 102) # Halit React kursuna girdi


# ============================================================
#  2. KISIM: ARAYÜZ (GUI) - ED-TECH (EĞİTİM) TEMASI
# ============================================================

# TEMA: Udemy/Coursera esintili, Göz yormayan İndigo ve Turkuaz (EdTech)
C = {
    "bg":        "#0A0F1C",  # Derin Uzay / Koyu Lacivert
    "sidebar":   "#111827",  # Yan Panel (Slate)
    "card":      "#1F2937",  # Kartlar
    "border":    "#374151",  # İnce Sınırlar
    "accent":    "#6366F1",  # İndigo (Mor-Mavi Ana Vurgu)
    "accent2":   "#14B8A6",  # Turkuaz (Teal)
    "success":   "#10B981",  # Yeşil
    "warning":   "#F59E0B",  # Turuncu
    "danger":    "#EF4444",  # Kırmızı
    "text":      "#F9FAFB",  # Parlak Beyaz
    "text_sub":  "#9CA3AF",  # Gümüş
    "text_dim":  "#6B7280",  # Koyu Gri
    "row_alt":   "#18212F",  # Tablo 2. Satır
    "row_sel":   "#312E81",  # Seçili Satır
    "input_bg":  "#0A0F1C",  
}

def card_ss(): return f"background:{C['card']};border:1px solid {C['border']};border-radius:12px;"
def btn_primary_ss(): return f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C['accent']},stop:1 #4F46E5);color:#FFF;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{opacity: 0.8;}}"
def btn_success_ss(): return f"QPushButton{{background:{C['accent2']};color:#FFF;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#0D9488;}}"
def input_ss(): return f"QLineEdit,QSpinBox,QComboBox{{background:{C['input_bg']};color:{C['text']};border:1px solid {C['border']};border-radius:8px;padding:8px 12px;font-size:13px;}}"

TABLE_SS = f"""
    QTableWidget{{background:{C['card']};color:{C['text']};border:none;gridline-color:{C['border']};font-size:13px;selection-background-color:{C['row_sel']};outline:none;alternate-background-color:{C['row_alt']};}}
    QTableWidget::item{{padding:10px 14px;border-bottom:1px solid {C['border']};}}
    QHeaderView::section{{background:{C['sidebar']};color:{C['accent']};padding:10px 14px;border:none;border-bottom:2px solid {C['accent']};font-size:12px;font-weight:800;letter-spacing:0.5px;}}
"""

def shadow(widget):
    fx = QGraphicsDropShadowEffect(widget)
    fx.setBlurRadius(25); fx.setColor(QColor(0, 0, 0, 100)); fx.setOffset(0, 5)
    widget.setGraphicsEffect(fx)

class KpiCard(QFrame):
    def __init__(self, baslik, deger, alt, renk):
        super().__init__()
        self.setFixedHeight(114)
        self.setStyleSheet(f"QFrame{{background:{C['card']};border:1px solid {C['border']};border-radius:12px;border-left:5px solid {renk};}}")
        shadow(self)
        lay = QVBoxLayout(self); lay.setContentsMargins(20, 15, 20, 15); lay.setSpacing(4)
        lbl_t = QLabel(baslik.upper()); lbl_t.setStyleSheet(f"color:{C['text_sub']};font-size:11px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        self.lbl_v = QLabel(str(deger)); self.lbl_v.setStyleSheet(f"color:{renk};font-size:32px;font-weight:800;background:transparent;border:none;")
        lbl_a = QLabel(alt); lbl_a.setStyleSheet(f"color:{C['text_dim']};font-size:12px;background:transparent;border:none;")
        lay.addWidget(lbl_t); lay.addWidget(self.lbl_v); lay.addWidget(lbl_a)
    def guncelle(self, val): self.lbl_v.setText(str(val))

class SideBtn(QPushButton):
    def __init__(self, ikon, metin):
        super().__init__(f"  {ikon}  {metin}")
        self.setCheckable(True); self.setFixedHeight(50); self.setCursor(Qt.PointingHandCursor)
        self._refresh(False)
    def _refresh(self, aktif):
        if aktif: self.setStyleSheet(f"QPushButton{{background:rgba(99, 102, 241, 0.15);color:{C['accent']};border:none;border-left:4px solid {C['accent']};border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:800;}}")
        else: self.setStyleSheet(f"QPushButton{{background:transparent;color:{C['text_sub']};border:none;border-left:4px solid transparent;border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:600;}}QPushButton:hover{{background:{C['card']};color:{C['text']};border-left:4px solid {C['border']};}}")
    def setChecked(self, v): super().setChecked(v); self._refresh(v)

class DashboardPage(QWidget):
    def __init__(self, merkez: PlatformMerkezi):
        super().__init__()
        self.merkez = merkez
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("📊  Platform Özeti", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        self.kpi_row = QHBoxLayout(); lay.addLayout(self.kpi_row)
        self.c1 = KpiCard("Aktif Eğitimler", 0, "Yayındaki Kurs Sayısı", C['accent'])
        self.c2 = KpiCard("Toplam Öğrenci", 0, "Sisteme Kayıtlı Kullanıcılar", C['success'])
        self.c3 = KpiCard("Uzman Eğitmenler", 0, "Ders Veren Akademisyenler", C['accent2'])
        for c in [self.c1, self.c2, self.c3]: self.kpi_row.addWidget(c)
        
        lay.addWidget(QLabel("Mevcut Kurs Kontenjan Durumları", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:15px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["Kurs Kodu", "Eğitim Adı", "Kontenjan", "Kayıtlı Öğrenci"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)

    def refresh(self):
        kurslar = self.merkez.get_tum_kurslar().values()
        self.c1.guncelle(len(kurslar))
        self.c2.guncelle(len(self.merkez.get_tum_ogrenciler()))
        self.c3.guncelle(len(self.merkez.get_tum_egitmenler()))

        self.tablo.setRowCount(0)
        for k in kurslar:
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            id_item = QTableWidgetItem(f"KRS-{k.get_kurs_id()}")
            id_item.setForeground(QColor(C['accent2']))
            font = QFont(); font.setBold(True); id_item.setFont(font)
            
            self.tablo.setItem(r, 0, id_item)
            self.tablo.setItem(r, 1, QTableWidgetItem(k.get_kurs_adi()))
            self.tablo.setItem(r, 2, QTableWidgetItem(str(k.get_kontenjan())))
            
            durum_item = QTableWidgetItem(f"{k.get_ogrenci_sayisi()} Kişi")
            if k.get_ogrenci_sayisi() >= k.get_kontenjan():
                durum_item.setText("🔴 KONTENJAN DOLU")
                durum_item.setForeground(QColor(C['danger']))
            else:
                durum_item.setForeground(QColor(C['success']))
            durum_item.setFont(font)
            self.tablo.setItem(r, 3, durum_item)

class EgitmenKursPage(QWidget):
    def __init__(self, merkez: PlatformMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🎓  Eğitmen & Kurs Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        # KURS OLUŞTURMA KARTI
        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Sisteme Yeni Kurs Ekle", styleSheet=f"color:{C['accent']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QGridLayout()
        self.k_id = QSpinBox(); self.k_id.setRange(1, 99999)
        self.k_ad = QLineEdit(); self.k_ad.setPlaceholderText("Örn: Python ile Backend")
        self.k_egitmen = QLineEdit(); self.k_egitmen.setPlaceholderText("Eğitmen Adı")
        self.k_uzmanlik = QLineEdit(); self.k_uzmanlik.setPlaceholderText("Uzmanlık Alanı")
        self.k_kontenjan = QSpinBox(); self.k_kontenjan.setRange(1, 5000)
        
        for w in [self.k_id, self.k_ad, self.k_egitmen, self.k_uzmanlik, self.k_kontenjan]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Kurs ID:", styleSheet=lbl_style), 0, 0); g.addWidget(self.k_id, 1, 0)
        g.addWidget(QLabel("Kurs Adı:", styleSheet=lbl_style), 0, 1); g.addWidget(self.k_ad, 1, 1)
        g.addWidget(QLabel("Eğitmen Adı:", styleSheet=lbl_style), 2, 0); g.addWidget(self.k_egitmen, 3, 0)
        g.addWidget(QLabel("Eğitmen Uzmanlığı:", styleSheet=lbl_style), 2, 1); g.addWidget(self.k_uzmanlik, 3, 1)
        g.addWidget(QLabel("Maks. Kontenjan:", styleSheet=lbl_style), 2, 2); g.addWidget(self.k_kontenjan, 3, 2)
        klay.addLayout(g)
        
        btn_ekle = QPushButton("＋ Kursu Yayına Al"); btn_ekle.setStyleSheet(btn_primary_ss()); btn_ekle.clicked.connect(self._kurs_ekle)
        klay.addWidget(btn_ekle, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        # TABLO
        lay.addWidget(QLabel("Platformdaki Tüm Eğitimler", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["Kurs ID", "Kurs Adı", "Eğitmen", "Uzmanlık"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _kurs_ekle(self):
        if not self.k_ad.text().strip() or not self.k_egitmen.text().strip():
            QMessageBox.warning(self, "Hata", "Kurs Adı ve Eğitmen alanları boş bırakılamaz!")
            return
        
        # Eğitmen Nesnesi Oluştur (Composition için)
        egitmen = Egitmen(self.k_egitmen.text(), self.k_uzmanlik.text())
        self.merkez.egitmen_ekle(egitmen)
        
        # Kurs Nesnesi Oluştur (İçine Eğitmen dahil edildi)
        kurs = Kurs(self.k_id.value(), self.k_ad.text(), egitmen, self.k_kontenjan.value())
        ok, msg = self.merkez.kurs_ekle(kurs)
        
        if ok: 
            self.k_ad.clear(); self.k_egitmen.clear(); self.k_uzmanlik.clear()
            self.refresh()
            self.dashboard.refresh()
            
            # Öğrenci kayıt sekmesindeki açılır menüyü de güncelle
            if hasattr(self.parentWidget().parentWidget(), 'p_ogrenci'):
                self.parentWidget().parentWidget().p_ogrenci.combo_guncelle()
            QMessageBox.information(self, "Sistem", msg)
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for k in self.merkez.get_tum_kurslar().values():
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(k.get_kurs_id())))
            
            ad_item = QTableWidgetItem(k.get_kurs_adi())
            font = QFont(); font.setBold(True); ad_item.setFont(font)
            ad_item.setForeground(QColor(C['accent'])) 
            self.tablo.setItem(r, 1, ad_item)
            
            self.tablo.setItem(r, 2, QTableWidgetItem(k.get_egitmen().get_ad()))
            self.tablo.setItem(r, 3, QTableWidgetItem(k.get_egitmen().get_uzmanlik()))

class OgrenciIslemleriPage(QWidget):
    def __init__(self, merkez: PlatformMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("💻  Öğrenci & Kayıt İşlemleri", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        
        # Öğrenci Kayıt Grid
        g = QHBoxLayout()
        self.o_id = QSpinBox(); self.o_id.setRange(1, 99999)
        self.o_ad = QLineEdit(); self.o_ad.setPlaceholderText("Öğrenci Ad Soyad")
        self.o_email = QLineEdit(); self.o_email.setPlaceholderText("E-posta")
        self.combo = QComboBox() # Kurs Seçimi
        
        for w in [self.o_id, self.o_ad, self.o_email, self.combo]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Ogr. ID:", styleSheet=lbl_style)); g.addWidget(self.o_id)
        g.addWidget(QLabel("Ad Soyad:", styleSheet=lbl_style)); g.addWidget(self.o_ad)
        g.addWidget(QLabel("E-posta:", styleSheet=lbl_style)); g.addWidget(self.o_email)
        klay.addLayout(g)

        g2 = QHBoxLayout()
        g2.addWidget(QLabel("Kayıt Olunacak Kurs:", styleSheet=f"color:{C['accent2']};font-size:13px;font-weight:800;background:transparent;"))
        g2.addWidget(self.combo)
        btn_kaydet = QPushButton("✓ Kursa Kaydol"); btn_kaydet.setStyleSheet(btn_success_ss()); btn_kaydet.clicked.connect(self._kursa_yazil)
        g2.addWidget(btn_kaydet)
        klay.addLayout(g2)
        lay.addWidget(kart)

        # HOCANIN LİSTESİNDE İSTENEN "KURS LİSTESİ" ÖZELLİĞİ
        lay.addWidget(QLabel("Öğrencilerin Aldığı Kurslar (kurs_listesi metodu)", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(3)
        self.tablo.setHorizontalHeaderLabels(["Öğrenci No", "Ad Soyad", "Kayıtlı Olduğu Eğitimler"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        
        self.combo_guncelle()
        self.refresh()

    def combo_guncelle(self):
        self.combo.clear()
        for k in self.merkez.get_tum_kurslar().values():
            self.combo.addItem(f"{k.get_kurs_adi()} (Kapasite: {k.get_ogrenci_sayisi()}/{k.get_kontenjan()})", k.get_kurs_id())

    def _kursa_yazil(self):
        if not self.o_ad.text().strip():
            QMessageBox.warning(self, "Hata", "Öğrenci adı giriniz!")
            return
            
        kurs_id = self.combo.currentData()
        if not kurs_id: return

        # Öğrenciyi kontrol et, yoksa sisteme ekle
        ogrenci = self.merkez.get_tum_ogrenciler().get(self.o_id.value())
        if not ogrenci:
            ogrenci = Ogrenci(self.o_id.value(), self.o_ad.text(), self.o_email.text())
            self.merkez.ogrenci_ekle(ogrenci)

        # Kursa kayıt işlemini tetikle (ogrenci_kaydet metodu çalışır)
        ok, msg = self.merkez.kursa_kayit_yap(ogrenci.get_ogrenci_id(), kurs_id)
        
        if ok:
            QMessageBox.information(self, "Kayıt Başarılı", msg)
            self.o_ad.clear(); self.o_email.clear()
            self.combo_guncelle()
            self.refresh()
            self.dashboard.refresh()
        else:
            QMessageBox.critical(self, "Kayıt Reddedildi", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for o in reversed(list(self.merkez.get_tum_ogrenciler().values())):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(o.get_ogrenci_id())))
            
            ad_item = QTableWidgetItem(o.get_ad())
            font = QFont(); font.setBold(True); ad_item.setFont(font)
            self.tablo.setItem(r, 1, ad_item)
            
            # HOCAYA ŞOV KISMI: kurs_listesi() metodunu kullanarak verileri çekiyoruz
            alinan_kurslar = o.kurs_listesi()
            kurs_isimleri = ", ".join([k.get_kurs_adi() for k in alinan_kurslar])
            
            if not kurs_isimleri: kurs_isimleri = "Henüz kursa kayıtlı değil."
            
            kurs_item = QTableWidgetItem(kurs_isimleri)
            kurs_item.setForeground(QColor(C['accent2']))
            self.tablo.setItem(r, 2, kurs_item)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🎓 Proje 5 — Online Kurs Platformu")
        self.setMinimumSize(1200, 750); self.setStyleSheet(f"QMainWindow{{background:{C['bg']};color:{C['text']};}}")

        self.merkez = PlatformMerkezi()
        self.merkez.test_verilerini_yukle()

        merkez_widget = QWidget(); merkez_widget.setStyleSheet(f"background:{C['bg']};"); self.setCentralWidget(merkez_widget)
        ana = QHBoxLayout(merkez_widget); ana.setContentsMargins(0, 0, 0, 0); ana.setSpacing(0)

        # YAN PANEL
        sidebar = QFrame(); sidebar.setFixedWidth(240); sidebar.setStyleSheet(f"background:{C['sidebar']};border-right:1px solid {C['border']};")
        sb = QVBoxLayout(sidebar); sb.setContentsMargins(0, 0, 0, 20); sb.setSpacing(0)
        
        logo = QFrame(); logo.setFixedHeight(80); logo.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C['accent']},stop:1 {C['accent2']});")
        ll = QVBoxLayout(logo); ll.setContentsMargins(20, 15, 20, 15)
        t1 = QLabel("🎓 ED-TECH HUB"); t1.setStyleSheet("color:#FFF;font-size:18px;font-weight:900;background:transparent;")
        t2 = QLabel("Proje 5 Platformu"); t2.setStyleSheet("color:rgba(255,255,255,0.8);font-size:12px;font-weight:800;background:transparent;")
        ll.addWidget(t1); ll.addWidget(t2); sb.addWidget(logo); sb.addSpacing(20)

        self.nav = []
        for ikon, metin in [("📊", "Platform Özeti"), ("🎓", "Eğitmen & Kurs"), ("💻", "Öğrenci Kayıt")]:
            btn = SideBtn(ikon, metin); btn.clicked.connect(lambda _, m=metin: self._goto(m))
            sb.addWidget(btn); self.nav.append(btn)
        sb.addStretch()
        
        self.lbl_saat = QLabel(); self.lbl_saat.setAlignment(Qt.AlignCenter); self.lbl_saat.setStyleSheet(f"color:{C['text_dim']};font-size:12px;font-weight:800;background:transparent;")
        sb.addWidget(self.lbl_saat); ana.addWidget(sidebar)

        # İÇERİK ALANI
        icerik = QWidget(); icerik.setStyleSheet(f"background:{C['bg']};")
        il = QVBoxLayout(icerik); il.setContentsMargins(0,0,0,0); il.setSpacing(0)

        topbar = QFrame(); topbar.setFixedHeight(55); topbar.setStyleSheet(f"background:{C['sidebar']};border-bottom:1px solid {C['border']};")
        tl = QHBoxLayout(topbar); tl.setContentsMargins(30, 0, 30, 0)
        self.lbl_page = QLabel("PLATFORM ÖZETİ"); self.lbl_page.setStyleSheet(f"color:{C['text']};font-size:15px;font-weight:800;background:transparent;")
        tl.addWidget(self.lbl_page); tl.addStretch()
        tl.addWidget(QLabel("👤 Yönetici", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        il.addWidget(topbar)

        self.stack = QStackedWidget(); self.stack.setStyleSheet(f"background:{C['bg']};")
        self.p_dashboard = DashboardPage(self.merkez)
        self.p_egitmen = EgitmenKursPage(self.merkez, self.p_dashboard)
        self.p_ogrenci = OgrenciIslemleriPage(self.merkez, self.p_dashboard)
        
        for p in [self.p_dashboard, self.p_egitmen, self.p_ogrenci]: self.stack.addWidget(p)
        il.addWidget(self.stack); ana.addWidget(icerik)

        self._goto("Platform Özeti")
        t = QTimer(self); t.timeout.connect(lambda: self.lbl_saat.setText(datetime.now().strftime("%d.%m.%Y\n%H:%M:%S"))); t.start(1000)

    def _goto(self, sayfa):
        idx = {"Platform Özeti": 0, "Eğitmen & Kurs": 1, "Öğrenci Kayıt": 2}[sayfa]
        self.stack.setCurrentIndex(idx)
        self.lbl_page.setText(sayfa.upper())
        for i, b in enumerate(self.nav): b.setChecked(i == idx)
        
        if idx == 0: self.p_dashboard.refresh()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    p = QPalette()
    p.setColor(QPalette.Window, QColor(C['bg'])); p.setColor(QPalette.WindowText, QColor(C['text']))
    p.setColor(QPalette.Base, QColor(C['card'])); p.setColor(QPalette.AlternateBase, QColor(C['row_alt']))
    p.setColor(QPalette.Text, QColor(C['text'])); p.setColor(QPalette.Button, QColor(C['card']))
    p.setColor(QPalette.ButtonText, QColor(C['text'])); p.setColor(QPalette.Highlight, QColor(C['accent']))
    p.setColor(QPalette.HighlightedText, QColor("#FFF"))
    app.setPalette(p)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())