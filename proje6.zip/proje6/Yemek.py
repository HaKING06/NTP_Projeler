"""
============================================================
  PROJE 6: YEMEK TARİF PLATFORMU
============================================================
Açıklama: Bu proje, yemek tariflerinin eklendiği, malzemelerin
tutulduğu ve kullanıcıların bu tarifleri puanlayabildiği 
bir platformu OOP mantığıyla sağlar.
============================================================
"""

import sys
from datetime import datetime, timedelta

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFrame,
    QStackedWidget, QHeaderView, QLineEdit, QGridLayout,
    QSpinBox, QMessageBox, QAbstractItemView, QGraphicsDropShadowEffect
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QPalette, QFont

# ============================================================
#  1. KISIM: İŞ MANTIĞI VE SINIFLAR (BACKEND)
# ============================================================

class Malzeme:
    def __init__(self, malzeme_adi: str, miktar: str):
        self.__malzeme_adi = malzeme_adi
        self.__miktar = miktar

    def get_malzeme_adi(self) -> str: return self.__malzeme_adi
    def get_miktar(self) -> str: return self.__miktar
    def __str__(self): return f"{self.__miktar} {self.__malzeme_adi}"


class Tarif:
    def __init__(self, tarif_id: int, tarif_adi: str, kategori: str, hazirlama_suresi: int):
        self.__tarif_id = tarif_id
        self.__tarif_adi = tarif_adi
        self.__kategori = kategori
        self.__hazirlama_suresi = hazirlama_suresi # dakika cinsinden
        self.__malzemeler = []
        self.__degerlendirmeler = [] # Verilen puanların listesi

    def get_tarif_id(self) -> int: return self.__tarif_id
    def get_tarif_adi(self) -> str: return self.__tarif_adi
    def get_kategori(self) -> str: return self.__kategori
    def get_hazirlama_suresi(self) -> int: return self.__hazirlama_suresi
    def get_malzemeler(self) -> list: return self.__malzemeler
    
    def malzeme_ekle(self, malzeme: Malzeme):
        self.__malzemeler.append(malzeme)

    def tarif_guncelle(self, yeni_ad: str, yeni_kategori: str, yeni_sure: int):
        if yeni_ad: self.__tarif_adi = yeni_ad
        if yeni_kategori: self.__kategori = yeni_kategori
        if yeni_sure > 0: self.__hazirlama_suresi = yeni_sure

    def puani_kaydet(self, puan: int):
        self.__degerlendirmeler.append(puan)

    def ortalama_puan(self) -> float:
        if not self.__degerlendirmeler:
            return 0.0
        return sum(self.__degerlendirmeler) / len(self.__degerlendirmeler)


class Degerlendirme:
    def __init__(self, islem_id: int, kullanici: 'Kullanici', tarif: Tarif, puan: int):
        self.__islem_id = islem_id
        self.__kullanici = kullanici
        self.__tarif = tarif
        self.__puan = puan
        self.__tarih = datetime.now()

    def get_islem_id(self) -> int: return self.__islem_id
    def get_kullanici(self) -> 'Kullanici': return self.__kullanici
    def get_tarif(self) -> Tarif: return self.__tarif
    def get_puan(self) -> int: return self.__puan
    def get_tarih(self) -> datetime: return self.__tarih

    # Sunum için tarihi geriye alma metodu
    def _test_icin_tarih_degistir(self, gun_farki):
        self.__tarih -= timedelta(days=gun_farki)


class Kullanici:
    def __init__(self, kullanici_id: int, ad: str):
        self.__kullanici_id = kullanici_id
        self.__ad = ad
        self.__yaptigi_degerlendirmeler = []

    def get_kullanici_id(self) -> int: return self.__kullanici_id
    def get_ad(self) -> str: return self.__ad
    def get_yaptigi_degerlendirmeler(self) -> list: return self.__yaptigi_degerlendirmeler

    def tarif_degerlendir(self, islem: Degerlendirme):
        tarif = islem.get_tarif()
        puan = islem.get_puan()
        
        if 1 <= puan <= 5:
            self.__yaptigi_degerlendirmeler.append(islem)
            tarif.puani_kaydet(puan)
            return True, f"{self.__ad}, '{tarif.get_tarif_adi()}' tarifine {puan} yıldız verdi!"
        return False, "Puan 1 ile 5 arasında olmalıdır."


class PlatformMerkezi:
    def __init__(self):
        self.__tarifler = {}
        self.__kullanicilar = {}
        self.__islem_gecmisi = []
        self.__son_islem_id = 8000

    def tarif_ekle(self, tarif: Tarif):
        if tarif.get_tarif_id() in self.__tarifler: 
            return False, "Bu ID ile tarif zaten var."
        self.__tarifler[tarif.get_tarif_id()] = tarif
        return True, "Tarif platforma eklendi."

    def kullanici_ekle(self, kullanici: Kullanici):
        if kullanici.get_kullanici_id() in self.__kullanicilar: 
            return False, "Bu ID ile kullanıcı zaten var."
        self.__kullanicilar[kullanici.get_kullanici_id()] = kullanici
        return True, "Kullanıcı sisteme kaydedildi."

    def get_tarifler(self): return self.__tarifler
    def get_kullanicilar(self): return self.__kullanicilar
    def get_islemler(self): return self.__islem_gecmisi

    def yeni_degerlendirme(self, kullanici_id: int, tarif_id: int, puan: int):
        kullanici = self.__kullanicilar.get(kullanici_id)
        tarif = self.__tarifler.get(tarif_id)
        
        if not kullanici: return False, "Kullanıcı bulunamadı!"
        if not tarif: return False, "Tarif bulunamadı!"
        
        yeni_islem = Degerlendirme(self.__son_islem_id, kullanici, tarif, puan)
        ok, msg = kullanici.tarif_degerlendir(yeni_islem)
        
        if ok:
            self.__islem_gecmisi.append(yeni_islem)
            self.__son_islem_id += 1
        return ok, msg

    # SUNUM İÇİN SAHTE VERİ ÜRETİCİ
    def sahte_verileri_yukle(self):
        # 1. Kullanıcıları ekleyelim
        self.kullanici_ekle(Kullanici(1, "Berkkan Kahraman"))
        self.kullanici_ekle(Kullanici(2, "Jimmy Tyler"))
        self.kullanici_ekle(Kullanici(3, "Alp Akcelep"))
        self.kullanici_ekle(Kullanici(4, "Halit Güneş"))

        # 2. Tarifleri Ekleyelim (Yüksek Protein & Sporcu Odaklı)
        t1 = Tarif(101, "Yüksek Proteinli Tavuk Sote", "Ana Yemek", 25)
        t1.malzeme_ekle(Malzeme("Tavuk Göğsü", "300 gr"))
        t1.malzeme_ekle(Malzeme("Zeytinyağı", "1 Yemek Kaşığı"))
        self.tarif_ekle(t1)

        t2 = Tarif(102, "Ton Balıklı Fit Salata", "Salata", 10)
        t2.malzeme_ekle(Malzeme("Ton Balığı", "1 Kutu"))
        t2.malzeme_ekle(Malzeme("Yeşillik", "1 Kase"))
        self.tarif_ekle(t2)

        t3 = Tarif(103, "Yulaflı Yumurta Beyazı Omlet", "Kahvaltı", 15)
        t3.malzeme_ekle(Malzeme("Yumurta Beyazı", "4 Adet"))
        t3.malzeme_ekle(Malzeme("Yulaf Ezmesi", "50 gr"))
        self.tarif_ekle(t3)
        
        self.tarif_ekle(Tarif(104, "Fırında Somon", "Deniz Ürünleri", 35))
        self.tarif_ekle(Tarif(105, "Lor Peynirli Pankek", "Tatlı / Ara Öğün", 20))

        # 3. Değerlendirme Senaryoları
        self.yeni_degerlendirme(1, 101, 5) # Berkkan tavuk soteye 5 verdi
        self.__islem_gecmisi[-1]._test_icin_tarih_degistir(2)

        self.yeni_degerlendirme(2, 103, 4) # Jimmy omlete 4 verdi
        self.__islem_gecmisi[-1]._test_icin_tarih_degistir(1)
        
        self.yeni_degerlendirme(3, 101, 4) # Alp de tavuk soteyi denedi
        self.yeni_degerlendirme(4, 102, 5) # Halit salataya 5 verdi


# ============================================================
#  2. KISIM: ARAYÜZ (GUI) - GÖZ YORMAYAN MODERN TEMA
# ============================================================

C = {
    "bg":        "#1E1E2E",  
    "sidebar":   "#181825",  
    "card":      "#313244",  
    "border":    "#45475A",  
    "accent":    "#89B4FA",  
    "accent2":   "#74C7EC",  
    "success":   "#A6E3A1",  
    "warning":   "#F9E2AF",  
    "danger":    "#F38BA8",  
    "text":      "#CDD6F4",  
    "text_sub":  "#A6ADC8",  
    "text_dim":  "#7F849C",  
    "row_alt":   "#25253A",  
    "row_sel":   "#3B4252",  
    "input_bg":  "#11111B",  
}

def card_ss(): return f"background:{C['card']};border:1px solid {C['border']};border-radius:12px;"
def btn_primary_ss(): return f"QPushButton{{background:{C['accent']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:{C['accent2']};}}"
def btn_success_ss(): return f"QPushButton{{background:{C['success']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#87D481;}}"
def btn_warning_ss(): return f"QPushButton{{background:{C['warning']};color:#11111B;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#EBD399;}}"
def input_ss(): return f"QLineEdit,QSpinBox{{background:{C['input_bg']};color:{C['text']};border:1px solid {C['border']};border-radius:8px;padding:8px 12px;font-size:13px;}}"

TABLE_SS = f"""
    QTableWidget{{background:{C['card']};color:{C['text']};border:none;gridline-color:{C['border']};font-size:13px;selection-background-color:{C['row_sel']};outline:none;alternate-background-color:{C['row_alt']};}}
    QTableWidget::item{{padding:10px 14px;border-bottom:1px solid {C['border']};}}
    QHeaderView::section{{background:{C['sidebar']};color:{C['accent']};padding:10px 14px;border:none;border-bottom:2px solid {C['accent']};font-size:12px;font-weight:800;letter-spacing:0.5px;}}
"""

def shadow(widget):
    fx = QGraphicsDropShadowEffect(widget)
    fx.setBlurRadius(20); fx.setColor(QColor(0, 0, 0, 60)); fx.setOffset(0, 4)
    widget.setGraphicsEffect(fx)


class KpiCard(QFrame):
    def __init__(self, baslik, deger, alt, renk):
        super().__init__()
        self.setFixedHeight(114)
        self.setStyleSheet(f"QFrame{{background:{C['card']};border:1px solid {C['border']};border-radius:12px;border-left:5px solid {renk};}}")
        shadow(self)
        lay = QVBoxLayout(self); lay.setContentsMargins(20, 15, 20, 15); lay.setSpacing(4)
        lbl_t = QLabel(baslik.upper()); lbl_t.setStyleSheet(f"color:{C['text_sub']};font-size:11px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        self.lbl_v = QLabel(str(deger)); self.lbl_v.setStyleSheet(f"color:{renk};font-size:30px;font-weight:800;background:transparent;border:none;")
        lbl_a = QLabel(alt); lbl_a.setStyleSheet(f"color:{C['text_dim']};font-size:12px;background:transparent;border:none;")
        lay.addWidget(lbl_t); lay.addWidget(self.lbl_v); lay.addWidget(lbl_a)
    def guncelle(self, val): self.lbl_v.setText(str(val))

class SideBtn(QPushButton):
    def __init__(self, ikon, metin):
        super().__init__(f"  {ikon}  {metin}")
        self.setCheckable(True); self.setFixedHeight(50); self.setCursor(Qt.PointingHandCursor)
        self._refresh(False)
    def _refresh(self, aktif):
        if aktif: self.setStyleSheet(f"QPushButton{{background:rgba(137, 180, 250, 0.1);color:{C['accent']};border:none;border-left:4px solid {C['accent']};border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:800;}}")
        else: self.setStyleSheet(f"QPushButton{{background:transparent;color:{C['text_sub']};border:none;border-left:4px solid transparent;border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:600;}}QPushButton:hover{{background:{C['card']};color:{C['text']};border-left:4px solid {C['border']};}}")
    def setChecked(self, v): super().setChecked(v); self._refresh(v)

class DashboardPage(QWidget):
    def __init__(self, merkez: PlatformMerkezi):
        super().__init__()
        self.merkez = merkez
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lbl = QLabel("📊  Platform Özeti")
        lbl.setStyleSheet(f"color:{C['text']};font-size:24px;font-weight:800;")
        lay.addWidget(lbl)

        self.kpi_row = QHBoxLayout(); lay.addLayout(self.kpi_row)
        self.c1 = KpiCard("Sistemdeki Tarif", 0, "Yemek Çeşitleri", C['accent'])
        self.c2 = KpiCard("Aktif Kullanıcı", 0, "Kayıtlı Gurmeler", C['success'])
        self.c3 = KpiCard("Toplam Yorum", 0, "Yapılan Değerlendirmeler", C['warning'])
        for c in [self.c1, self.c2, self.c3]: self.kpi_row.addWidget(c)
        
        lay.addWidget(QLabel("Son Değerlendirmeler (Canlı Log)", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:15px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["Puan", "İşlem No", "Kullanıcı", "Tarif Adı", "İşlem Tarihi"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)

    def refresh(self):
        tarifler = self.merkez.get_tarifler().values()
        kullanicilar = self.merkez.get_kullanicilar().values()
        islemler = self.merkez.get_islemler()
        
        self.c1.guncelle(len(tarifler))
        self.c2.guncelle(len(kullanicilar))
        self.c3.guncelle(len(islemler))

        self.tablo.setRowCount(0)
        for i in reversed(islemler[-10:]):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            
            puan_str = "⭐" * i.get_puan()
            item_puan = QTableWidgetItem(puan_str)
            item_puan.setForeground(QColor(C['warning']))
            font = QFont(); font.setBold(True); item_puan.setFont(font)
            
            self.tablo.setItem(r, 0, item_puan)
            self.tablo.setItem(r, 1, QTableWidgetItem(f"#{i.get_islem_id()}"))
            self.tablo.setItem(r, 2, QTableWidgetItem(i.get_kullanici().get_ad()))
            self.tablo.setItem(r, 3, QTableWidgetItem(i.get_tarif().get_tarif_adi()))
            self.tablo.setItem(r, 4, QTableWidgetItem(i.get_tarih().strftime("%d.%m.%Y - %H:%M")))

class TarifYonetimPage(QWidget):
    def __init__(self, merkez: PlatformMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🍳  Tarif Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Mutfak: Yeni Tarif Ekle", styleSheet=f"color:{C['accent']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QGridLayout()
        self.t_id = QSpinBox(); self.t_id.setRange(1, 9999)
        self.t_ad = QLineEdit(); self.t_ad.setPlaceholderText("Tarif Adı (örn. Yulaf Omlet)")
        self.t_kat = QLineEdit(); self.t_kat.setPlaceholderText("Kategori (örn. Kahvaltı)")
        self.t_sure = QSpinBox(); self.t_sure.setRange(1, 500); self.t_sure.setSuffix(" Dk")
        
        for w in [self.t_id, self.t_ad, self.t_kat, self.t_sure]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Tarif ID", styleSheet=lbl_style), 0, 0); g.addWidget(self.t_id, 1, 0)
        g.addWidget(QLabel("Tarif Adı", styleSheet=lbl_style), 0, 1); g.addWidget(self.t_ad, 1, 1)
        g.addWidget(QLabel("Kategori", styleSheet=lbl_style), 0, 2); g.addWidget(self.t_kat, 1, 2)
        g.addWidget(QLabel("Süre (Dakika)", styleSheet=lbl_style), 0, 3); g.addWidget(self.t_sure, 1, 3)
        klay.addLayout(g)
        
        btn_tarif = QPushButton("＋ Tarif Kaydet"); btn_tarif.setStyleSheet(btn_primary_ss()); btn_tarif.clicked.connect(self._tarif_ekle)
        klay.addWidget(btn_tarif, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Tüm Tarifler Menüsü", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["ID", "Tarif Adı", "Kategori", "Hazırlama", "Ortalama Puan"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _tarif_ekle(self):
        if not self.t_ad.text().strip() or not self.t_kat.text().strip():
            QMessageBox.warning(self, "Hata", "Tarif adı ve Kategori boş olamaz!")
            return
        t = Tarif(self.t_id.value(), self.t_ad.text(), self.t_kat.text(), self.t_sure.value())
        ok, msg = self.merkez.tarif_ekle(t)
        if ok: 
            self.t_ad.clear(); self.t_kat.clear(); self.t_sure.setValue(1)
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for t in self.merkez.get_tarifler().values():
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(t.get_tarif_id())))
            self.tablo.setItem(r, 1, QTableWidgetItem(t.get_tarif_adi()))
            self.tablo.setItem(r, 2, QTableWidgetItem(t.get_kategori()))
            self.tablo.setItem(r, 3, QTableWidgetItem(f"{t.get_hazirlama_suresi()} Dk"))
            
            ort = t.ortalama_puan()
            ort_txt = f"⭐ {ort:.1f}/5.0" if ort > 0 else "Değerlendirilmedi"
            item_ort = QTableWidgetItem(ort_txt)
            if ort > 0: item_ort.setForeground(QColor(C['warning']))
            font = QFont(); font.setBold(True); item_ort.setFont(font)
            self.tablo.setItem(r, 4, item_ort)

class KullaniciYonetimPage(QWidget):
    def __init__(self, merkez: PlatformMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("👥  Kullanıcı Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Yeni Kullanıcı Ekle", styleSheet=f"color:{C['success']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QHBoxLayout()
        self.u_id = QSpinBox(); self.u_id.setRange(1, 9999)
        self.u_ad = QLineEdit(); self.u_ad.setPlaceholderText("Kullanıcı Ad Soyad")
        for w in [self.u_id, self.u_ad]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Kullanıcı ID:", styleSheet=lbl_style)); g.addWidget(self.u_id)
        g.addWidget(QLabel("Ad Soyad:", styleSheet=lbl_style)); g.addWidget(self.u_ad)
        klay.addLayout(g)
        
        btn_kullanici = QPushButton("＋ Kullanıcı Kaydet"); btn_kullanici.setStyleSheet(btn_success_ss()); btn_kullanici.clicked.connect(self._kullanici_ekle)
        klay.addWidget(btn_kullanici, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Sistemdeki Kullanıcılar", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(3)
        self.tablo.setHorizontalHeaderLabels(["ID", "Ad Soyad", "Yaptığı Değerlendirme Sayısı"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _kullanici_ekle(self):
        if not self.u_ad.text().strip():
            QMessageBox.warning(self, "Hata", "Ad Soyad boş olamaz!")
            return
        u = Kullanici(self.u_id.value(), self.u_ad.text())
        ok, msg = self.merkez.kullanici_ekle(u)
        if ok: 
            self.u_ad.clear()
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for u in self.merkez.get_kullanicilar().values():
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(u.get_kullanici_id())))
            self.tablo.setItem(r, 1, QTableWidgetItem(u.get_ad()))
            
            yorum_sayisi = len(u.get_yaptigi_degerlendirmeler())
            item = QTableWidgetItem(f"{yorum_sayisi} Yorum Yaptı")
            if yorum_sayisi > 0: 
                item.setForeground(QColor(C['accent2']))
                font = QFont(); font.setBold(True); item.setFont(font)
            self.tablo.setItem(r, 2, item)


class DegerlendirmePage(QWidget):
    def __init__(self, merkez: PlatformMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("⭐  Puanlama & Değerlendirme", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QHBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        
        self.d_kullanici = QSpinBox(); self.d_kullanici.setRange(1, 9999); self.d_kullanici.setStyleSheet(input_ss())
        self.d_tarif = QSpinBox(); self.d_tarif.setRange(1, 9999); self.d_tarif.setStyleSheet(input_ss())
        self.d_puan = QSpinBox(); self.d_puan.setRange(1, 5); self.d_puan.setStyleSheet(input_ss())
        self.d_puan.setPrefix("⭐ ")

        lbl_style = f"color:{C['text_sub']};font-size:13px;font-weight:800;background:transparent;"
        klay.addWidget(QLabel("Kullanıcı ID:", styleSheet=lbl_style)); klay.addWidget(self.d_kullanici)
        klay.addWidget(QLabel("Tarif ID:", styleSheet=lbl_style)); klay.addWidget(self.d_tarif)
        klay.addWidget(QLabel("Puan (1-5):", styleSheet=lbl_style)); klay.addWidget(self.d_puan)
        
        btn_puanla = QPushButton("Puan Ver"); btn_puanla.setStyleSheet(btn_warning_ss()); btn_puanla.clicked.connect(self._puanla)
        
        klay.addWidget(btn_puanla); klay.addStretch()
        lay.addWidget(kart)

        lay.addWidget(QLabel("Tüm Puanlama Geçmişi", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["Sistem İşlem No", "Kullanıcı Adı", "Tarif", "Verilen Puan"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _puanla(self):
        ok, msg = self.merkez.yeni_degerlendirme(self.d_kullanici.value(), self.d_tarif.value(), self.d_puan.value())
        QMessageBox.information(self, "İşlem Sonucu", msg)
        if ok: 
            self.d_puan.setValue(1)
            self._tum_sayfalari_guncelle()

    def _tum_sayfalari_guncelle(self):
        self.refresh()
        self.dashboard.refresh()
        if hasattr(self.parentWidget().parentWidget(), 'p_tarif'):
            self.parentWidget().parentWidget().p_tarif.refresh()
        if hasattr(self.parentWidget().parentWidget(), 'p_kullanici'):
            self.parentWidget().parentWidget().p_kullanici.refresh()

    def refresh(self):
        self.tablo.setRowCount(0)
        for i in reversed(self.merkez.get_islemler()):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(f"#{i.get_islem_id()}"))
            self.tablo.setItem(r, 1, QTableWidgetItem(i.get_kullanici().get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(i.get_tarif().get_tarif_adi()))
            
            puan_str = "⭐" * i.get_puan()
            item_puan = QTableWidgetItem(puan_str)
            item_puan.setForeground(QColor(C['warning']))
            self.tablo.setItem(r, 3, item_puan)
 
#============================================================
#  3. KISIM: ANA PENCERE VE GEZİNME
#============================================================
class MainWindow(QMainWindow): 
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🍳 Proje 6 — Yemek Tarif Platformu")
        self.setMinimumSize(1200, 750); self.setStyleSheet(f"QMainWindow{{background:{C['bg']};color:{C['text']};}}")

        self.merkez = PlatformMerkezi()
        self.merkez.sahte_verileri_yukle()

        merkez_widget = QWidget(); merkez_widget.setStyleSheet(f"background:{C['bg']};"); self.setCentralWidget(merkez_widget)
        ana = QHBoxLayout(merkez_widget); ana.setContentsMargins(0, 0, 0, 0); ana.setSpacing(0)

        # YAN PANEL
        sidebar = QFrame(); sidebar.setFixedWidth(240); sidebar.setStyleSheet(f"background:{C['sidebar']};border-right:1px solid {C['border']};")
        sb = QVBoxLayout(sidebar); sb.setContentsMargins(0, 0, 0, 20); sb.setSpacing(0)
        
        logo = QFrame(); logo.setFixedHeight(80); logo.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C['accent']},stop:1 {C['accent2']});")
        ll = QVBoxLayout(logo); ll.setContentsMargins(20, 15, 20, 15)
        t1 = QLabel("👨‍🍳 Mutfak Sırları"); t1.setStyleSheet("color:#11111B;font-size:17px;font-weight:900;background:transparent;")
        t2 = QLabel("Proje 6"); t2.setStyleSheet("color:rgba(17,17,27,0.7);font-size:12px;font-weight:800;background:transparent;")
        ll.addWidget(t1); ll.addWidget(t2); sb.addWidget(logo); sb.addSpacing(20)

        self.nav = []
        for ikon, metin in [("📊", "Özet Ekranı"), ("🍳", "Tarif Yönetimi"), ("👥", "Kullanıcı Yönetimi"), ("⭐", "Değerlendirme")]:
            btn = SideBtn(ikon, metin); btn.clicked.connect(lambda _, m=metin: self._goto(m))
            sb.addWidget(btn); self.nav.append(btn)
        sb.addStretch()
        
        self.lbl_saat = QLabel(); self.lbl_saat.setAlignment(Qt.AlignCenter); self.lbl_saat.setStyleSheet(f"color:{C['text_dim']};font-size:12px;font-weight:800;background:transparent;")
        sb.addWidget(self.lbl_saat); ana.addWidget(sidebar)

        # İÇERİK ALANI
        icerik = QWidget(); icerik.setStyleSheet(f"background:{C['bg']};")
        il = QVBoxLayout(icerik); il.setContentsMargins(0,0,0,0); il.setSpacing(0)

        topbar = QFrame(); topbar.setFixedHeight(55); topbar.setStyleSheet(f"background:{C['sidebar']};border-bottom:1px solid {C['border']};")
        tl = QHBoxLayout(topbar); tl.setContentsMargins(30, 0, 30, 0)
        self.lbl_page = QLabel("Özet Ekranı"); self.lbl_page.setStyleSheet(f"color:{C['text']};font-size:15px;font-weight:800;background:transparent;")
        tl.addWidget(self.lbl_page); tl.addStretch()
        tl.addWidget(QLabel("👤 Yönetici", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        il.addWidget(topbar)

        self.stack = QStackedWidget(); self.stack.setStyleSheet(f"background:{C['bg']};")
        self.p_dashboard = DashboardPage(self.merkez)
        self.p_tarif = TarifYonetimPage(self.merkez, self.p_dashboard)
        self.p_kullanici = KullaniciYonetimPage(self.merkez, self.p_dashboard)
        self.p_degerlendirme = DegerlendirmePage(self.merkez, self.p_dashboard)
        
        for p in [self.p_dashboard, self.p_tarif, self.p_kullanici, self.p_degerlendirme]: self.stack.addWidget(p)
        il.addWidget(self.stack); ana.addWidget(icerik)

        self._goto("Özet Ekranı")
        t = QTimer(self); t.timeout.connect(lambda: self.lbl_saat.setText(datetime.now().strftime("%d.%m.%Y\n%H:%M:%S"))); t.start(1000)

    def _goto(self, sayfa):
        idx = {"Özet Ekranı": 0, "Tarif Yönetimi": 1, "Kullanıcı Yönetimi": 2, "Değerlendirme": 3}[sayfa]
        self.stack.setCurrentIndex(idx)
        self.lbl_page.setText(sayfa.upper())
        for i, b in enumerate(self.nav): b.setChecked(i == idx)
        
        if idx == 0: self.p_dashboard.refresh()
        elif idx == 1: self.p_tarif.refresh()
        elif idx == 2: self.p_kullanici.refresh()
        elif idx == 3: self.p_degerlendirme.refresh()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    p = QPalette()
    p.setColor(QPalette.Window, QColor(C['bg'])); p.setColor(QPalette.WindowText, QColor(C['text']))
    p.setColor(QPalette.Base, QColor(C['card'])); p.setColor(QPalette.AlternateBase, QColor(C['row_alt']))
    p.setColor(QPalette.Text, QColor(C['text'])); p.setColor(QPalette.Button, QColor(C['card']))
    p.setColor(QPalette.ButtonText, QColor(C['text'])); p.setColor(QPalette.Highlight, QColor(C['accent']))
    p.setColor(QPalette.HighlightedText, QColor("#11111B"))
    app.setPalette(p)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())