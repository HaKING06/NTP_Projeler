"""
============================================================
  PROJE 10: BASİT CRM (MÜŞTERİ İLİŞKİLERİ YÖNETİMİ) SİSTEMİ
============================================================
Açıklama: Bu proje, Müşteri, Satış ve Destek Talebi 
yönetimini Nesne Tabanlı Programlama (OOP) ile sağlar.
Kurulum  : pip install PyQt5
============================================================
"""

import sys
from datetime import datetime

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFrame,
    QStackedWidget, QHeaderView, QLineEdit, QGridLayout,
    QSpinBox, QDoubleSpinBox, QMessageBox, QAbstractItemView, QGraphicsDropShadowEffect
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QPalette, QFont

# ============================================================
#  1. KISIM: İŞ MANTIĞI VE SINIFLAR (BACKEND)
# ============================================================
# CRM MERKEZİ SINIFI (TÜM VERİLER BURADA TUTULUR)
class Musteri: 
    def __init__(self, musteri_id: int, ad: str, telefon: str): # Müşteri sınıfı, müşteri bilgilerini tutar
        self.__musteri_id = musteri_id
        self.__ad = ad
        self.__telefon = telefon
        self.__kayit_tarihi = datetime.now() 

    def get_musteri_id(self) -> int: return self.__musteri_id
    def get_ad(self) -> str:         return self.__ad
    def get_telefon(self) -> str:    return self.__telefon
# SATIŞ SINIFI (Yapılan satışları temsil eder)
class Satis:
    def __init__(self, satis_id: int, urun: str, fiyat: float, musteri: Musteri):
        self.__satis_id = satis_id
        self.__urun = urun
        self.__fiyat = fiyat
        self.__musteri = musteri
        self.__tarih = datetime.now()

    def get_satis_id(self) -> int: return self.__satis_id
    def get_urun(self) -> str:     return self.__urun
    def get_fiyat(self) -> float:  return self.__fiyat
    def get_musteri(self) -> Musteri: return self.__musteri
    def get_tarih(self) -> datetime: return self.__tarih
# DESTEK TALEBİ SINIFI (Müşteri destek taleplerini temsil eder)
class DestekTalebi:
    def __init__(self, talep_id: int, aciklama: str, musteri: Musteri):
        self.__talep_id = talep_id
        self.__aciklama = aciklama
        self.__musteri = musteri
        self.__durum = "Açık" 
        self.__tarih = datetime.now()

    def get_talep_id(self) -> int: return self.__talep_id
    def get_aciklama(self) -> str: return self.__aciklama
    def get_musteri(self) -> Musteri: return self.__musteri
    def get_durum(self) -> str:    return self.__durum
    def get_tarih(self) -> datetime: return self.__tarih

    def talebi_kapat(self):
        self.__durum = "Çözüldü"
# CRM MERKEZİ SINIFI (TÜM VERİLER BURADA TUTULUR)
class CRMMerkezi:
    def __init__(self):
        self.__musteriler = {}
        self.__satislar = []
        self.__talepler = []
        
        self.__son_satis_id = 1000
        self.__son_talep_id = 5000

    def musteri_ekle(self, musteri: Musteri):
        if musteri.get_musteri_id() in self.__musteriler:
            return False, "Bu ID ile bir müşteri zaten kayıtlı!"
        self.__musteriler[musteri.get_musteri_id()] = musteri
        return True, f"{musteri.get_ad()} sisteme başarıyla eklendi."

    def get_musteri(self, musteri_id: int) -> Musteri:
        return self.__musteriler.get(musteri_id, None)

    def get_tum_musteriler(self): return self.__musteriler
    def get_tum_satislar(self): return self.__satislar
    def get_tum_talepler(self): return self.__talepler

    def yeni_satis_yap(self, musteri_id: int, urun: str, fiyat: float):
        musteri = self.get_musteri(musteri_id)
        if not musteri: return False, "Müşteri bulunamadı! Önce müşteriyi kaydedin."
        
        yeni_satis = Satis(self.__son_satis_id, urun, fiyat, musteri)
        self.__satislar.append(yeni_satis)
        self.__son_satis_id += 1
        return True, "Satış başarıyla kaydedildi."

    def yeni_talep_ac(self, musteri_id: int, aciklama: str):
        musteri = self.get_musteri(musteri_id)
        if not musteri: return False, "Müşteri bulunamadı!"
        
        yeni_talep = DestekTalebi(self.__son_talep_id, aciklama, musteri)
        self.__talepler.append(yeni_talep)
        self.__son_talep_id += 1
        return True, "Destek talebi teknik ekibe iletildi."
# Talep çözülme işlemi
    def talep_cozuldu_isaretle(self, talep_id: int):
        for talep in self.__talepler:
            if talep.get_talep_id() == talep_id:
                talep.talebi_kapat()
                return True, "Talep durumu 'Çözüldü' olarak güncellendi."
        return False, "Bu ID'ye ait talep bulunamadı."

    def test_verilerini_yukle(self):
        self.musteri_ekle(Musteri(1, "Halit Güneş", "0555 111 22 33"))
        self.musteri_ekle(Musteri(2, "Alp Akcelep", "0532 444 55 66"))
        self.musteri_ekle(Musteri(3, "Kurumsal A.Ş.", "0850 123 45 67"))
        
        self.yeni_satis_yap(1, "CRM Yazılım Paketi", 15000.0)
        self.yeni_satis_yap(3, "Sunucu Kurulumu", 25000.0)
        self.yeni_satis_yap(2, "SEO Danışmanlığı", 8500.0)
        
        # Test için uzun bir açıklama ekliyoruz
        uzun_aciklama = "Müşteri, yazılım paneline giriş yaparken 'Bağlantı Zaman Aşımı' hatası alıyor. Ağ ayarları kontrol edildi ancak sorun devam ediyor. Acil dönüş beklenmektedir."
        self.yeni_talep_ac(1, uzun_aciklama)
        self.yeni_talep_ac(3, "Sunucu performans optimizasyonu ve hızlandırma talebi.")

# ============================================================
#  2. KISIM: ARAYÜZ (GUI) - KURUMSAL CRM TEMASI
# ============================================================

C = {
    "bg":        "#0B132B",  
    "sidebar":   "#14213D",  
    "card":      "#1C2A48",  
    "border":    "#2E4063",  
    "accent":    "#48CAE4",  
    "accent2":   "#0077B6",  
    "success":   "#06D6A0",  
    "warning":   "#FFD166",  
    "danger":    "#EF476F",  
    "text":      "#FFFFFF",  
    "text_sub":  "#9EACC2",  
    "text_dim":  "#5D7196",  
    "row_alt":   "#16233B",  
    "row_sel":   "#0077B6",  
    "input_bg":  "#080E21",  
}
# STİL TANIMLARI (KURUMSAL TEMAYA UYGUN RENKLER VE TASARIMLAR)
def card_ss(): return f"background:{C['card']};border:1px solid {C['border']};border-radius:10px;"
def btn_primary_ss(): return f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C['accent2']},stop:1 {C['accent']});color:#000;border:none;border-radius:6px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#90E0EF;}}"
def btn_success_ss(): return f"QPushButton{{background:{C['success']};color:#000;border:none;border-radius:6px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#56E3B8;}}"
def btn_warning_ss(): return f"QPushButton{{background:{C['warning']};color:#000;border:none;border-radius:6px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#FFDF8C;}}"
def input_ss(): return f"QLineEdit,QSpinBox,QDoubleSpinBox{{background:{C['input_bg']};color:{C['text']};border:1px solid {C['border']};border-radius:6px;padding:8px 12px;font-size:13px;}}"

TABLE_SS = f"""
    QTableWidget{{background:{C['card']};color:{C['text']};border:none;gridline-color:{C['border']};font-size:13px;selection-background-color:{C['row_sel']};outline:none;alternate-background-color:{C['row_alt']};}}
    QTableWidget::item{{padding:10px 14px;border-bottom:1px solid {C['border']};}}
    QHeaderView::section{{background:{C['sidebar']};color:{C['accent']};padding:10px 14px;border:none;border-bottom:2px solid {C['accent']};font-size:12px;font-weight:800;letter-spacing:0.5px;}}
"""

def shadow(widget):
    fx = QGraphicsDropShadowEffect(widget)
    fx.setBlurRadius(20); fx.setColor(QColor(0, 0, 0, 80)); fx.setOffset(0, 4)
    widget.setGraphicsEffect(fx)

class KpiCard(QFrame):
    def __init__(self, baslik, deger, alt, renk):
        super().__init__()
        self.setFixedHeight(114)
        self.setStyleSheet(f"QFrame{{background:{C['card']};border:1px solid {C['border']};border-radius:10px;border-left:5px solid {renk};}}")
        shadow(self)
        lay = QVBoxLayout(self); lay.setContentsMargins(20, 15, 20, 15); lay.setSpacing(4)
        lbl_t = QLabel(baslik.upper()); lbl_t.setStyleSheet(f"color:{C['text_sub']};font-size:11px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        self.lbl_v = QLabel(str(deger)); self.lbl_v.setStyleSheet(f"color:{renk};font-size:30px;font-weight:800;background:transparent;border:none;")
        lbl_a = QLabel(alt); lbl_a.setStyleSheet(f"color:{C['text_dim']};font-size:12px;background:transparent;border:none;")
        lay.addWidget(lbl_t); lay.addWidget(self.lbl_v); lay.addWidget(lbl_a)
    def guncelle(self, val): self.lbl_v.setText(str(val))

class SideBtn(QPushButton):
    def __init__(self, ikon, metin):
        super().__init__(f"  {ikon}  {metin}")
        self.setCheckable(True); self.setFixedHeight(50); self.setCursor(Qt.PointingHandCursor)
        self._refresh(False)
    def _refresh(self, aktif):
        if aktif: self.setStyleSheet(f"QPushButton{{background:rgba(72, 202, 228, 0.15);color:{C['accent']};border:none;border-left:4px solid {C['accent']};border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:800;}}")
        else: self.setStyleSheet(f"QPushButton{{background:transparent;color:{C['text_sub']};border:none;border-left:4px solid transparent;border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:600;}}QPushButton:hover{{background:{C['card']};color:{C['text']};border-left:4px solid {C['border']};}}")
    def setChecked(self, v): super().setChecked(v); self._refresh(v)

class DashboardPage(QWidget):
    def __init__(self, crm: CRMMerkezi):
        super().__init__()
        self.crm = crm
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lbl = QLabel("📊  CRM Performans Analizi")
        lbl.setStyleSheet(f"color:{C['text']};font-size:24px;font-weight:800;")
        lay.addWidget(lbl)

        self.kpi_row = QHBoxLayout(); lay.addLayout(self.kpi_row)
        self.c1 = KpiCard("Aktif Müşteri", 0, "Sisteme Kayıtlı", C['accent'])
        self.c2 = KpiCard("Toplam Ciro", 0, "Yapılan Satışlar", C['success'])
        self.c3 = KpiCard("Açık Destek", 0, "Bekleyen Talepler", C['danger'])
        for c in [self.c1, self.c2, self.c3]: self.kpi_row.addWidget(c)
        
        lay.addWidget(QLabel("Son Kayıt Edilen Müşteriler", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:15px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(3)
        self.tablo.setHorizontalHeaderLabels(["Müşteri ID", "Müşteri Adı / Ünvanı", "İletişim (Telefon)"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def refresh(self):
        musteriler = list(self.crm.get_tum_musteriler().values())
        satislar = self.crm.get_tum_satislar()
        talepler = self.crm.get_tum_talepler()
        
        self.c1.guncelle(len(musteriler))
        toplam_ciro = sum(s.get_fiyat() for s in satislar)
        self.c2.guncelle(f"₺{toplam_ciro:,.0f}")
        self.c3.guncelle(sum(1 for t in talepler if t.get_durum() == "Açık"))

        self.tablo.setRowCount(0)
        # Son eklenenleri üstte göstermek için reversed kullanıyoruz
        for m in reversed(musteriler):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(m.get_musteri_id())))
            
            ad_item = QTableWidgetItem(m.get_ad())
            font = QFont(); font.setBold(True); ad_item.setFont(font)
            self.tablo.setItem(r, 1, ad_item)
            
            self.tablo.setItem(r, 2, QTableWidgetItem(m.get_telefon()))
# İTHALATÇI TEDARİKÇİ SINIFI 
class MusteriPage(QWidget):
    def __init__(self, crm: CRMMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.crm = crm; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("👥  Müşteri Veritabanı", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Sisteme Yeni Müşteri Tanımla", styleSheet=f"color:{C['accent']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QHBoxLayout()
        self.m_id = QSpinBox(); self.m_id.setRange(1, 99999)
        self.m_ad = QLineEdit(); self.m_ad.setPlaceholderText("Şirket veya Kişi Adı")
        self.m_tel = QLineEdit(); self.m_tel.setPlaceholderText("Telefon Numarası")
        for w in [self.m_id, self.m_ad, self.m_tel]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("ID:", styleSheet=lbl_style)); g.addWidget(self.m_id)
        g.addWidget(QLabel("Ad/Ünvan:", styleSheet=lbl_style)); g.addWidget(self.m_ad)
        g.addWidget(QLabel("Telefon:", styleSheet=lbl_style)); g.addWidget(self.m_tel)
        klay.addLayout(g)
        
        btn_ekle = QPushButton("＋ Müşteriyi Kaydet"); btn_ekle.setStyleSheet(btn_primary_ss()); btn_ekle.clicked.connect(self._musteri_ekle)
        klay.addWidget(btn_ekle, alignment=Qt.AlignRight)
        lay.addWidget(kart)

        # EKLENEN KISIM: MÜŞTERİLER LİSTESİ
        lay.addWidget(QLabel("Kayıtlı Tüm Aktif Müşteriler", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(3)
        self.tablo.setHorizontalHeaderLabels(["Müşteri ID", "Ad Soyad / Ünvan", "Telefon Numarası"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _musteri_ekle(self):
        if not self.m_ad.text().strip() or not self.m_tel.text().strip():
            QMessageBox.warning(self, "Hata", "Ad ve Telefon alanları zorunludur!")
            return
        m = Musteri(self.m_id.value(), self.m_ad.text(), self.m_tel.text())
        ok, msg = self.crm.musteri_ekle(m)
        if ok: 
            self.m_ad.clear(); self.m_tel.clear()
            QMessageBox.information(self, "Başarılı", msg)
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Uyarı", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        musteriler = list(self.crm.get_tum_musteriler().values())
        for m in reversed(musteriler):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(m.get_musteri_id())))
            
            ad_item = QTableWidgetItem(m.get_ad())
            font = QFont(); font.setBold(True); ad_item.setFont(font)
            ad_item.setForeground(QColor(C['accent'])) # Müşteri isimlerini turkuaz vurguladık
            self.tablo.setItem(r, 1, ad_item)
            
            self.tablo.setItem(r, 2, QTableWidgetItem(m.get_telefon()))

# İTHALATÇI TEDARİKÇİ SINIFI
class SatisPage(QWidget):
    def __init__(self, crm: CRMMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.crm = crm; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("💼  Satış Yönetimi", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QHBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        
        self.s_uye = QSpinBox(); self.s_uye.setRange(1, 99999); self.s_uye.setStyleSheet(input_ss())
        self.s_urun = QLineEdit(); self.s_urun.setPlaceholderText("Satılan Ürün/Hizmet"); self.s_urun.setStyleSheet(input_ss())
        self.s_fiyat = QDoubleSpinBox(); self.s_fiyat.setRange(0, 9999999); self.s_fiyat.setDecimals(2); self.s_fiyat.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        klay.addWidget(QLabel("Müşteri ID:", styleSheet=lbl_style)); klay.addWidget(self.s_uye)
        klay.addWidget(QLabel("Ürün:", styleSheet=lbl_style)); klay.addWidget(self.s_urun)
        klay.addWidget(QLabel("Tutar (₺):", styleSheet=lbl_style)); klay.addWidget(self.s_fiyat)
        
        btn_satis = QPushButton("✓ Satışı Onayla"); btn_satis.setStyleSheet(btn_success_ss()); btn_satis.clicked.connect(self._satis_yap)
        klay.addWidget(btn_satis)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Gerçekleşen Satışlar Listesi", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["İşlem No", "Müşteri", "Ürün/Hizmet", "Tarih", "Tutar (₺)"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _satis_yap(self):
        if not self.s_urun.text().strip():
            QMessageBox.warning(self, "Hata", "Ürün adı boş olamaz!")
            return
        ok, msg = self.crm.yeni_satis_yap(self.s_uye.value(), self.s_urun.text(), self.s_fiyat.value())
        if ok: 
            QMessageBox.information(self, "Başarılı", msg)
            self.s_urun.clear(); self.s_fiyat.setValue(0)
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Hata", msg)

    def refresh(self):
        self.tablo.setRowCount(0)
        for s in reversed(self.crm.get_tum_satislar()):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(f"#{s.get_satis_id()}"))
            self.tablo.setItem(r, 1, QTableWidgetItem(s.get_musteri().get_ad()))
            self.tablo.setItem(r, 2, QTableWidgetItem(s.get_urun()))
            self.tablo.setItem(r, 3, QTableWidgetItem(s.get_tarih().strftime("%d.%m.%Y %H:%M")))
            
            fiyat_item = QTableWidgetItem(f"₺{s.get_fiyat():,.2f}")
            fiyat_item.setForeground(QColor(C['success']))
            self.tablo.setItem(r, 4, fiyat_item)

class DestekPage(QWidget): # Destek taleplerinin yönetildiği sayfa
    def __init__(self, crm: CRMMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.crm = crm; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🛠️  Destek Talepleri (Helpdesk)", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QHBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        
        self.d_uye = QSpinBox(); self.d_uye.setRange(1, 99999); self.d_uye.setStyleSheet(input_ss())
        self.d_aciklama = QLineEdit(); self.d_aciklama.setPlaceholderText("Müşterinin sorunu nedir?"); self.d_aciklama.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        klay.addWidget(QLabel("Müşteri ID:", styleSheet=lbl_style)); klay.addWidget(self.d_uye)
        klay.addWidget(QLabel("Sorun/Açıklama:", styleSheet=lbl_style)); klay.addWidget(self.d_aciklama)
        
        btn_ac = QPushButton("＋ Talep Aç"); btn_ac.setStyleSheet(btn_warning_ss()); btn_ac.clicked.connect(self._talep_ac)
        btn_kapat = QPushButton("✓ Seçileni Çözüldü Yap"); btn_kapat.setStyleSheet(btn_success_ss()); btn_kapat.clicked.connect(self._talep_kapat)
        klay.addWidget(btn_ac); klay.addWidget(btn_kapat)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Aktif ve Geçmiş Talepler (Detay için metne tıklayın)", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        # EKLENEN KISIM: Sütun başlığında (Tıkla) uyarısı
        self.tablo.setHorizontalHeaderLabels(["Talep ID", "Durum", "Müşteri", "Açıklama (Tıkla)", "Tarih"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tablo.verticalHeader().setVisible(False)
        
        # EKLENEN KISIM: Hücreye tıklanınca çalışan fonksiyon
        self.tablo.cellClicked.connect(self._hucreye_tiklandi)
        
        lay.addWidget(self.tablo)
        self.refresh()

    def _hucreye_tiklandi(self, row, col):
        """Kullanıcı açıklama sütununa tıkladığında çalışan metod."""
        if col == 3:  # 3 numaralı sütun "Açıklama" sütunudur
            # Tıklanan satırdaki metni ve ID'yi alıyoruz
            talep_id = self.tablo.item(row, 0).text()
            aciklama = self.tablo.item(row, col).text()
            
            # Popup (Mesaj Kutusu) gösterimi
            msg = QMessageBox(self)
            msg.setWindowTitle(f"Destek Talebi Detayı - {talep_id}")
            msg.setText(f"<b>Müşterinin İlettiği Sorun:</b><br><br>{aciklama}")
            msg.setStyleSheet(f"""
                QMessageBox {{ background: {C['card']}; color: {C['text']}; }}
                QLabel {{ color: {C['text']}; font-size: 14px; }}
                QPushButton {{ background: {C['accent']}; color: #000; border-radius: 5px; padding: 6px 15px; font-weight: bold; }}
            """)
            msg.exec_()

    def _talep_ac(self):
        if not self.d_aciklama.text().strip():
            QMessageBox.warning(self, "Hata", "Açıklama alanı boş bırakılamaz!")
            return
        ok, msg = self.crm.yeni_talep_ac(self.d_uye.value(), self.d_aciklama.text())
        if ok:
            self.d_aciklama.clear()
            self.refresh()
            self.dashboard.refresh()
        else: QMessageBox.warning(self, "Hata", msg)

    def _talep_kapat(self):
        secili = self.tablo.currentRow()
        if secili < 0:
            QMessageBox.warning(self, "Uyarı", "Kapatmak için listeden bir talep seçin!")
            return
        
        talep_id_str = self.tablo.item(secili, 0).text().replace("#", "")
        ok, msg = self.crm.talep_cozuldu_isaretle(int(talep_id_str))
        if ok:
            self.refresh()
            self.dashboard.refresh()

    def refresh(self):
        self.tablo.setRowCount(0)
        for t in reversed(self.crm.get_tum_talepler()):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(f"#{t.get_talep_id()}"))
            
            durum_item = QTableWidgetItem(t.get_durum())
            font = QFont(); font.setBold(True); durum_item.setFont(font)
            if t.get_durum() == "Açık": durum_item.setForeground(QColor(C['danger']))
            else: durum_item.setForeground(QColor(C['success']))
            self.tablo.setItem(r, 1, durum_item)
            
            self.tablo.setItem(r, 2, QTableWidgetItem(t.get_musteri().get_ad()))
            
            # EKLENEN KISIM: Açıklamanın tıklanabilir olduğunu belirten renklendirme ve ipucu
            aciklama_item = QTableWidgetItem(t.get_aciklama())
            aciklama_item.setForeground(QColor(C['accent']))
            aciklama_item.setToolTip("Tamamını okumak için üzerine tıklayın")
            
            self.tablo.setItem(r, 3, aciklama_item)
            self.tablo.setItem(r, 4, QTableWidgetItem(t.get_tarih().strftime("%d.%m.%Y %H:%M")))

class MainWindow(QMainWindow): # Uygulamanın ana penceresi ve navigasyon yönetimi
    def __init__(self):
        super().__init__()
        self.setWindowTitle("💼 Proje 10 — Kurumsal CRM Sistemi")
        self.setMinimumSize(1200, 750); self.setStyleSheet(f"QMainWindow{{background:{C['bg']};color:{C['text']};}}")

        self.crm = CRMMerkezi()
        self.crm.test_verilerini_yukle()

        merkez = QWidget(); merkez.setStyleSheet(f"background:{C['bg']};"); self.setCentralWidget(merkez)
        ana = QHBoxLayout(merkez); ana.setContentsMargins(0, 0, 0, 0); ana.setSpacing(0)

        sidebar = QFrame(); sidebar.setFixedWidth(240); sidebar.setStyleSheet(f"background:{C['sidebar']};border-right:1px solid {C['border']};")
        sb = QVBoxLayout(sidebar); sb.setContentsMargins(0, 0, 0, 20); sb.setSpacing(0)
        
        logo = QFrame(); logo.setFixedHeight(80); logo.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C['accent']},stop:1 {C['accent2']});")
        ll = QVBoxLayout(logo); ll.setContentsMargins(20, 15, 20, 15)
        t1 = QLabel("💼 CRM Sistemi"); t1.setStyleSheet("color:#000;font-size:18px;font-weight:900;background:transparent;")
        t2 = QLabel("Proje 10"); t2.setStyleSheet("color:rgba(0,0,0,0.7);font-size:12px;font-weight:800;background:transparent;")
        ll.addWidget(t1); ll.addWidget(t2); sb.addWidget(logo); sb.addSpacing(20)

        self.nav = []
        for ikon, metin in [("📊", "Analiz (Özet)"), ("👥", "Müşteriler"), ("💼", "Satış İşlemleri"), ("🛠️", "Destek Talepleri")]:
            btn = SideBtn(ikon, metin); btn.clicked.connect(lambda _, m=metin: self._goto(m))
            sb.addWidget(btn); self.nav.append(btn)
        sb.addStretch()
        
        self.lbl_saat = QLabel(); self.lbl_saat.setAlignment(Qt.AlignCenter); self.lbl_saat.setStyleSheet(f"color:{C['text_dim']};font-size:12px;font-weight:800;background:transparent;")
        sb.addWidget(self.lbl_saat); ana.addWidget(sidebar)

        icerik = QWidget(); icerik.setStyleSheet(f"background:{C['bg']};")
        il = QVBoxLayout(icerik); il.setContentsMargins(0,0,0,0); il.setSpacing(0)

        topbar = QFrame(); topbar.setFixedHeight(55); topbar.setStyleSheet(f"background:{C['sidebar']};border-bottom:1px solid {C['border']};")
        tl = QHBoxLayout(topbar); tl.setContentsMargins(30, 0, 30, 0)
        self.lbl_page = QLabel("ANALİZ (ÖZET)"); self.lbl_page.setStyleSheet(f"color:{C['text']};font-size:15px;font-weight:800;background:transparent;")
        tl.addWidget(self.lbl_page); tl.addStretch()
        tl.addWidget(QLabel("👤 Yönetici", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        il.addWidget(topbar)

        self.stack = QStackedWidget(); self.stack.setStyleSheet(f"background:{C['bg']};")
        self.p_dashboard = DashboardPage(self.crm)
        self.p_musteri = MusteriPage(self.crm, self.p_dashboard)
        self.p_satis = SatisPage(self.crm, self.p_dashboard)
        self.p_destek = DestekPage(self.crm, self.p_dashboard)
        
        for p in [self.p_dashboard, self.p_musteri, self.p_satis, self.p_destek]: self.stack.addWidget(p)
        il.addWidget(self.stack); ana.addWidget(icerik)

        self._goto("Analiz (Özet)")
        t = QTimer(self); t.timeout.connect(lambda: self.lbl_saat.setText(datetime.now().strftime("%d.%m.%Y\n%H:%M:%S"))); t.start(1000)

    def _goto(self, sayfa):
        idx = {"Analiz (Özet)": 0, "Müşteriler": 1, "Satış İşlemleri": 2, "Destek Talepleri": 3}[sayfa]
        self.stack.setCurrentIndex(idx)
        self.lbl_page.setText(sayfa.upper())
        for i, b in enumerate(self.nav): b.setChecked(i == idx)
        
        # Sekme değiştiğinde tüm verileri taze tutmak için:
        if idx == 0: self.p_dashboard.refresh()
        elif idx == 1: self.p_musteri.refresh()
        elif idx == 2: self.p_satis.refresh()
        elif idx == 3: self.p_destek.refresh()

# ============================================================
#  3. KISIM: UYGULAMA BAŞLATMAK
# ============================================================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    p = QPalette()
    p.setColor(QPalette.Window, QColor(C['bg'])); p.setColor(QPalette.WindowText, QColor(C['text']))
    p.setColor(QPalette.Base, QColor(C['card'])); p.setColor(QPalette.AlternateBase, QColor(C['row_alt']))
    p.setColor(QPalette.Text, QColor(C['text'])); p.setColor(QPalette.Button, QColor(C['card']))
    p.setColor(QPalette.ButtonText, QColor(C['text'])); p.setColor(QPalette.Highlight, QColor(C['accent']))
    p.setColor(QPalette.HighlightedText, QColor("#000"))
    app.setPalette(p)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())