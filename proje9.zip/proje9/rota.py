"""
============================================================
  PROJE 9: SEYAHAT PLANLAMA UYGULAMASI
============================================================
Açıklama: Bu proje, Nesne Tabanlı Programlama (OOP) ile
Konaklama, Plan ve Seyahat sınıflarını birleştirerek 
(Composition) gelişmiş bir tatil ajandası sunar.
============================================================
"""

import sys
from datetime import datetime

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFrame,
    QStackedWidget, QHeaderView, QLineEdit, QGridLayout,
    QSpinBox, QDoubleSpinBox, QMessageBox, QAbstractItemView, QGraphicsDropShadowEffect,
    QDateEdit, QComboBox
)
from PyQt5.QtCore import Qt, QTimer, QDate
from PyQt5.QtGui import QColor, QPalette, QFont

# ============================================================
#  1. KISIM: İŞ MANTIĞI VE SINIFLAR (BACKEND)
# ============================================================

class Konaklama:
    """Seyahat sırasındaki otel ve fiyat bilgisini tutar."""
    def __init__(self, otel_adi: str, fiyat: float):
        # HOCAYA AÇIKLAMA: Encapsulation (Kapsülleme) ile verileri gizliyoruz.
        self.__otel_adi = otel_adi
        self.__fiyat = fiyat

    def get_otel_adi(self) -> str: return self.__otel_adi
    def get_fiyat(self) -> float:  return self.__fiyat

class Plan:
    """Seyahatin rotasını ve yapılacak aktiviteleri liste olarak tutar."""
    def __init__(self):
        self.__rota = []         # Örn: ["Müze Gezisi", "Şehir Merkezi", "Liman"]
        self.__aktiviteler = []  # Örn: ["Yüzme", "Doğa Yürüyüşü"]

    def rota_ekle(self, yer: str):
        self.__rota.append(yer)
        return True, f"'{yer}' rotaya eklendi."

    def aktivite_ekle(self, aktivite: str):
        self.__aktiviteler.append(aktivite)
        return True, f"'{aktivite}' aktivitelere eklendi."

    def get_rota(self) -> list: return self.__rota
    def get_aktiviteler(self) -> list: return self.__aktiviteler

class Seyahat:
    """Konaklama ve Plan sınıflarını birleştiren Ana Seyahat nesnesi."""
    def __init__(self, seyahat_id: int, gidis_yeri: str, tarih: str, konaklama: Konaklama):
        self.__seyahat_id = seyahat_id
        self.__gidis_yeri = gidis_yeri
        self.__tarih = tarih
        
        # HOCAYA AÇIKLAMA: Composition (Bileşim). Bir seyahatin içinde Konaklama ve Plan sınıfları yaşar.
        self.__konaklama = konaklama
        self.__plan = Plan() 

    def get_seyahat_id(self) -> int: return self.__seyahat_id
    def get_gidis_yeri(self) -> str: return self.__gidis_yeri
    def get_tarih(self) -> str:      return self.__tarih
    def get_konaklama(self) -> Konaklama: return self.__konaklama
    def get_plan(self) -> Plan:      return self.__plan

class SeyahatMerkezi:
    """Tüm seyahat veritabanını yöneten Sistem (Manager) Sınıfı."""
    def __init__(self):
        self.__seyahatler = {}

    def seyahat_olustur(self, seyahat: Seyahat):
        if seyahat.get_seyahat_id() in self.__seyahatler:
            return False, "Bu ID ile bir seyahat planı zaten mevcut!"
        self.__seyahatler[seyahat.get_seyahat_id()] = seyahat
        return True, f"{seyahat.get_gidis_yeri()} seyahati başarıyla oluşturuldu."

    def get_tum_seyahatler(self) -> dict:
        return self.__seyahatler

    def get_seyahat(self, seyahat_id: int) -> Seyahat:
        return self.__seyahatler.get(seyahat_id, None)

    def test_verilerini_yukle(self):
        # Sunum için dolu görünmesi adına hazır veriler
        k1 = Konaklama("Rixos Premium", 25000.0)
        s1 = Seyahat(101, "Antalya", "15.06.2026", k1)
        s1.get_plan().rota_ekle("Kaleiçi")
        s1.get_plan().rota_ekle("Düden Şelalesi")
        s1.get_plan().aktivite_ekle("Tüplü Dalış")
        self.seyahat_olustur(s1)

        k2 = Konaklama("Hilton Bosphorus", 18000.0)
        s2 = Seyahat(102, "İstanbul", "22.06.2026", k2)
        s2.get_plan().aktivite_ekle("Boğaz Turu")
        self.seyahat_olustur(s2)


# ============================================================
#  2. KISIM: ARAYÜZ (GUI) - PREMIUM TRAVEL TEMASI
# ============================================================

# TEMA: TripAdvisor / Booking tarzı (Gece Mavisi & Turuncu)
C = {
    "bg":        "#0B1120",  # Çok Koyu Mavi
    "sidebar":   "#131C31",  # Yan Panel
    "card":      "#1E293B",  # Kart Rengi (Slate)
    "border":    "#334155",  # Kenarlıklar
    "accent":    "#0EA5E9",  # Tatil Mavisi (Sky)
    "accent2":   "#F59E0B",  # Gün Batımı Turuncusu (Amber)
    "success":   "#10B981",  # Zümrüt Yeşili
    "warning":   "#FBBF24",  # Sarı
    "danger":    "#EF4444",  # Kırmızı
    "text":      "#F8FAFC",  # Beyaz
    "text_sub":  "#94A3B8",  # Gri Alt Metin
    "text_dim":  "#475569",  # Koyu Gri
    "row_alt":   "#151F32",  # Tablo Çizgili Satır
    "row_sel":   "#1E3A5F",  # Seçili Satır
    "input_bg":  "#0B1120",  # Girdi Alanı
}

def card_ss(): return f"background:{C['card']};border:1px solid {C['border']};border-radius:12px;"
def btn_primary_ss(): return f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C['accent']},stop:1 #0284C7);color:#FFF;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{opacity: 0.8;}}"
def btn_success_ss(): return f"QPushButton{{background:{C['accent2']};color:#000;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#FCD34D;}}"
def input_ss(): return f"QLineEdit,QSpinBox,QDoubleSpinBox,QDateEdit,QComboBox{{background:{C['input_bg']};color:{C['text']};border:1px solid {C['border']};border-radius:8px;padding:8px 12px;font-size:13px;}}"

TABLE_SS = f"""
    QTableWidget{{background:{C['card']};color:{C['text']};border:none;gridline-color:{C['border']};font-size:13px;selection-background-color:{C['row_sel']};outline:none;alternate-background-color:{C['row_alt']};}}
    QTableWidget::item{{padding:10px 14px;border-bottom:1px solid {C['border']};}}
    QHeaderView::section{{background:{C['sidebar']};color:{C['accent']};padding:10px 14px;border:none;border-bottom:2px solid {C['accent']};font-size:12px;font-weight:800;letter-spacing:0.5px;}}
"""

def shadow(widget):
    fx = QGraphicsDropShadowEffect(widget)
    fx.setBlurRadius(20); fx.setColor(QColor(0, 0, 0, 90)); fx.setOffset(0, 4)
    widget.setGraphicsEffect(fx)

class KpiCard(QFrame):
    def __init__(self, baslik, deger, alt, renk):
        super().__init__()
        self.setFixedHeight(114)
        self.setStyleSheet(f"QFrame{{background:{C['card']};border:1px solid {C['border']};border-radius:12px;border-left:5px solid {renk};}}")
        shadow(self)
        lay = QVBoxLayout(self); lay.setContentsMargins(20, 15, 20, 15); lay.setSpacing(4)
        lbl_t = QLabel(baslik.upper()); lbl_t.setStyleSheet(f"color:{C['text_sub']};font-size:11px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        self.lbl_v = QLabel(str(deger)); self.lbl_v.setStyleSheet(f"color:{renk};font-size:30px;font-weight:800;background:transparent;border:none;")
        lbl_a = QLabel(alt); lbl_a.setStyleSheet(f"color:{C['text_dim']};font-size:12px;background:transparent;border:none;")
        lay.addWidget(lbl_t); lay.addWidget(self.lbl_v); lay.addWidget(lbl_a)
    def guncelle(self, val): self.lbl_v.setText(str(val))

class SideBtn(QPushButton):
    def __init__(self, ikon, metin):
        super().__init__(f"  {ikon}  {metin}")
        self.setCheckable(True); self.setFixedHeight(50); self.setCursor(Qt.PointingHandCursor)
        self._refresh(False)
    def _refresh(self, aktif):
        if aktif: self.setStyleSheet(f"QPushButton{{background:rgba(14, 165, 233, 0.15);color:{C['accent']};border:none;border-left:4px solid {C['accent']};border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:800;}}")
        else: self.setStyleSheet(f"QPushButton{{background:transparent;color:{C['text_sub']};border:none;border-left:4px solid transparent;border-radius:0;text-align:left;padding-left:18px;font-size:14px;font-weight:600;}}QPushButton:hover{{background:{C['card']};color:{C['text']};border-left:4px solid {C['border']};}}")
    def setChecked(self, v): super().setChecked(v); self._refresh(v)

class DashboardPage(QWidget):
    def __init__(self, merkez: SeyahatMerkezi):
        super().__init__()
        self.merkez = merkez
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🌍  Seyahat Özeti", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        self.kpi_row = QHBoxLayout(); lay.addLayout(self.kpi_row)
        self.c1 = KpiCard("Planlanan Seyahat", 0, "Aktif Tatil Planı", C['accent'])
        self.c2 = KpiCard("Toplam Rota", 0, "Gezilecek Yerler", C['accent2'])
        self.c3 = KpiCard("Otel Gideri", 0, "Toplam Konaklama Bütçesi", C['success'])
        for c in [self.c1, self.c2, self.c3]: self.kpi_row.addWidget(c)
        
        lay.addWidget(QLabel("Yaklaşan Seyahatler", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:15px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["ID", "Gidiş Yeri", "Tarih", "Otel Adı"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)

    def refresh(self):
        seyahatler = self.merkez.get_tum_seyahatler().values()
        self.c1.guncelle(len(seyahatler))
        
        toplam_rota = sum(len(s.get_plan().get_rota()) for s in seyahatler)
        self.c2.guncelle(toplam_rota)
        
        toplam_gider = sum(s.get_konaklama().get_fiyat() for s in seyahatler)
        self.c3.guncelle(f"₺{toplam_gider:,.0f}")

        self.tablo.setRowCount(0)
        for s in reversed(list(seyahatler)):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            id_item = QTableWidgetItem(f"#{s.get_seyahat_id()}")
            id_item.setForeground(QColor(C['accent2']))
            font = QFont(); font.setBold(True); id_item.setFont(font)
            
            self.tablo.setItem(r, 0, id_item)
            self.tablo.setItem(r, 1, QTableWidgetItem(s.get_gidis_yeri()))
            self.tablo.setItem(r, 2, QTableWidgetItem(s.get_tarih()))
            self.tablo.setItem(r, 3, QTableWidgetItem(s.get_konaklama().get_otel_adi()))

class SeyahatPage(QWidget):
    def __init__(self, merkez: SeyahatMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🛫  Yeni Seyahat Planla", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        klay.addWidget(QLabel("Seyahat ve Konaklama Bilgileri", styleSheet=f"color:{C['accent']};font-size:14px;font-weight:800;background:transparent;"))
        
        g = QGridLayout()
        self.s_id = QSpinBox(); self.s_id.setRange(1, 99999)
        self.s_yer = QLineEdit(); self.s_yer.setPlaceholderText("Gidilecek Şehir/Ülke")
        self.s_tarih = QDateEdit(); self.s_tarih.setCalendarPopup(True); self.s_tarih.setDate(QDate.currentDate())
        self.s_otel = QLineEdit(); self.s_otel.setPlaceholderText("Konaklanacak Otel")
        self.s_fiyat = QDoubleSpinBox(); self.s_fiyat.setRange(0, 999999); self.s_fiyat.setDecimals(2)
        
        for w in [self.s_id, self.s_yer, self.s_tarih, self.s_otel, self.s_fiyat]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:12px;font-weight:800;background:transparent;"
        g.addWidget(QLabel("Seyahat ID:", styleSheet=lbl_style), 0, 0); g.addWidget(self.s_id, 1, 0)
        g.addWidget(QLabel("Gidiş Yeri:", styleSheet=lbl_style), 0, 1); g.addWidget(self.s_yer, 1, 1)
        g.addWidget(QLabel("Tarih:", styleSheet=lbl_style), 0, 2); g.addWidget(self.s_tarih, 1, 2)
        g.addWidget(QLabel("Otel Adı:", styleSheet=lbl_style), 2, 0); g.addWidget(self.s_otel, 3, 0, 1, 2)
        g.addWidget(QLabel("Otel Fiyatı (₺):", styleSheet=lbl_style), 2, 2); g.addWidget(self.s_fiyat, 3, 2)
        klay.addLayout(g)
        
        btn_ekle = QPushButton("＋ Planı Kaydet"); btn_ekle.setStyleSheet(btn_primary_ss()); btn_ekle.clicked.connect(self._seyahat_ekle)
        klay.addWidget(btn_ekle, alignment=Qt.AlignRight)
        lay.addWidget(kart); lay.addStretch()

    def _seyahat_ekle(self):
        if not self.s_yer.text().strip() or not self.s_otel.text().strip():
            QMessageBox.warning(self, "Hata", "Lütfen yer ve otel adı giriniz!")
            return
        
        # Konaklama Nesnesi Oluşturuluyor
        otel = Konaklama(self.s_otel.text(), self.s_fiyat.value())
        # Seyahat Nesnesi Oluşturuluyor (İçine Konaklama gömüldü)
        seyahat = Seyahat(self.s_id.value(), self.s_yer.text(), self.s_tarih.date().toString("dd.MM.yyyy"), otel)
        
        ok, msg = self.merkez.seyahat_olustur(seyahat)
        if ok: 
            self.s_yer.clear(); self.s_otel.clear(); self.s_fiyat.setValue(0)
            self.dashboard.refresh()
            # Diğer sayfayı da yenile
            if hasattr(self.parentWidget().parentWidget(), 'p_plan'):
                self.parentWidget().parentWidget().p_plan.combo_guncelle()
            QMessageBox.information(self, "Başarılı", msg)
        else: QMessageBox.warning(self, "Uyarı", msg)

class PlanPage(QWidget):
    def __init__(self, merkez: SeyahatMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.merkez = merkez; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(32, 28, 32, 28); lay.setSpacing(20)
        lay.addWidget(QLabel("🗺️  Rota ve Aktivite Planlayıcı", styleSheet=f"color:{C['text']};font-size:24px;font-weight:800;"))

        # İşlem Kartı
        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(24,20,24,20)
        
        self.combo = QComboBox(); self.combo.setStyleSheet(input_ss())
        self.combo.currentIndexChanged.connect(self.tablo_guncelle)
        klay.addWidget(QLabel("Plan Yapılacak Seyahati Seçin:", styleSheet=f"color:{C['accent2']};font-size:13px;font-weight:800;background:transparent;"))
        klay.addWidget(self.combo)
        
        g = QHBoxLayout()
        self.p_metin = QLineEdit(); self.p_metin.setPlaceholderText("Eklenecek Yer veya Aktivite..."); self.p_metin.setStyleSheet(input_ss())
        g.addWidget(self.p_metin)
        
        btn_rota = QPushButton("📍 Rota Ekle"); btn_rota.setStyleSheet(btn_primary_ss()); btn_rota.clicked.connect(lambda: self._plan_ekle("rota"))
        btn_akt = QPushButton("🏄 Aktivite Ekle"); btn_akt.setStyleSheet(btn_success_ss()); btn_akt.clicked.connect(lambda: self._plan_ekle("aktivite"))
        g.addWidget(btn_rota); g.addWidget(btn_akt)
        klay.addLayout(g)
        lay.addWidget(kart)

        lay.addWidget(QLabel("Seçili Seyahatin Plan Detayları", styleSheet=f"color:{C['text_sub']};font-size:14px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(2)
        self.tablo.setHorizontalHeaderLabels(["Rotadaki Yerler", "Planlanan Aktiviteler"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        
        self.combo_guncelle()

    def combo_guncelle(self):
        self.combo.clear()
        for s in self.merkez.get_tum_seyahatler().values():
            self.combo.addItem(f"#{s.get_seyahat_id()} - {s.get_gidis_yeri()}", s.get_seyahat_id())
        self.tablo_guncelle()

    def tablo_guncelle(self):
        self.tablo.setRowCount(0)
        s_id = self.combo.currentData()
        if not s_id: return
        
        seyahat = self.merkez.get_seyahat(s_id)
        if not seyahat: return
        
        rotalar = seyahat.get_plan().get_rota()
        aktiviteler = seyahat.get_plan().get_aktiviteler()
        
        max_row = max(len(rotalar), len(aktiviteler))
        self.tablo.setRowCount(max_row)
        
        for i in range(max_row):
            if i < len(rotalar):
                item = QTableWidgetItem(f"📍 {rotalar[i]}")
                item.setForeground(QColor(C['accent']))
                self.tablo.setItem(i, 0, item)
            if i < len(aktiviteler):
                item = QTableWidgetItem(f"🏄 {aktiviteler[i]}")
                item.setForeground(QColor(C['accent2']))
                self.tablo.setItem(i, 1, item)

    def _plan_ekle(self, tip):
        s_id = self.combo.currentData()
        metin = self.p_metin.text().strip()
        if not s_id or not metin:
            QMessageBox.warning(self, "Hata", "Lütfen bir seyahat seçin ve veri girin!")
            return
            
        seyahat = self.merkez.get_seyahat(s_id)
        plan = seyahat.get_plan() # Sınıf içindeki Plan nesnesine eriştik
        
        if tip == "rota":
            plan.rota_ekle(metin)
        else:
            plan.aktivite_ekle(metin)
            
        self.p_metin.clear()
        self.tablo_guncelle()
        self.dashboard.refresh()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("✈️ Proje 9 — Seyahat Planlama")
        self.setMinimumSize(1200, 750); self.setStyleSheet(f"QMainWindow{{background:{C['bg']};color:{C['text']};}}")

        self.merkez = SeyahatMerkezi()
        self.merkez.test_verilerini_yukle()

        merkez_widget = QWidget(); merkez_widget.setStyleSheet(f"background:{C['bg']};"); self.setCentralWidget(merkez_widget)
        ana = QHBoxLayout(merkez_widget); ana.setContentsMargins(0, 0, 0, 0); ana.setSpacing(0)

        # YAN PANEL
        sidebar = QFrame(); sidebar.setFixedWidth(240); sidebar.setStyleSheet(f"background:{C['sidebar']};border-right:1px solid {C['border']};")
        sb = QVBoxLayout(sidebar); sb.setContentsMargins(0, 0, 0, 20); sb.setSpacing(0)
        
        logo = QFrame(); logo.setFixedHeight(80); logo.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C['accent']},stop:1 {C['accent2']});")
        ll = QVBoxLayout(logo); ll.setContentsMargins(20, 15, 20, 15)
        t1 = QLabel("✈️ TRAVEL MASTER"); t1.setStyleSheet("color:#FFF;font-size:18px;font-weight:900;background:transparent;")
        t2 = QLabel("Proje 9 Sistemi"); t2.setStyleSheet("color:rgba(255,255,255,0.8);font-size:12px;font-weight:800;background:transparent;")
        ll.addWidget(t1); ll.addWidget(t2); sb.addWidget(logo); sb.addSpacing(20)

        self.nav = []
        for ikon, metin in [("🌍", "Özet Ekranı"), ("🛫", "Yeni Seyahat"), ("🗺️", "Rota ve Aktivite")]:
            btn = SideBtn(ikon, metin); btn.clicked.connect(lambda _, m=metin: self._goto(m))
            sb.addWidget(btn); self.nav.append(btn)
        sb.addStretch()
        
        self.lbl_saat = QLabel(); self.lbl_saat.setAlignment(Qt.AlignCenter); self.lbl_saat.setStyleSheet(f"color:{C['text_dim']};font-size:12px;font-weight:800;background:transparent;")
        sb.addWidget(self.lbl_saat); ana.addWidget(sidebar)

        # İÇERİK ALANI
        icerik = QWidget(); icerik.setStyleSheet(f"background:{C['bg']};")
        il = QVBoxLayout(icerik); il.setContentsMargins(0,0,0,0); il.setSpacing(0)

        topbar = QFrame(); topbar.setFixedHeight(55); topbar.setStyleSheet(f"background:{C['sidebar']};border-bottom:1px solid {C['border']};")
        tl = QHBoxLayout(topbar); tl.setContentsMargins(30, 0, 30, 0)
        self.lbl_page = QLabel("ÖZET EKRANI"); self.lbl_page.setStyleSheet(f"color:{C['text']};font-size:15px;font-weight:800;background:transparent;")
        tl.addWidget(self.lbl_page); tl.addStretch()
        tl.addWidget(QLabel("👤 Yönetici", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        il.addWidget(topbar)

        self.stack = QStackedWidget(); self.stack.setStyleSheet(f"background:{C['bg']};")
        self.p_dashboard = DashboardPage(self.merkez)
        self.p_seyahat = SeyahatPage(self.merkez, self.p_dashboard)
        self.p_plan = PlanPage(self.merkez, self.p_dashboard)
        
        for p in [self.p_dashboard, self.p_seyahat, self.p_plan]: self.stack.addWidget(p)
        il.addWidget(self.stack); ana.addWidget(icerik)

        self._goto("Özet Ekranı")
        t = QTimer(self); t.timeout.connect(lambda: self.lbl_saat.setText(datetime.now().strftime("%d.%m.%Y\n%H:%M:%S"))); t.start(1000)

    def _goto(self, sayfa):
        idx = {"Özet Ekranı": 0, "Yeni Seyahat": 1, "Rota ve Aktivite": 2}[sayfa]
        self.stack.setCurrentIndex(idx)
        self.lbl_page.setText(sayfa.upper())
        for i, b in enumerate(self.nav): b.setChecked(i == idx)
        
        if idx == 0: self.p_dashboard.refresh()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    p = QPalette()
    p.setColor(QPalette.Window, QColor(C['bg'])); p.setColor(QPalette.WindowText, QColor(C['text']))
    p.setColor(QPalette.Base, QColor(C['card'])); p.setColor(QPalette.AlternateBase, QColor(C['row_alt']))
    p.setColor(QPalette.Text, QColor(C['text'])); p.setColor(QPalette.Button, QColor(C['card']))
    p.setColor(QPalette.ButtonText, QColor(C['text'])); p.setColor(QPalette.Highlight, QColor(C['accent']))
    p.setColor(QPalette.HighlightedText, QColor("#FFF"))
    app.setPalette(p)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())